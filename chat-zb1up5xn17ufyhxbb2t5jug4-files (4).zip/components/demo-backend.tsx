// NO DEMO MODE - REMOVED
// This application only works with real backend connection
// No fallback or demo functionality allowed

export default function NoDemoMode() {
  return null
}