"use client"

import { useState, useEffect } from 'react'
import { Calendar, Cloud, Download, Share2 } from 'lucide-react'
import { Badge } from './ui/badge'
import { Button } from './ui/button'
import ImageLoader from './image-loader'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

interface ResultsViewerProps {
  results: any
}

export default function ResultsViewer({ results }: ResultsViewerProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null)
  const [activeIndex, setActiveIndex] = useState<string>('ndvi')
  
  // Extract job ID from results
  const jobId = results.metadata?.job_id || 'unknown'
  
  console.log("🎯 ResultsViewer loaded", { jobId, results })
  
  // Convert backend static URLs to proxy URLs
  const getImageUrl = (staticUrl: string) => {
    if (!staticUrl) return ''
    // Remove leading slash if present and use proxy
    const cleanPath = staticUrl.startsWith('/') ? staticUrl.slice(1) : staticUrl
    return `/api/proxy?path=${encodeURIComponent(cleanPath)}`
  }
  
  console.log("🔗 Using proxy URLs for job:", jobId)

  if (!results || !results.images) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">📊 Nenhum resultado disponível</p>
      </div>
    )
  }

  const { metadata, indices, images, tiles } = results

  const downloadImage = (imagePath: string, filename: string) => {
    console.log("Downloading image", { imagePath, filename })
    const link = document.createElement('a')
    link.href = imagePath
    link.download = filename
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const openImageModal = (imagePath: string) => {
    console.log("Opening image modal", imagePath)
    setSelectedImage(imagePath)
  }

  const indexButtons = [
    { key: 'ndvi', label: 'NDVI' },
    { key: 'evi', label: 'EVI' },
    { key: 'savi', label: 'SAVI' },
    { key: 'gci', label: 'GCI' },
  ]

  const getIndexStats = (index: string) => {
    const indexData = indices.find((idx: any) => idx.indice.toLowerCase() === index)
    return indexData || { min: 0, media: 0, max: 0 }
  }

  // Check if all 5 guaranteed images are available
  const hasAllImages = images && images.rgb && images.ndvi && images.evi && images.savi && images.gci
  
  if (!hasAllImages) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">⏳ Aguardando imagens do processamento...</p>
        <p className="text-sm text-gray-400 mt-2">Status deve ser "done" para exibir imagens</p>
      </div>
    )
  }

  // jobId is already the short ID from backend
  const tilesUrl = `${process.env.NEXT_PUBLIC_TILES_URL || 'https://tiles.iagrosat.com'}/static/jobs/${jobId}/tiles/rgb/{z}/{x}/{y}.png`

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6 bg-white">
      {/* Header - Clean and Minimal */}
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          📊 Relatório de Análise Espectral
        </h1>
        <p className="text-gray-600">
          Job ID: <span className="font-mono">{results.metadata.job_id}</span> • 
          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800 ml-2">
            ✓ Concluído
          </span>
        </p>
      </div>

      {/* RGB Image - Top Center */}
      <div className="text-center mb-8">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">🖼️ Imagem RGB Sentinel-2</h2>
        <div className="inline-block bg-gray-50 p-4 rounded-lg shadow-sm">
          <img 
            src={getImageUrl(images.rgb)}
            alt="RGB Satellite Image" 
            className="max-w-md mx-auto rounded-lg shadow-md cursor-pointer hover:scale-105 transition-transform"
            onClick={() => setSelectedImage(getImageUrl(images.rgb))}
          />
          <div className="mt-3 text-sm text-gray-500">
            📅 {results.metadata.data_captura} • 🌤️ {results.metadata.cobertura_nuvens}% nuvens • 📍 {results.metadata.localizacao}
          </div>
        </div>
      </div>
      
      {/* Vegetation Indices - Horizontal Layout */}
      <div className="space-y-6">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">📈 Índices de Vegetação</h2>
          
          {/* Index Selection Buttons */}
          <div className="flex justify-center space-x-2 mb-6">
            {indexButtons.map((btn) => (
              <button
                key={btn.key}
                onClick={() => setActiveIndex(btn.key)}
                className={`px-6 py-2 rounded-lg font-medium transition-all ${
                  activeIndex === btn.key 
                    ? 'bg-blue-600 text-white shadow-lg' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {btn.label}
              </button>
            ))}
          </div>
        </div>
        
        {/* Current Index Display */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
          {/* Index Image */}
          <div className="text-center">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              🔬 {activeIndex.toUpperCase()} - Análise Espectral
            </h3>
            <div className="bg-gray-50 p-4 rounded-lg shadow-sm">
              <img
                src={getImageUrl(images[activeIndex])}
                alt={`Índice ${activeIndex.toUpperCase()}`}
                className="w-full max-w-sm mx-auto rounded-lg shadow-md cursor-pointer hover:scale-105 transition-transform"
                onClick={() => setSelectedImage(getImageUrl(images[activeIndex]))}
              />
              <button
                onClick={() => window.open(getImageUrl(images[activeIndex]), '_blank')}
                className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
              >
                📥 Download {activeIndex.toUpperCase()}
              </button>
            </div>
          </div>
          
          {/* Statistics */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900">📊 Estatísticas</h3>
            
            <div className="grid grid-cols-1 gap-4">
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-center">
                <div className="text-sm font-medium text-green-600 mb-1">Valor Mínimo</div>
                <div className="text-2xl font-bold text-green-900">
                  {getIndexStats(activeIndex).min}
                </div>
              </div>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-center">
                <div className="text-sm font-medium text-blue-600 mb-1">Valor Médio</div>
                <div className="text-2xl font-bold text-blue-900">
                  {getIndexStats(activeIndex).media}
                </div>
              </div>
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 text-center">
                <div className="text-sm font-medium text-orange-600 mb-1">Valor Máximo</div>
                <div className="text-2xl font-bold text-orange-900">
                  {getIndexStats(activeIndex).max}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Metadata */}
      <div className="bg-gray-50 rounded-lg p-6 mt-8">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">🌍 Metadados da Análise</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          <div>
            <span className="font-medium text-gray-600">Data:</span>
            <div className="text-gray-900">{results.metadata.data_captura}</div>
          </div>
          <div>
            <span className="font-medium text-gray-600">Satélite:</span>
            <div className="text-gray-900">{results.metadata.satelite}</div>
          </div>
          <div>
            <span className="font-medium text-gray-600">Resolução:</span>
            <div className="text-gray-900">{results.metadata.resolucao}</div>
          </div>
          <div>
            <span className="font-medium text-gray-600">Nuvens:</span>
            <div className="text-gray-900">{results.metadata.cobertura_nuvens}%</div>
          </div>
          <div>
            <span className="font-medium text-gray-600">Latitude:</span>
            <div className="text-gray-900 font-mono">{results.metadata.coordenadas[1]}</div>
          </div>
          <div>
            <span className="font-medium text-gray-600">Longitude:</span>
            <div className="text-gray-900 font-mono">{results.metadata.coordenadas[0]}</div>
          </div>
          <div>
            <span className="font-medium text-gray-600">Local:</span>
            <div className="text-gray-900">{results.metadata.localizacao}</div>
          </div>
        </div>
      </div>

      {/* Modal de imagem */}
      {selectedImage && (
        <div 
          className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedImage(null)}
        >
          <div className="max-w-4xl max-h-full overflow-auto">
            <img 
              src={selectedImage} 
              alt="Full size preview" 
              className="w-full h-auto rounded-lg shadow-2xl"
            />
          </div>
        </div>
      )}
    </div>
  )
}