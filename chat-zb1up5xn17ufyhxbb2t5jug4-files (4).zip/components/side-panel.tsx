"use client"

import { useState } from 'react'
import { AnalysisControl } from './analysis-control'
import ProgressTracker from './progress-tracker'
import { LogsViewer } from './logs-viewer'
import ResultsViewer from './results-viewer'
import { ResultsButton } from './results-button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { Badge } from '@/components/ui/badge'
import { MapPin, Activity, Eye } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { AlertCircle, CheckCircle, Clock, Download, ArrowRight } from 'lucide-react'

interface SidePanelProps {
  selectedCoordinates: { lat: number; lon: number } | null
  selectedArea?: any
  currentJob: string | null
  onJobStart: (jobId: string) => void
  analysisResults: any
  onAnalysisComplete: (results: any) => void
}

export function SidePanel({ 
  selectedCoordinates, 
  selectedArea,
  currentJob, 
  onJobStart, 
  analysisResults,
  onAnalysisComplete 
}: SidePanelProps) {
  const [showResults, setShowResults] = useState(false)

  console.log("SidePanel rendered", {
    selectedCoordinates,
    currentJob,
    analysisResults,
    showResults
  })

  const handleAnalysisComplete = (results: any) => {
    onAnalysisComplete(results)
    setShowResults(true)
  }

  if (showResults && analysisResults) {
    return (
      <div className="h-full bg-iagrosat-background">
        <div className="p-4 bg-iagrosat-surface border-b border-iagrosat-border">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-iagrosat-text">Resultados da Análise</h2>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setShowResults(false)}
              className="bg-iagrosat-surface border-iagrosat-border text-iagrosat-text hover:bg-iagrosat-muted"
            >
              Voltar
            </Button>
          </div>
        </div>
        <div className="flex-1 overflow-hidden">
          <ResultsViewer results={analysisResults} />
        </div>
      </div>
    )
  }

  return (
    <div className="h-full bg-iagrosat-background flex flex-col">
      {/* Header Simples */}
      <div className="p-4 bg-iagrosat-surface border-b border-iagrosat-border">
        <h2 className="text-lg font-semibold text-iagrosat-text">🛰️ Sistema</h2>
      </div>

      {/* Progress Tracker (quando job está ativo) */}
      {currentJob && (
        <div className="flex-1 overflow-auto p-4 border-b border-iagrosat-border">
          <ProgressTracker 
            jobId={currentJob}
          />
        </div>
      )}

      {/* Results Button (quando análise está completa) */}
      {analysisResults && !showResults && (
        <div className="p-4 border-b border-iagrosat-border">
          <ResultsButton 
            results={analysisResults}
            onViewResults={() => setShowResults(true)}
          />
        </div>
      )}

      {/* Analysis Control (quando coordenadas selecionadas mas sem job ativo) */}
      {selectedCoordinates && !currentJob && !analysisResults && (
        <div className="flex-1 overflow-auto p-4">
          <AnalysisControl
            selectedCoordinates={selectedCoordinates}
            selectedArea={selectedArea}
            onJobStart={onJobStart}
            onAnalysisComplete={handleAnalysisComplete}
          />
        </div>
      )}

      {/* Simple connection status at bottom */}
      <div className="mt-auto p-4 border-t border-iagrosat-border">
        <div className="flex items-center gap-2 text-sm text-iagrosat-muted">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          <span>Sentinel Connected</span>
        </div>
      </div>
    </div>
  )
}