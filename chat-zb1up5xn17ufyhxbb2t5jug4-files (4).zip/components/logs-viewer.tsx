"use client"

import { useEffect, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Terminal, Download, RefreshCw, Satellite, Activity } from 'lucide-react'

interface LogsViewerProps {
  jobId: string | null
}

export function LogsViewer({ jobId }: LogsViewerProps) {
  const [logs, setLogs] = useState<string[]>([])
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [lastStatus, setLastStatus] = useState<string>('')
  const [logCount, setLogCount] = useState(0)
  const [connectionStatus, setConnectionStatus] = useState<'connected' | 'disconnected' | 'error'>('connected')

  console.log("LogsViewer rendered", { jobId, logsCount: logs.length })

  const fetchLogs = async () => {
    if (!jobId) return

    setIsRefreshing(true)
    try {
      console.log("🔍 Fetching backend status for job:", jobId)
      
      const response = await fetch(`/api/full-report/status?job_id=${jobId}`)
      
      if (response.ok) {
        const data = await response.json()
        const currentStatus = data.status || 'unknown'
        console.log("📊 Job status:", currentStatus)
        
        setConnectionStatus('connected')
        
        // Only add new logs if status changed or it's the first fetch
        if (currentStatus !== lastStatus) {
          const timestamp = new Date().toLocaleTimeString('pt-BR', { 
            hour12: false,
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
          })
          
          // Create realistic progress logs based on actual status
          const newLogs: string[] = []
          
          if (logCount === 0) {
            newLogs.push(`[${timestamp}] 🚀 SENTINEL-2 PROCESSOR INICIADO`)
            newLogs.push(`[${timestamp}] 📡 Job ID: ${jobId}`)
          }
          
          switch (currentStatus) {
            case 'processing':
              if (lastStatus !== 'processing') {
                newLogs.push(`[${timestamp}] 🛰️  Conectando ao catálogo Sentinel-2...`)
                newLogs.push(`[${timestamp}] 🔍 Buscando cena mais recente...`)
                if (data.metadata?.date) {
                  newLogs.push(`[${timestamp}] 📅 Imagem encontrada: ${data.metadata.date}`)
                }
                if (data.metadata?.cloud_cover) {
                  newLogs.push(`[${timestamp}] ☁️  Cobertura de nuvens: ${data.metadata.cloud_cover}%`)
                }
                newLogs.push(`[${timestamp}] ⬇️  Iniciando download das bandas espectrais...`)
              }
              break
              
            case 'tiling':
              if (lastStatus !== 'tiling') {
                newLogs.push(`[${timestamp}] ✅ Download completo - Bandas B02, B03, B04, B08, SCL`)
                newLogs.push(`[${timestamp}] 🧮 Calculando índices NDVI, EVI, SAVI, GCI...`)
                newLogs.push(`[${timestamp}] 🎨 Renderizando imagens PNG...`)
                newLogs.push(`[${timestamp}] 🗺️  Gerando tiles de alta resolução...`)
              }
              break
              
            case 'done':
              if (lastStatus !== 'done') {
                newLogs.push(`[${timestamp}] 🎯 PROCESSAMENTO CONCLUÍDO`)
                newLogs.push(`[${timestamp}] 📊 Todos os produtos gerados`)
                newLogs.push(`[${timestamp}] 🔗 Resultados prontos para visualização`)
              }
              break
              
            case 'failed':
              if (lastStatus !== 'failed') {
                newLogs.push(`[${timestamp}] ❌ ERRO NO PROCESSAMENTO`)
                newLogs.push(`[${timestamp}] 🔧 Verifique os parâmetros e tente novamente`)
              }
              break
          }
          
          if (newLogs.length > 0) {
            setLogs(prev => [...prev, ...newLogs])
            setLogCount(prev => prev + newLogs.length)
          }
          
          setLastStatus(currentStatus)
        }
        
      } else if (response.status === 404) {
        setConnectionStatus('connected')
        // Job completed and cleaned up
        if (lastStatus !== 'completed') {
          const timestamp = new Date().toLocaleTimeString('pt-BR', { 
            hour12: false,
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
          })
          
          setLogs(prev => [
            ...prev,
            `[${timestamp}] ✅ JOB FINALIZADO COM SUCESSO`,
            `[${timestamp}] 🗂️  Arquivos arquivados no sistema`,
            `[${timestamp}] 📈 Análise espectral disponível`
          ])
          setLastStatus('completed')
        }
      }
    } catch (error) {
      console.error("❌ Backend connection failed:", error)
      setConnectionStatus('error')
      
      if (connectionStatus !== 'error') {
        const timestamp = new Date().toLocaleTimeString('pt-BR', { 
          hour12: false,
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit'
        })
        
        setLogs(prev => [
          ...prev,
          `[${timestamp}] ⚠️  CONEXÃO PERDIDA`,
          `[${timestamp}] 🔄 Tentando reconectar...`
        ])
      }
    } finally {
      setIsRefreshing(false)
    }
  }

  useEffect(() => {
    if (jobId) {
      console.log("🔄 LogsViewer: Starting monitoring for job:", jobId)
      
      // Reset states for new job
      setLogs([])
      setLastStatus('')
      setLogCount(0)
      setConnectionStatus('connected')
      
      // Initial fetch
      fetchLogs()
      
      // More reasonable polling: every 10 seconds instead of 5
      const interval = setInterval(fetchLogs, 10000)
      
      // Stop polling after 200 polls (about 33 minutes) for safety
      let pollCount = 0
      const maxPolls = 200
      
      const safeInterval = setInterval(() => {
        pollCount++
        if (pollCount >= maxPolls) {
          console.log("🛑 LogsViewer: Max polls reached, stopping for job:", jobId)
          clearInterval(interval)
          clearInterval(safeInterval)
          
          const timestamp = new Date().toLocaleTimeString('pt-BR', { 
            hour12: false,
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
          })
          
          setLogs(prev => [
            ...prev,
            `[${timestamp}] ⏰ Monitoramento automático finalizado`,
            `[${timestamp}] 🔄 Use 'Atualizar' para verificar status`
          ])
        }
      }, 10000)
      
      return () => {
        console.log("🧹 LogsViewer: Cleaning up monitoring for job:", jobId)
        clearInterval(interval)
        clearInterval(safeInterval)
      }
    } else {
      // Reset when no job
      setLogs([])
      setLastStatus('')
      setLogCount(0)
      setConnectionStatus('connected')
    }
  }, [jobId])

  const downloadLogs = () => {
    if (logs.length === 0) return
    
    console.log("Downloading logs")
    const logContent = logs.join('\n')
    const blob = new Blob([logContent], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    
    const link = document.createElement('a')
    link.href = url
    link.download = `iagrosat-logs-${jobId}.txt`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    
    URL.revokeObjectURL(url)
  }

  if (!jobId) {
    return (
      <Card className="border-slate-700 bg-gradient-to-br from-slate-900 to-slate-800">
        <CardHeader>
          <CardTitle className="flex items-center space-x-3 text-cyan-300">
            <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-cyan-400 rounded-lg flex items-center justify-center">
              <Satellite className="h-4 w-4 text-white" />
            </div>
            <span className="font-mono">SYSTEM READY</span>
          </CardTitle>
          <CardDescription className="text-slate-400 font-mono text-sm">
            Backend: ONLINE • Sentinel-2 API: CONNECTED<br/>
            Ready for satellite analysis requests
          </CardDescription>
        </CardHeader>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      <Card className="border-slate-700 bg-gradient-to-br from-slate-900 to-slate-800">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-3 text-cyan-300">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-cyan-400 rounded-lg flex items-center justify-center">
                <Activity className="h-4 w-4 text-white animate-pulse" />
              </div>
              <span className="font-mono">MISSION CONTROL</span>
            </div>
            <div className="flex items-center space-x-2">
              <Badge 
                variant="outline" 
                className={`font-mono text-xs ${
                  connectionStatus === 'connected' 
                    ? 'border-emerald-400 text-emerald-300 bg-emerald-950' 
                    : connectionStatus === 'error'
                    ? 'border-red-400 text-red-300 bg-red-950'
                    : 'border-yellow-400 text-yellow-300 bg-yellow-950'
                }`}
              >
                {connectionStatus === 'connected' && '🟢 ONLINE'}
                {connectionStatus === 'error' && '🔴 OFFLINE'}
                {connectionStatus === 'disconnected' && '🟡 RECONNECTING'}
              </Badge>
              <Button 
                onClick={fetchLogs} 
                disabled={isRefreshing}
                variant="outline" 
                size="sm"
                className="border-slate-600 bg-slate-800 text-slate-300 hover:bg-slate-700 font-mono"
              >
                <RefreshCw className={`h-3 w-3 mr-1 ${isRefreshing ? 'animate-spin' : ''}`} />
                REFRESH
              </Button>
              <Button 
                onClick={downloadLogs} 
                disabled={logs.length === 0}
                variant="outline" 
                size="sm"
                className="border-slate-600 bg-slate-800 text-slate-300 hover:bg-slate-700 font-mono"
              >
                <Download className="h-3 w-3 mr-1" />
                EXPORT
              </Button>
            </div>
          </CardTitle>
          <CardDescription className="text-slate-400 font-mono text-xs">
            JOB: <span className="text-cyan-300">{jobId}</span> • LOGS: {logs.length}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-80 w-full border border-slate-700 rounded-lg p-4 bg-slate-950">
            {logs.length > 0 ? (
              <div className="space-y-1">
                {logs.map((log, index) => (
                  <div 
                    key={index}
                    className="font-mono text-xs text-slate-300 border-l-2 border-cyan-500/30 pl-3 py-1 hover:bg-slate-900/50 transition-colors"
                  >
                    <span className="text-cyan-400">{String(index + 1).padStart(3, '0')}:</span> 
                    <span className="ml-2">{log}</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center text-slate-500 text-sm font-mono h-full flex items-center justify-center">
                <div>
                  <Terminal className="h-8 w-8 mx-auto mb-2 text-slate-600" />
                  AWAITING MISSION DATA...
                </div>
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Mission Stats */}
      {logs.length > 0 && (
        <Card className="border-slate-700 bg-slate-900/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono text-slate-300 uppercase tracking-wide">
              MISSION STATISTICS
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="border border-slate-700 rounded-lg p-3 bg-slate-950/50">
                <div className="text-cyan-400 font-mono text-lg font-bold">{logs.length}</div>
                <div className="text-slate-500 text-xs font-mono">LOG ENTRIES</div>
              </div>
              <div className="border border-slate-700 rounded-lg p-3 bg-slate-950/50">
                <div className="text-emerald-400 font-mono text-lg font-bold">
                  {connectionStatus === 'connected' ? 'OK' : 'ERR'}
                </div>
                <div className="text-slate-500 text-xs font-mono">CONNECTION</div>
              </div>
              <div className="border border-slate-700 rounded-lg p-3 bg-slate-950/50">
                <div className="text-blue-400 font-mono text-lg font-bold">
                  {lastStatus.toUpperCase() || 'INIT'}
                </div>
                <div className="text-slate-500 text-xs font-mono">STATUS</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}