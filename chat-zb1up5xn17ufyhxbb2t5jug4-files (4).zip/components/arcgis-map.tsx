'use client'

import React, { useEffect, useRef, useState } from 'react'
import { loadModules } from 'esri-loader'

interface ArcGISMapProps {
  onSelectionChange?: (selection: any) => void
  onCoordinatesChange?: (coordinates: { lat: number; lng: number }) => void
}

export default function ArcGISMap({ onSelectionChange, onCoordinatesChange }: ArcGISMapProps) {
  const mapDiv = useRef<HTMLDivElement>(null)
  const [sketch, setSketch] = useState<any>(null)
  const [view, setView] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (mapDiv.current) {
      initializeMap()
    }
    
    return () => {
      if (view) {
        view.destroy()
      }
    }
  }, [])

  const initializeMap = async () => {
    try {
      console.log('Inicializando mapa ArcGIS...')
      
      // Carregando módulos ArcGIS
      const [Map, MapView, GraphicsLayer, Sketch, Graphic] = await loadModules([
        'esri/Map',
        'esri/views/MapView',
        'esri/layers/GraphicsLayer',
        'esri/widgets/Sketch',
        'esri/Graphic'
      ])

      console.log('Módulos carregados com sucesso')

      // Criando camada de gráficos
      const graphicsLayer = new GraphicsLayer()

      // Criando mapa
      const map = new Map({
        basemap: 'satellite',
        layers: [graphicsLayer]
      })

      // Criando visualização
      const mapView = new MapView({
        container: mapDiv.current,
        map: map,
        center: [-46.6333, -23.5505], // São Paulo
        zoom: 10
      })

      console.log('Mapa criado, aguardando carregamento...')

      // Aguardando carregamento do mapa
      await mapView.when()
      console.log('Mapa carregado com sucesso')

      // Criando widget de desenho
      const sketchWidget = new Sketch({
        view: mapView,
        layer: graphicsLayer,
        creationMode: 'update'
      })

      // Eventos do sketch
      sketchWidget.on('create', (event: any) => {
        console.log('Desenho criado:', event.state)
        if (event.state === 'complete') {
          console.log('Geometria:', event.graphic.geometry)
          onSelectionChange?.(event.graphic.geometry)
        }
      })

      sketchWidget.on('update', (event: any) => {
        console.log('Desenho atualizado:', event.state)
        if (event.state === 'complete') {
          onSelectionChange?.(event.graphics[0].geometry)
        }
      })

      // Evento de clique para coordenadas
      mapView.on('click', (event: any) => {
        console.log('Clique no mapa:', event.mapPoint)
        onCoordinatesChange?.({
          lat: event.mapPoint.latitude,
          lng: event.mapPoint.longitude
        })
      })

      setView(mapView)
      setSketch(sketchWidget)
      setIsLoading(false)
      
      console.log('Mapa ArcGIS inicializado com sucesso')
    } catch (error) {
      console.error('Erro ao inicializar mapa ArcGIS:', error)
      setIsLoading(false)
    }
  }

  // Funções para controlar ferramentas
  const activatePolygonTool = () => {
    if (sketch) {
      console.log('Ativando ferramenta de polígono')
      sketch.create('polygon')
    }
  }

  const activateRectangleTool = () => {
    if (sketch) {
      console.log('Ativando ferramenta de retângulo')
      sketch.create('rectangle')
    }
  }

  const activatePointTool = () => {
    if (sketch) {
      console.log('Ativando ferramenta de ponto')
      sketch.create('point')
    }
  }

  const clearSelection = () => {
    if (sketch && sketch.layer) {
      console.log('Limpando seleção')
      sketch.layer.removeAll()
    }
  }

  // Expondo funções para componente pai
  useEffect(() => {
    if (window && sketch) {
      (window as any).arcgisTools = {
        activatePolygonTool,
        activateRectangleTool,
        activatePointTool,
        clearSelection
      }
    }
  }, [sketch])

  return (
    <div className="relative w-full h-full">
      <div 
        ref={mapDiv} 
        className="w-full h-full"
        style={{ minHeight: '400px' }}
      />
      
      {isLoading && (
        <div className="absolute inset-0 bg-slate-600 bg-opacity-75 flex items-center justify-center">
          <div className="text-center">
            <div className="w-16 h-16 bg-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
              <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                <path d="M13 7 9 3 5 7l4 4"></path>
                <path d="m17 11 4 4-4 4-4-4"></path>
                <path d="m8 12 4 4 6-6-4-4Z"></path>
                <path d="m16 8 3-3"></path>
                <path d="M9 21a6 6 0 0 0-6-6"></path>
              </svg>
            </div>
            <h2 className="text-xl font-bold text-white mb-2">Carregando Mapa Satelital</h2>
            <p className="text-slate-300">Conectando com ArcGIS...</p>
          </div>
        </div>
      )}
    </div>
  )
}