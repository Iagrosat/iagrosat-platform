"use client"

import { Button } from '@/components/ui/button'
import { Eye, Download, ExternalLink } from 'lucide-react'
import { Card } from '@/components/ui/card'

interface ResultsButtonProps {
  onViewResults: () => void
  results: any
}

export function ResultsButton({ onViewResults, results }: ResultsButtonProps) {
  if (!results) return null

  return (
    <Card className="p-4 bg-gradient-to-r from-iagrosat-secondary/20 to-iagrosat-primary/20 border-iagrosat-secondary border-2 animate-pulse-soft">
      <div className="text-center space-y-3">
        <div className="text-lg font-bold text-iagrosat-secondary">
          ✅ Análise Concluída!
        </div>
        
        <div className="text-sm text-iagrosat-text">
          Todos os índices espectrais foram calculados com sucesso
        </div>
        
        <Button 
          onClick={onViewResults}
          className="w-full bg-iagrosat-secondary hover:bg-iagrosat-primary text-white font-semibold py-3 px-6 animate-bounce-gentle"
          size="lg"
        >
          <Eye className="h-5 w-5 mr-2" />
          Ver Resultados
        </Button>
        
        <div className="flex justify-center space-x-2 text-xs text-iagrosat-muted">
          <span>RGB</span>
          <span>•</span>
          <span>NDVI</span>
          <span>•</span>
          <span>EVI</span>
          <span>•</span>
          <span>SAVI</span>
          <span>•</span>
          <span>GCI</span>
        </div>
      </div>
    </Card>
  )
}