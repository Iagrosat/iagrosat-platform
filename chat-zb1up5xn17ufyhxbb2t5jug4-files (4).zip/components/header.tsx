"use client"

import { Satellite, Activity, Database, Wifi, Shield } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import Link from 'next/link'

export function Header() {
  console.log("Header component rendered")
  
  return (
    <header className="bg-iagrosat-surface border-b border-iagrosat-border px-6 py-4 shadow-lg">
      <div className="flex items-center justify-between animate-fade-in-up">
        <div className="flex items-center space-x-3">
          <div className="relative">
            <div className="w-12 h-12 bg-gradient-to-r from-iagrosat-primary to-iagrosat-secondary rounded-xl flex items-center justify-center shadow-xl hover:shadow-2xl transition-all duration-500">
              <Satellite className="h-7 w-7 text-white animate-spin" style={{ animationDuration: '8s' }} />
            </div>
            <div className="absolute -top-1 -right-1 w-4 h-4 bg-iagrosat-accent rounded-full animate-ping"></div>
            <div className="absolute top-1 right-1 w-2 h-2 bg-iagrosat-accent rounded-full"></div>
          </div>
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-iagrosat-primary to-iagrosat-accent bg-clip-text text-transparent">
              iAgroSat
            </h1>
            <p className="text-sm text-iagrosat-text font-medium">Sistema Elite de Análise Satelital</p>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <Badge className="bg-iagrosat-success/20 text-iagrosat-success border-iagrosat-success/30 animate-pulse">
              <Activity className="h-3 w-3 mr-1" />
              Sistema Operacional
            </Badge>
            <Badge className="bg-iagrosat-primary/20 text-iagrosat-primary border-iagrosat-primary/30">
              <Database className="h-3 w-3 mr-1" />
              Análise Satelital Avançada
            </Badge>
          </div>
          
          <Link href="/enterprise">
            <Button 
              variant="outline" 
              size="sm" 
              className="bg-gradient-to-r from-blue-600 to-purple-600 border-blue-500 text-white hover:from-blue-700 hover:to-purple-700 transition-all duration-300 shadow-lg hover:shadow-xl"
            >
              <Shield className="h-4 w-4 mr-2" />
              Enterprise
            </Button>
          </Link>
          
          <div className="text-right">
            <div className="text-xs text-iagrosat-muted font-mono">Backend API: 3.131.130.131:8000</div>
            <div className="flex items-center space-x-1 text-xs text-iagrosat-success">
              <Wifi className="h-3 w-3 animate-pulse" />
              <span>Análise de vegetação em tempo real</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}