"use client"

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface ImageLoaderProps {
  src: string
  alt: string
  className?: string
  onClick?: () => void
}

export default function ImageLoader({ src, alt, className, onClick }: ImageLoaderProps) {
  const [currentSrc, setCurrentSrc] = useState(src)
  const [error, setError] = useState<string | boolean | null>(null)
  const [loading, setLoading] = useState(true)
  const [imageSize, setImageSize] = useState<string>('')

  useEffect(() => {
    setCurrentSrc(src)
    const loadImageAsync = async () => {
      try {
        setLoading(true)
        setError(null)
        console.log("📡 Loading ORIGINAL TIFF image:", src)
        
        // PRIORITY 1: Check TIFF original file (HIGHEST QUALITY)
        const response = await fetch(src, { method: 'HEAD' })
        if (response.ok) {
          const contentLength = response.headers.get('content-length')
          if (contentLength) {
            const sizeInMB = (parseInt(contentLength) / (1024 * 1024)).toFixed(1)
            setImageSize(`${sizeInMB}MB ORIGINAL`)
            console.log("✅ TIFF original found:", sizeInMB + "MB")
          }
          setCurrentSrc(src)
        } else {
          console.log("⚠️ TIFF not found, trying PNG fallback...")
          // FALLBACK: Try PNG version (lower quality, processed)
          const pngSrc = src.replace('.tif', '.png')
          const pngResponse = await fetch(pngSrc, { method: 'HEAD' })
          if (pngResponse.ok) {
            const contentLength = pngResponse.headers.get('content-length')
            if (contentLength) {
              const sizeInMB = (parseInt(contentLength) / (1024 * 1024)).toFixed(1)
              setImageSize(`${sizeInMB}MB PNG`)
              console.log("📷 PNG fallback found:", sizeInMB + "MB")
            }
            setCurrentSrc(pngSrc)
          } else {
            console.log("❌ No images found for:", src)
            setError("Image not found")
          }
        }
      } catch (err) {
        console.error('❌ Error loading image:', err)
        setError("Error loading image")
      } finally {
        setLoading(false)
      }
    }
    
    loadImageAsync()
  }, [src])
  
  return (
    <img 
      src={currentSrc} 
      alt={alt}
      className={className}
      onClick={onClick}
      onError={() => setError("Failed to load image")}
      onLoad={() => setLoading(false)}
    />
  )
}