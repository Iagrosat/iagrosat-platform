"use client";

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  Shield, 
  Search, 
  Filter, 
  Download, 
  Calendar,
  User,
  Activity,
  AlertCircle,
  CheckCircle,
  Clock,
  MapPin
} from 'lucide-react';

export function AuditViewer() {
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [filteredLogs, setFilteredLogs] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('all');

  // Mock audit logs
  useEffect(() => {
    const mockLogs = [
      {
        id: '1',
        timestamp: '2024-07-04T17:30:00Z',
        userId: '2',
        userName: 'Carlos Silva',
        action: 'ANALYSIS_STARTED',
        resource: 'Analysis Job',
        details: {
          jobId: '435cb5f4',
          coordinates: { lat: -23.5505, lon: -46.6333 },
          location: 'São Paulo, SP'
        },
        ip: '192.168.1.100',
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        severity: 'info'
      },
      {
        id: '2',
        timestamp: '2024-07-04T17:25:00Z',
        userId: '3',
        userName: 'Ana Santos',
        action: 'ANALYSIS_EXPORTED',
        resource: 'Analysis Results',
        details: {
          jobId: '226653f4',
          format: 'PDF',
          size: '2.4 MB'
        },
        ip: '192.168.1.101',
        userAgent: 'Mozilla/5.0 (macOS; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
        severity: 'info'
      },
      {
        id: '3',
        timestamp: '2024-07-04T17:20:00Z',
        userId: '1',
        userName: 'Admin Principal',
        action: 'USER_LOGIN',
        resource: 'Authentication',
        details: {
          loginMethod: 'password',
          success: true
        },
        ip: '192.168.1.102',
        userAgent: 'Mozilla/5.0 (Ubuntu; Linux x86_64) AppleWebKit/537.36',
        severity: 'info'
      },
      {
        id: '4',
        timestamp: '2024-07-04T17:15:00Z',
        userId: '4',
        userName: 'João Oliveira',
        action: 'ACCESS_DENIED',
        resource: 'User Management',
        details: {
          attemptedAction: 'DELETE_USER',
          reason: 'Insufficient permissions'
        },
        ip: '192.168.1.103',
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        severity: 'warning'
      },
      {
        id: '5',
        timestamp: '2024-07-04T17:10:00Z',
        userId: '2',
        userName: 'Carlos Silva',
        action: 'ANALYSIS_COMPLETED',
        resource: 'Analysis Job',
        details: {
          jobId: '1409ea08',
          processingTime: '3.2 min',
          success: true
        },
        ip: '192.168.1.100',
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        severity: 'info'
      }
    ];
    
    setAuditLogs(mockLogs);
    setFilteredLogs(mockLogs);
  }, []);

  useEffect(() => {
    let filtered = auditLogs;

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(log =>
        log.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.resource.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Apply severity filter
    if (selectedFilter !== 'all') {
      filtered = filtered.filter(log => log.severity === selectedFilter);
    }

    setFilteredLogs(filtered);
  }, [auditLogs, searchTerm, selectedFilter]);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'info': return 'bg-blue-500';
      case 'warning': return 'bg-yellow-500';
      case 'error': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'info': return CheckCircle;
      case 'warning': return AlertCircle;
      case 'error': return AlertCircle;
      default: return Activity;
    }
  };

  const getActionIcon = (action: string) => {
    if (action.includes('ANALYSIS')) return MapPin;
    if (action.includes('USER') || action.includes('LOGIN')) return User;
    if (action.includes('ACCESS')) return Shield;
    return Activity;
  };

  const exportAuditLogs = () => {
    console.log('📤 Exporting audit logs...');
    // In real app, trigger CSV/PDF export
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Auditoria de Segurança</h1>
          <p className="text-slate-400">Monitoramento de atividades e logs de segurança</p>
        </div>
        <Button onClick={exportAuditLogs} className="bg-green-600 hover:bg-green-700">
          <Download className="w-4 h-4 mr-2" />
          Exportar Logs
        </Button>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
          <Input
            placeholder="Buscar por usuário, ação ou recurso..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-slate-800/50 border-slate-600 text-white"
          />
        </div>
        
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-400" />
          <Button
            variant={selectedFilter === 'all' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedFilter('all')}
          >
            Todos
          </Button>
          <Button
            variant={selectedFilter === 'info' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedFilter('info')}
          >
            Info
          </Button>
          <Button
            variant={selectedFilter === 'warning' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedFilter('warning')}
          >
            Aviso
          </Button>
          <Button
            variant={selectedFilter === 'error' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedFilter('error')}
          >
            Erro
          </Button>
        </div>
      </div>

      {/* Audit Logs */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Shield className="w-5 h-5" />
            Logs de Auditoria
            <Badge variant="outline" className="text-slate-300 border-slate-600">
              {filteredLogs.length} registros
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {filteredLogs.map((log) => {
              const SeverityIcon = getSeverityIcon(log.severity);
              const ActionIcon = getActionIcon(log.action);
              
              return (
                <div
                  key={log.id}
                  className="flex items-start gap-4 p-4 bg-slate-900/30 rounded-lg hover:bg-slate-900/50 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <div className={`w-3 h-3 ${getSeverityColor(log.severity)} rounded-full`}></div>
                    <ActionIcon className="w-4 h-4 text-slate-400" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-medium text-white">{log.action}</p>
                      <Badge variant="outline" className="text-xs border-slate-600 text-slate-400">
                        {log.resource}
                      </Badge>
                    </div>
                    
                    <div className="flex items-center gap-4 text-sm text-slate-400 mb-2">
                      <span className="flex items-center gap-1">
                        <User className="w-3 h-3" />
                        {log.userName}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {new Date(log.timestamp).toLocaleString('pt-BR')}
                      </span>
                      <span className="flex items-center gap-1">
                        <Activity className="w-3 h-3" />
                        {log.ip}
                      </span>
                    </div>
                    
                    {log.details && (
                      <div className="text-xs text-slate-500 bg-slate-900/50 p-2 rounded">
                        <pre className="font-mono">
                          {JSON.stringify(log.details, null, 2)}
                        </pre>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <SeverityIcon className="w-4 h-4 text-slate-400" />
                    <Badge
                      variant="outline"
                      className={`text-xs border-slate-600 ${
                        log.severity === 'warning' ? 'text-yellow-400' :
                        log.severity === 'error' ? 'text-red-400' :
                        'text-slate-400'
                      }`}
                    >
                      {log.severity}
                    </Badge>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}