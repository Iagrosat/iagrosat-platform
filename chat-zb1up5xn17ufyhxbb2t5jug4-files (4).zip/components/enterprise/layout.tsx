"use client";

import { useState, ReactNode } from 'react';
import { useAuth } from '@/contexts/auth-context';
import { useRouter, usePathname } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  LayoutDashboard, 
  MapPin, 
  Users, 
  Settings, 
  Shield, 
  BarChart3, 
  FileText, 
  LogOut,
  Menu,
  X,
  Bell,
  Search,
  HelpCircle,
  ChevronDown
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Permission } from '@/types/auth';

interface EnterpriseLayoutProps {
  children: ReactNode;
}

export function EnterpriseLayout({ children }: EnterpriseLayoutProps) {
  const { user, logout, hasPermission } = useAuth();
  const router = useRouter();
  const pathname = usePathname();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const navigation = [
    {
      name: 'Dashboard',
      href: '/enterprise',
      icon: LayoutDashboard,
      id: 'dashboard',
      permission: null
    },
    {
      name: 'Análise Satelital',
      href: '/enterprise/analysis',
      icon: MapPin,
      id: 'analysis',
      permission: Permission.CREATE_ANALYSIS
    },
    {
      name: 'Relatórios',
      href: '/enterprise/reports',
      icon: FileText,
      id: 'reports',
      permission: Permission.VIEW_ANALYSIS
    },
    {
      name: 'Usuários',
      href: '/enterprise/users',
      icon: Users,
      id: 'users',
      permission: Permission.VIEW_USERS
    },
    {
      name: 'Auditoria',
      href: '/enterprise/audit',
      icon: Shield,
      id: 'audit',
      permission: Permission.VIEW_AUDIT_LOGS
    },
    {
      name: 'Configurações',
      href: '/enterprise/settings',
      icon: Settings,
      id: 'settings',
      permission: Permission.MANAGE_SETTINGS
    }
  ];

  const filteredNavigation = navigation.filter(item => 
    !item.permission || hasPermission(item.permission)
  );

  const isActive = (href: string) => {
    if (href === '/enterprise') {
      return pathname === '/enterprise';
    }
    return pathname.startsWith(href);
  };

  return (
    <div className="min-h-screen bg-slate-900 flex">
      {/* Sidebar */}
      <div className={cn(
        "fixed inset-y-0 left-0 z-50 w-64 bg-slate-800 border-r border-slate-700 transform transition-transform duration-300 ease-in-out",
        sidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="flex items-center justify-between p-4 border-b border-slate-700">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-green-400 to-blue-500 rounded-lg flex items-center justify-center">
                <div className="text-white font-bold text-sm">iA</div>
              </div>
              <div>
                <h1 className="text-lg font-bold text-white">iAgroSat</h1>
                <p className="text-xs text-slate-400">Enterprise</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSidebarOpen(false)}
              className="text-slate-400 hover:text-white lg:hidden"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-4 space-y-2">
            {filteredNavigation.map((item) => (
              <Button
                key={item.id}
                variant={isActive(item.href) ? "default" : "ghost"}
                className={cn(
                  "w-full justify-start gap-2 transition-colors",
                  isActive(item.href)
                    ? "bg-gradient-to-r from-green-600 to-blue-600 text-white" 
                    : "text-slate-300 hover:text-white hover:bg-slate-700"
                )}
                onClick={() => router.push(item.href)}
              >
                <item.icon className="w-4 h-4" />
                {item.name}
              </Button>
            ))}
          </nav>

          {/* User Info */}
          <div className="p-4 border-t border-slate-700">
            <div className="flex items-center gap-3">
              <Avatar className="w-10 h-10">
                <AvatarImage src={user?.avatar} />
                <AvatarFallback>{user?.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-white truncate">{user?.name}</p>
                <p className="text-xs text-slate-400 truncate">{user?.email}</p>
                <Badge variant="outline" className="text-xs border-slate-600 text-slate-400 mt-1">
                  {user?.role}
                </Badge>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={logout}
              className="w-full mt-3 text-slate-400 hover:text-red-400 justify-start gap-2"
            >
              <LogOut className="w-4 h-4" />
              Sair
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className={cn(
        "flex-1 transition-all duration-300",
        sidebarOpen ? "ml-64" : "ml-0"
      )}>
        {/* Top Bar */}
        <header className="bg-slate-800/50 border-b border-slate-700 p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="text-slate-400 hover:text-white"
              >
                <Menu className="w-4 h-4" />
              </Button>
              <div className="hidden md:flex items-center gap-2">
                <Search className="w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Buscar análises, usuários, relatórios..."
                  className="bg-slate-900/50 border border-slate-600 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-400 focus:outline-none focus:border-blue-500 w-80"
                />
              </div>
            </div>

            <div className="flex items-center gap-4">
              <Badge variant="outline" className="border-green-500 text-green-400">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                Sistema Online
              </Badge>
              
              <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                <Bell className="w-4 h-4" />
              </Button>
              
              <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                <HelpCircle className="w-4 h-4" />
              </Button>

              <div className="flex items-center gap-2">
                <div className="text-right">
                  <p className="text-sm font-medium text-white">{user?.name}</p>
                  <p className="text-xs text-slate-400">{user?.company}</p>
                </div>
                <Avatar className="w-8 h-8">
                  <AvatarImage src={user?.avatar} />
                  <AvatarFallback>{user?.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                </Avatar>
                <ChevronDown className="w-4 h-4 text-slate-400" />
              </div>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-auto">
          {children}
        </main>
      </div>

      {/* Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/20 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
}