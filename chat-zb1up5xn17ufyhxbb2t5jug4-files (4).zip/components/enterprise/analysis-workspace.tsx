"use client";

import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/auth-context';
import { MapContainer } from '@/components/map-container';
import { SidePanel } from '@/components/side-panel';
import { GlobalJobMonitor } from '@/components/global-job-monitor';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  MapPin, 
  Clock, 
  Download, 
  Share2, 
  Archive,
  CheckCircle,
  AlertCircle,
  History
} from 'lucide-react';
import { Permission } from '@/types/auth';

export function AnalysisWorkspace() {
  const { user, hasPermission } = useAuth();
  const [selectedCoordinates, setSelectedCoordinates] = useState<{lat: number, lon: number} | null>(null);
  const [selectedArea, setSelectedArea] = useState<any>(null);
  const [currentJob, setCurrentJob] = useState<string | null>(null);
  const [analysisResults, setAnalysisResults] = useState<any>(null);
  const [isAnalysisComplete, setIsAnalysisComplete] = useState(false);
  const [completedJobs, setCompletedJobs] = useState<string[]>([]);
  const [analysisHistory, setAnalysisHistory] = useState<any[]>([]);

  // Enterprise audit logging
  const logAnalysisEvent = (action: string, details: any) => {
    const auditEntry = {
      timestamp: new Date().toISOString(),
      userId: user?.id,
      userName: user?.name,
      action,
      details,
      ip: '127.0.0.1' // In real app, get from request
    };
    
    console.log('🔍 ENTERPRISE AUDIT LOG:', auditEntry);
    
    // In real app, send to audit service
    // auditService.log(auditEntry);
  };

  const handleJobComplete = (jobId: string) => {
    console.log('🎉 ENTERPRISE: Job completed - redirecting:', jobId);
    logAnalysisEvent('ANALYSIS_COMPLETED', { jobId });
    
    // Add to history
    setAnalysisHistory(prev => [{
      id: jobId,
      timestamp: new Date().toISOString(),
      user: user?.name,
      coordinates: selectedCoordinates,
      area: selectedArea,
      status: 'completed'
    }, ...prev]);
    
    window.location.href = `/results/${jobId}`;
  };

  const handleJobStart = (jobId: string) => {
    console.log('🚀 ENTERPRISE: New job started:', jobId);
    logAnalysisEvent('ANALYSIS_STARTED', { 
      jobId, 
      coordinates: selectedCoordinates,
      area: selectedArea 
    });
    
    setCurrentJob(jobId);
    setIsAnalysisComplete(false);
    setAnalysisResults(null);
    localStorage.clear();
    sessionStorage.clear();
  };

  const exportAnalysis = (jobId: string) => {
    if (!hasPermission(Permission.EXPORT_ANALYSIS)) {
      console.warn('User does not have export permission');
      return;
    }
    
    logAnalysisEvent('ANALYSIS_EXPORTED', { jobId });
    console.log('📤 Exporting analysis:', jobId);
    // In real app, trigger export
  };

  const shareAnalysis = (jobId: string) => {
    logAnalysisEvent('ANALYSIS_SHARED', { jobId });
    console.log('🔗 Sharing analysis:', jobId);
    // In real app, generate share link
  };

  const archiveAnalysis = (jobId: string) => {
    if (!hasPermission(Permission.DELETE_ANALYSIS)) {
      console.warn('User does not have delete permission');
      return;
    }
    
    logAnalysisEvent('ANALYSIS_ARCHIVED', { jobId });
    console.log('🗄️ Archiving analysis:', jobId);
    // In real app, archive analysis
  };

  const handleCoordinateSelect = (coordinates: { lat: number; lon: number; address: string }) => {
    console.log('Enterprise: Coordinates selected:', coordinates);
    setSelectedCoordinates({ lat: coordinates.lat, lon: coordinates.lon });
    logAnalysisEvent('COORDINATES_SELECTED', { coordinates });
  };

  const handleAreaSelect = (area: any) => {
    console.log('Enterprise: Area selected:', area);
    setSelectedArea(area);
    logAnalysisEvent('AREA_SELECTED', { area });
  };

  return (
    <div className="h-screen flex flex-col bg-slate-900">
      {/* Enterprise Header */}
      <div className="bg-slate-800/50 border-b border-slate-700 p-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-white">Workspace de Análise</h1>
            <p className="text-sm text-slate-400">
              Análise espectral de satélites Sentinel-2 • Usuário: {user?.name} ({user?.role})
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="border-green-500 text-green-400">
              <CheckCircle className="w-3 h-3 mr-1" />
              Sistema Operacional
            </Badge>
            {currentJob && (
              <Badge variant="outline" className="border-blue-500 text-blue-400">
                <Clock className="w-3 h-3 mr-1" />
                Processando: {currentJob}
              </Badge>
            )}
          </div>
        </div>
      </div>

      {/* Global Job Monitor */}
      <GlobalJobMonitor 
        onJobCompleted={(jobId: string) => {
          console.log("🎉 ENTERPRISE GLOBAL: Job completed detected:", jobId);
          
          if (currentJob === jobId) {
            console.log("✅ Current job completed - REDIRECTING");
            handleJobComplete(jobId);
          } else {
            console.log("ℹ️ Different job completed, adding to list");
            if (!completedJobs.includes(jobId)) {
              setCompletedJobs(prev => [...prev, jobId]);
            }
          }
        }}
      />

      <div className="flex-1 flex">
        {/* Map Container - 65% */}
        <div className="w-[65%] relative">
          <MapContainer 
            onCoordinateSelect={handleCoordinateSelect}
            onAreaSelect={handleAreaSelect}
          />
        </div>

        {/* Right Panel - 35% */}
        <div className="w-[35%] border-l border-slate-700 bg-slate-800/30">
          <Tabs defaultValue="analysis" className="h-full flex flex-col">
            <TabsList className="bg-slate-800/50 border-b border-slate-700 rounded-none">
              <TabsTrigger value="analysis">Análise</TabsTrigger>
              <TabsTrigger value="history">Histórico</TabsTrigger>
              <TabsTrigger value="completed">Concluídas</TabsTrigger>
            </TabsList>

            <TabsContent value="analysis" className="flex-1 overflow-auto">
              <SidePanel 
                selectedCoordinates={selectedCoordinates}
                selectedArea={selectedArea}
                currentJob={currentJob}
                onJobStart={setCurrentJob}
                analysisResults={analysisResults}
                onAnalysisComplete={(results) => {
                  console.log("✅ Enterprise analysis completed:", results);
                  setAnalysisResults(results);
                  setIsAnalysisComplete(true);
                  
                  if (currentJob) {
                    handleJobComplete(currentJob);
                  }
                }}
              />
            </TabsContent>

            <TabsContent value="history" className="flex-1 overflow-auto p-4">
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white text-sm flex items-center gap-2">
                    <History className="w-4 h-4" />
                    Histórico de Análises
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {analysisHistory.length === 0 ? (
                    <p className="text-slate-400 text-sm">Nenhuma análise no histórico</p>
                  ) : (
                    <div className="space-y-3">
                      {analysisHistory.map((analysis) => (
                        <div key={analysis.id} className="bg-slate-900/50 p-3 rounded-lg">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-sm font-medium text-white">{analysis.id}</p>
                              <p className="text-xs text-slate-400">
                                {new Date(analysis.timestamp).toLocaleString('pt-BR')}
                              </p>
                            </div>
                            <div className="flex gap-1">
                              {hasPermission(Permission.EXPORT_ANALYSIS) && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => exportAnalysis(analysis.id)}
                                  className="text-slate-400 hover:text-white"
                                >
                                  <Download className="w-3 h-3" />
                                </Button>
                              )}
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => shareAnalysis(analysis.id)}
                                className="text-slate-400 hover:text-white"
                              >
                                <Share2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="completed" className="flex-1 overflow-auto p-4">
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white text-sm flex items-center gap-2">
                    <CheckCircle className="w-4 h-4" />
                    Análises Concluídas
                    <Badge variant="outline" className="text-slate-300 border-slate-600">
                      {completedJobs.length}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {completedJobs.length === 0 ? (
                    <p className="text-slate-400 text-sm">Nenhuma análise concluída</p>
                  ) : (
                    <div className="space-y-2">
                      {completedJobs.map((jobId) => (
                        <div key={jobId} className="flex items-center justify-between bg-slate-900/50 p-2 rounded">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-slate-300 hover:text-white justify-start font-mono text-xs"
                            onClick={() => {
                              console.log('🔗 Enterprise: Opening results for job:', jobId);
                              logAnalysisEvent('RESULTS_VIEWED', { jobId });
                              window.open(`/results/${jobId}`, '_blank');
                            }}
                          >
                            {jobId}
                          </Button>
                          <div className="flex gap-1">
                            {hasPermission(Permission.EXPORT_ANALYSIS) && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => exportAnalysis(jobId)}
                                className="text-slate-400 hover:text-white"
                              >
                                <Download className="w-3 h-3" />
                              </Button>
                            )}
                            {hasPermission(Permission.DELETE_ANALYSIS) && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => archiveAnalysis(jobId)}
                                className="text-slate-400 hover:text-red-400"
                              >
                                <Archive className="w-3 h-3" />
                              </Button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}