'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { MapContainer } from '@/components/map-container'

export default function DesignV1Compacto() {
  const [searchQuery, setSearchQuery] = useState('')
  const [currentCoordinates, setCurrentCoordinates] = useState({ lat: -23.5505, lng: -46.6333 })
  const [selectedTool, setSelectedTool] = useState<string | null>(null)
  const [selectedArea, setSelectedArea] = useState({ points: 1, area: 0.25 })
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleSearch = async () => {
    const query = searchQuery.trim()
    if (!query) return

    console.log("🔍 Buscando por:", query)
    
    try {
      // Detecta coordenadas (lat,lng)
      const coordMatch = query.match(/(-?\d+\.?\d*),?\s*(-?\d+\.?\d*)/)
      if (coordMatch) {
        const lat = parseFloat(coordMatch[1])
        const lng = parseFloat(coordMatch[2])
        console.log("📍 Coordenadas detectadas:", lat, lng)
        setCurrentCoordinates({ lat, lng })
        return
      }
      
      // Busca cidade via ESRI
      const geocodeUrl = `https://geocode-api.arcgis.com/arcgis/rest/services/World/GeocodeServer/findAddressCandidates?singleLine=${encodeURIComponent(query)}&maxLocations=1&outFields=*&f=json`
      
      const response = await fetch(geocodeUrl)
      const data = await response.json()
      
      if (data.candidates && data.candidates.length > 0) {
        const result = data.candidates[0]
        const lat = result.location.y
        const lng = result.location.x
        
        console.log("🌍 Local encontrado:", result.address, "em", lat, lng)
        setCurrentCoordinates({ lat, lng })
      } else {
        alert('Local não encontrado. Tente outro nome.')
      }
    } catch (error) {
      console.error('Erro na busca:', error)
      alert('Erro na busca. Tente novamente.')
    }
  }

  const processAnalysis = () => {
    console.log("🚀 Iniciando análise")
    setIsLoading(true)
    const jobId = `job-${Date.now()}`
    router.push(`/results/${jobId}`)
  }

  const clearSelection = () => {
    setSelectedArea({ points: 1, area: 0.25 })
    setSelectedTool(null)
  }

  return (
    <div className="h-screen bg-gradient-to-br from-emerald-900 via-slate-800 to-green-900 flex flex-col">
      {/* Header Compacto */}
      <header className="bg-slate-900/90 backdrop-blur-md border-b border-emerald-500/30 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-gradient-to-br from-emerald-400 to-amber-400 rounded-full flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
              <path d="M13 7 9 3 5 7l4 4"></path>
              <path d="m17 11 4 4-4 4-4-4"></path>
              <path d="m8 12 4 4 6-6-4-4Z"></path>
            </svg>
          </div>
          <div>
            <h1 className="text-xl font-bold text-white">iAgroSat</h1>
            <p className="text-emerald-300 text-xs">ANÁLISE SATELITAL</p>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <span className="text-green-400 text-sm">● BACKEND ATIVO</span>
          <span className="text-amber-400 text-sm">● SENTINEL ATIVO</span>
        </div>
      </header>

      {/* Conteúdo Principal */}
      <div className="flex flex-1 overflow-hidden">
        {/* Painel Lateral Compacto */}
        <div className="w-72 bg-slate-900/90 backdrop-blur-md border-r border-emerald-500/30 flex flex-col">
          <div className="p-4 flex-1 space-y-4">
            
            {/* Busca */}
            <div>
              <h3 className="text-emerald-400 mb-2 text-sm font-bold">🔍 LOCALIZAÇÃO</h3>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Digite cidade ou endereço"
                className="w-full px-3 py-2 bg-slate-800 text-white border border-emerald-500/30 rounded text-sm"
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              />
              <button 
                onClick={handleSearch}
                className="w-full mt-2 bg-gradient-to-r from-emerald-600 to-amber-600 text-white py-2 font-bold text-sm rounded hover:from-emerald-700 hover:to-amber-700"
              >
                BUSCAR
              </button>
            </div>

            {/* Coordenadas */}
            <div>
              <h3 className="text-emerald-400 mb-2 text-sm font-bold">📍 COORDENADAS</h3>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="number"
                  placeholder="Latitude"
                  value={currentCoordinates.lat}
                  onChange={(e) => setCurrentCoordinates(prev => ({ ...prev, lat: parseFloat(e.target.value) || 0 }))}
                  className="px-2 py-1 bg-slate-800 text-white border border-emerald-500/30 rounded text-sm"
                />
                <input
                  type="number"
                  placeholder="Longitude"
                  value={currentCoordinates.lng}
                  onChange={(e) => setCurrentCoordinates(prev => ({ ...prev, lng: parseFloat(e.target.value) || 0 }))}
                  className="px-2 py-1 bg-slate-800 text-white border border-emerald-500/30 rounded text-sm"
                />
              </div>
              <button 
                onClick={() => console.log("Indo para coordenadas")}
                className="w-full mt-2 bg-gradient-to-r from-amber-600 to-emerald-600 text-white py-2 font-bold text-sm rounded hover:from-amber-700 hover:to-emerald-700"
              >
                IR
              </button>
            </div>

            {/* Seleção Ativa */}
            <div>
              <h3 className="text-emerald-400 mb-2 text-sm font-bold">🎯 SELEÇÃO ATIVA</h3>
              <div className="bg-slate-800/60 border border-emerald-500/30 rounded p-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-300">Pontos:</span>
                  <span className="text-emerald-400 font-bold">{selectedArea.points}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-300">Área:</span>
                  <span className="text-emerald-400 font-bold">{selectedArea.area.toFixed(2)} km²</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-300">Ferramenta:</span>
                  <span className="text-emerald-400 font-bold">{selectedTool?.toUpperCase() || 'NENHUMA'}</span>
                </div>
              </div>
            </div>

            {/* Botões */}
            <div className="space-y-2">
              <button 
                onClick={processAnalysis}
                className="w-full bg-gradient-to-r from-emerald-600 to-green-600 text-white py-3 font-bold text-sm rounded hover:from-emerald-700 hover:to-green-700"
              >
                PROCESSAR ANÁLISE
              </button>
              <button 
                onClick={clearSelection}
                className="w-full bg-gradient-to-r from-red-600 to-red-700 text-white py-2 font-bold text-sm rounded hover:from-red-700 hover:to-red-800"
              >
                LIMPAR SELEÇÃO
              </button>
            </div>
          </div>
        </div>

        {/* Mapa */}
        <div className="flex-1 relative">
          <MapContainer
            onCoordinateSelect={(coords) => {
              setCurrentCoordinates({ lat: coords.lat, lng: coords.lon })
            }}
            onAreaSelect={(area) => {
              setSelectedArea({ points: 1, area: area.area ? area.area / 1000000 : 0.25 })
            }}
            onAnalysisStart={processAnalysis}
            onToolActivated={setSelectedTool}
          />
          
          {/* Ferramentas do Mapa */}
          <div className="absolute top-4 right-4 flex flex-col space-y-2 z-50">
            <button className="w-10 h-10 bg-slate-900/90 border border-emerald-500/30 rounded flex items-center justify-center text-white hover:bg-slate-800/90">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect width="18" height="18" x="3" y="3" rx="2"/>
              </svg>
            </button>
            <button className="w-10 h-10 bg-slate-900/90 border border-emerald-500/30 rounded flex items-center justify-center text-white hover:bg-slate-800/90">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                <circle cx="12" cy="10" r="3"/>
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-slate-900/90 backdrop-blur-md border-t border-emerald-500/30 px-4 py-2 text-center">
        <span className="text-slate-300 text-sm">iAgroSat © 2024 - Powered by Sentinel-2</span>
      </footer>
    </div>
  )
}