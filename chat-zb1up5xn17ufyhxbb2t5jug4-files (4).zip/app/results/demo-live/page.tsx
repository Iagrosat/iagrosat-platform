'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { ArrowLeft } from 'lucide-react'
import ProgressTracker from '@/components/progress-tracker'
import { LogsViewer } from '@/components/logs-viewer'

export default function DemoLivePage() {
  const router = useRouter()
  const [jobId, setJobId] = useState<string>('demo-live-simulation')

  // Simulate processing status changes
  useEffect(() => {
    const simulateProcessing = async () => {
      // Simulate backend responses
      let step = 0
      const statuses = ['processing', 'processing', 'processing', 'tiling', 'tiling', 'done']
      
      const interval = setInterval(() => {
        if (step < statuses.length) {
          // Create a mock response to trigger logs
          const mockEvent = new CustomEvent('mockJobStatus', {
            detail: {
              status: statuses[step],
              metadata: {
                date: '2024-07-06',
                cloud_cover: 15
              }
            }
          })
          window.dispatchEvent(mockEvent)
          step++
        } else {
          clearInterval(interval)
        }
      }, 8000) // Change status every 8 seconds

      return () => clearInterval(interval)
    }

    simulateProcessing()
  }, [])

  return (
    <div className="h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-green-900 flex flex-col">
      {/* Header */}
      <header className="bg-slate-900/95 backdrop-blur-md border-b border-emerald-500/30 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="relative w-16 h-16">
            <div className="absolute inset-0 w-16 h-16 bg-gradient-to-br from-emerald-400 via-green-500 to-amber-400 rounded-full opacity-30"></div>
            <div className="absolute inset-2 w-12 h-12 bg-gradient-to-br from-emerald-400 via-green-500 to-amber-400 rounded-full flex items-center justify-center">
              <div className="animate-spin" style={{ animationDuration: '8s' }}>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                  <path d="M13 7 9 3 5 7l4 4"></path>
                  <path d="m17 11 4 4-4 4-4-4"></path>
                  <path d="m8 12 4 4 6-6-4-4Z"></path>
                  <path d="m16 8 3-3"></path>
                  <path d="M9 21a6 6 0 0 0-6-6"></path>
                </svg>
              </div>
            </div>
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white font-fira">iAgroSat</h1>
            <p className="text-emerald-300 text-sm font-fira font-medium">SISTEMA ELITE DE ANÁLISE SATELITAL</p>
          </div>
        </div>
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-400">
              <path d="M20 6 9 17l-5-5"/>
            </svg>
            <span className="text-sm text-slate-300 font-fira font-medium">SISTEMA OPERACIONAL</span>
          </div>
          <div className="flex items-center space-x-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-amber-400">
              <path d="M13 7 9 3 5 7l4 4"></path>
              <path d="m17 11 4 4-4 4-4-4"></path>
              <path d="m8 12 4 4 6-6-4-4Z"></path>
              <path d="m16 8 3-3"></path>
              <path d="M9 21a6 6 0 0 0-6-6"></path>
            </svg>
            <span className="text-sm text-slate-300 font-fira font-medium">ANÁLISE SATELITAL AVANÇADA</span>
          </div>
        </div>
      </header>
      
      <div className="flex-1 p-8 overflow-auto">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-8">
            <Button
              variant="outline"
              onClick={() => router.push('/')}
              className="flex items-center gap-2 mb-4 bg-slate-800/80 border-emerald-500/30 text-emerald-400 hover:bg-slate-700/80"
            >
              <ArrowLeft className="h-4 w-4" />
              Voltar ao Início
            </Button>
            <h1 className="text-3xl font-bold text-white mb-2 font-fira">
              🛰️ SENTINEL-2 PROCESSING ACTIVE
            </h1>
            <p className="text-slate-300 font-mono font-fira">
              Real-time satellite data analysis in progress • DEMO MODE
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Progress Tracker */}
            <div>
              <ProgressTracker 
                jobId={jobId} 
                onComplete={(completedJobId) => {
                  console.log("✅ Job completed:", completedJobId)
                  router.push(`/results/${completedJobId}`)
                }}
              />
            </div>
            
            {/* Logs Viewer */}
            <div>
              <LogsViewer jobId={jobId} />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}