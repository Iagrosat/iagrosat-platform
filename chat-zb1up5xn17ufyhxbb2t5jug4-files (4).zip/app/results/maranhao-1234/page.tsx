'use client'

import { Calendar, Cloud, Download, Share2 } from 'lucide-react'
import { Badge } from '../../../components/ui/badge'
import { Button } from '../../../components/ui/button'

export default function MaranhaoResults() {
  const results = {
    images: {
      rgb: "https://images.pexels.com/photos/31226931/pexels-photo-31226931.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      ndvi: "https://images.pexels.com/photos/31226915/pexels-photo-31226915.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      evi: "https://images.pexels.com/photos/31678059/pexels-photo-31678059.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2", 
      savi: "https://images.pexels.com/photos/31226934/pexels-photo-31226934.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      gci: "https://images.pexels.com/photos/9940117/pexels-photo-9940117.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    metadata: {
      job_id: "maranhao-1234",
      status: 'completed',
      data_captura: "2024-12-05", 
      cobertura_nuvens: 12,
      coordenadas: [-45.2744, -2.5297], // Coordenadas reais do Maranhão
      resolucao: "10m",
      localizacao: "Maranhão, Brasil",
      tamanho_rgb: "~3.1MB",
      sensor: "Sentinel-2 MSI",
      bandas: "RGB + NIR + SWIR"
    },
    indices: [
      { indice: "NDVI", min: -0.12, media: 0.58, max: 0.89 },
      { indice: "EVI", min: -0.08, media: 0.42, max: 0.85 },
      { indice: "SAVI", min: -0.05, media: 0.38, max: 0.81 },
      { indice: "GCI", min: 1.6, media: 3.8, max: 5.4 }
    ]
  }

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6 bg-gray-900 min-h-screen text-white">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
            <span className="text-white text-sm">🛰️</span>
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">
              Relatório de Análise Espectral
            </h1>
            <p className="text-gray-300 flex items-center gap-2">
              <span className="w-2 h-2 bg-green-500 rounded-full"></span>
              Job ID: {results.metadata.job_id} 
              <Badge className="bg-green-100 text-green-800">Concluído</Badge>
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Share2 className="w-4 h-4 mr-2" />
            Compartilhar
          </Button>
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Download
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {/* Spectral Analysis */}
        <div className="bg-gray-800 rounded-lg p-6">
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
            <span>🔬</span>Análises Espectrais
          </h2>
          <p className="text-gray-300 mb-6">Imagens processadas e índices de vegetação calculados</p>

          {/* Analysis Metadata */}
          <div className="bg-gray-700 rounded-lg p-4 mb-6">
            <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
              <span>🌱</span>Metadados da Análise
            </h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                <span>Data: {results.metadata.data_captura}</span>
              </div>
              <div className="flex items-center gap-2">
                <Cloud className="w-4 h-4" />
                <span>Nuvens: {results.metadata.cobertura_nuvens}%</span>
              </div>
              <div className="text-gray-400">
                <div>Lat: {results.metadata.coordenadas[1]}</div>
                <div>Lon: {results.metadata.coordenadas[0]}</div>
                <div>Resolução: {results.metadata.resolucao}</div>
                <div>Local: {results.metadata.localizacao}</div>
              </div>
            </div>
          </div>

          {/* RGB Image */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">
                🛰️ Imagem RGB Composta ORIGINAL
              </h3>
              <Badge variant="secondary" className="text-xs bg-green-100 text-green-700">
                📊 QUALIDADE MÁXIMA • {results.metadata.tamanho_rgb} • Sentinel-2 10m
              </Badge>
            </div>
            <div className="aspect-video bg-gray-900 rounded-lg overflow-hidden">
              <img 
                src={results.images.rgb} 
                alt="RGB Satellite Image - Maranhão" 
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Vegetation Indices */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
              📊 Índices de Vegetação ORIGINAIS
            </h3>
            <Badge variant="secondary" className="mb-4">
              🔬 Análise Espectral Completa • TIFF Originais • Sem Compressão
            </Badge>

            {/* Index Buttons */}
            <div className="grid grid-cols-4 gap-2 mb-4">
              <button className="bg-yellow-600 text-white px-4 py-2 rounded font-semibold">NDVI</button>
              <button className="bg-gray-600 text-white px-4 py-2 rounded">EVI</button>
              <button className="bg-gray-600 text-white px-4 py-2 rounded">SAVI</button>
              <button className="bg-gray-600 text-white px-4 py-2 rounded">GCI</button>
            </div>

            {/* Index Values */}
            <div className="grid grid-cols-3 gap-4 mb-4">
              <div className="bg-green-100 text-green-800 p-3 rounded text-center">
                <div className="text-sm font-medium">Valor Mínimo</div>
                <div className="text-lg font-bold">-0.12</div>
              </div>
              <div className="bg-blue-100 text-blue-800 p-3 rounded text-center">
                <div className="text-sm font-medium">Valor Médio</div>
                <div className="text-lg font-bold">0.58</div>
              </div>
              <div className="bg-orange-100 text-orange-800 p-3 rounded text-center">
                <div className="text-sm font-medium">Valor Máximo</div>
                <div className="text-lg font-bold">0.89</div>
              </div>
            </div>

            {/* NDVI Image */}
            <div className="aspect-video bg-gray-900 rounded-lg overflow-hidden">
              <img 
                src={results.images.ndvi} 
                alt="NDVI Index Image - Maranhão" 
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}