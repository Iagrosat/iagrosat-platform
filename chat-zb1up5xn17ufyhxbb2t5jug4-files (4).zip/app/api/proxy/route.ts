import { NextRequest, NextResponse } from 'next/server'
import { AuthChecker } from '@/lib/auth-checker'
import { AuditLogger } from '@/lib/audit-logger'

// Use environment variable for backend URL
const BACKEND_URL = process.env.BACKEND_URL || 'http://157.180.54.22:8000'

export async function GET(request: NextRequest) {
  console.log("🔄 Proxy request received")
  
  try {
    const { searchParams } = new URL(request.url)
    const path = searchParams.get('path')
    
    if (!path) {
      console.log("❌ No path parameter provided")
      return NextResponse.json({ error: 'Path parameter is required' }, { status: 400 })
    }

    // Allow access to job results images (static/jobs/*) without authentication
    const isJobResult = path.includes('static/jobs/') && (
      path.includes('.png') || 
      path.includes('.jpg') || 
      path.includes('.jpeg') ||
      path.includes('.tif') ||
      path.includes('.tiff')
    )

    // For non-job results, require authentication
    if (!isJobResult) {
      const authResult = await AuthChecker.validateRequest(request)
      if (!authResult.isValid) {
        console.log("❌ Unauthorized proxy access attempt")
        AuditLogger.logSecurityIncident('PROXY_UNAUTHORIZED_ACCESS', {
          path,
          reason: authResult.reason,
          ip: authResult.ip || 'unknown'
        }, authResult.ip || 'unknown', request.headers.get('user-agent') || 'unknown')
        return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
      }
    }

    console.log("✅ Proxying request to:", path)
    
    // Construct the backend URL  
    const backendUrl = `${BACKEND_URL}/${path}`
    console.log("🌐 Backend URL:", backendUrl)
    
    // Forward the request to the backend
    const response = await fetch(backendUrl, {
      method: 'GET',
      headers: {
        'User-Agent': 'iAgroSat-Frontend/1.0',
      },
    })
    
    if (!response.ok) {
      console.log(`❌ Backend responded with ${response.status}: ${response.statusText}`)
      return NextResponse.json(
        { error: `Backend error: ${response.status} ${response.statusText}` },
        { status: response.status }
      )
    }
    
    // Get the response data
    const data = await response.arrayBuffer()
    const contentType = response.headers.get('content-type') || 'application/octet-stream'
    
    console.log(`✅ Successfully proxied ${data.byteLength} bytes of ${contentType}`)
    
    // Return the data with appropriate headers
    return new NextResponse(data, {
      status: 200,
      headers: {
        'Content-Type': contentType,
        'Cache-Control': 'public, max-age=3600',
        'Access-Control-Allow-Origin': '*',
      },
    })
    
  } catch (error) {
    console.error("❌ Proxy error:", error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}