import { NextRequest, NextResponse } from 'next/server'
import { AuthChecker } from '@/lib/auth-checker'
import { Permission } from '@/types/auth'

// Backend server URL - UPDATE THIS TO YOUR LIVE SERVER
const BACKEND_URL = 'http://157.180.54.22:8000'  // User's live server

export async function POST(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const lat = searchParams.get('lat')
    const lon = searchParams.get('lon')
    
    console.log("📍 Full report request:", { lat, lon })
    
    // Validate coordinates
    if (!lat || !lon) {
      return NextResponse.json({ error: 'Parâmetros lat e lon são obrigatórios' }, { status: 400 })
    }
    
    const latNum = parseFloat(lat)
    const lonNum = parseFloat(lon)
    
    if (isNaN(latNum) || isNaN(lonNum)) {
      return NextResponse.json({ error: 'Coordenadas devem ser números válidos' }, { status: 400 })
    }
    
    // Get request body
    const body = await request.json().catch(() => ({}))
    
    console.log("🚀 Starting analysis for:", { lat: latNum, lon: lonNum })
    
    try {
      // Make backend request with timeout
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 15000) // 15 second timeout
      
      console.log("🌐 Attempting backend connection to:", `${BACKEND_URL}/api/full-report`)
      console.log("📦 Request body:", JSON.stringify({ ...body }))
      console.log("📍 Query params:", { lat: latNum, lon: lonNum })
      
      const backendResponse = await fetch(`${BACKEND_URL}/api/full-report?lat=${latNum}&lon=${lonNum}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'iAgroSat-Frontend/1.0',
        },
        body: JSON.stringify({
          ...body
        }),
        signal: controller.signal
      })
      
      clearTimeout(timeoutId)
      
      console.log("📡 Backend response status:", backendResponse.status)
      console.log("📡 Backend response headers:", Object.fromEntries(backendResponse.headers.entries()))
      
      if (backendResponse.ok) {
        const result = await backendResponse.json()
        console.log("✅ Backend response success:", result)
        return NextResponse.json({
          ...result,
          backend_status: 'connected',
          frontend_timestamp: new Date().toISOString()
        })
      } else {
        // Get error details from backend
        const errorText = await backendResponse.text()
        console.log("❌ Backend error response:", errorText)
        console.log("❌ Backend status:", backendResponse.status)
        
        // Try to parse as JSON if possible
        let errorData = null
        try {
          errorData = JSON.parse(errorText)
        } catch (e) {
          errorData = { message: errorText }
        }
        
        return NextResponse.json({
          error: `Backend error: ${backendResponse.status}`,
          backend_error: errorData,
          backend_status: 'error',
          status_code: backendResponse.status
        }, { status: backendResponse.status })
      }
    } catch (error) {
      console.log("🔄 Backend connection failed:", error)
      console.log("🔄 Error details:", error.message)
      
      // Check if it's a network error vs timeout
      if (error.name === 'AbortError') {
        console.log("⏱️ Backend request timed out")
        return NextResponse.json({
          error: 'Backend request timed out',
          backend_status: 'timeout'
        }, { status: 408 })
      }
      
      // Generate offline job ID as fallback
      const jobId = `offline-${Math.random().toString(36).substring(2, 15)}-${Date.now().toString().slice(-5)}`
      
      return NextResponse.json({
        job_id: jobId,
        status: 'queued',
        message: 'Análise iniciada em modo offline - Backend indisponível',
        created_at: new Date().toISOString(),
        coordinates: { lat: latNum, lon: lonNum },
        backend_status: 'offline',
        error_details: error.message
      })
    }
  } catch (error) {
    console.error('❌ Full report error:', error)
    return NextResponse.json({ error: 'Erro interno do servidor' }, { status: 500 })
  }
}