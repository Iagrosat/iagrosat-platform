'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { MapContainer } from '@/components/map-container'

export default function DesignMatrixHacker() {
  const router = useRouter()
  const [selectedTool, setSelectedTool] = useState<string | null>(null)
  const [currentCoordinates, setCurrentCoordinates] = useState({ lat: -23.5505, lng: -46.6333 })
  const [selectedArea, setSelectedArea] = useState({ points: 1, area: 0.25 })
  const [isLoading, setIsLoading] = useState(false)
  const [selectedLocation, setSelectedLocation] = useState<{lat: number, lon: number} | null>({ lat: -23.5505, lon: -46.6333 })
  const [searchQuery, setSearchQuery] = useState('')
  const [manualLat, setManualLat] = useState('')
  const [manualLng, setManualLng] = useState('')

  const processAnalysis = () => {
    console.log("🚀 Starting analysis process")
    setIsLoading(true)
    const jobId = `job-${Date.now()}`
    router.push(`/results/${jobId}`)
  };

  const handleSearch = async () => {
    const query = searchQuery.trim()
    if (!query) return

    console.log("🔍 Searching for:", query)
    
    try {
      const coordMatch = query.match(/(-?\d+\.?\d*),?\s*(-?\d+\.?\d*)/)
      if (coordMatch) {
        const lat = parseFloat(coordMatch[1])
        const lng = parseFloat(coordMatch[2])
        handleCoordinateUpdate(lat, lng)
        setSearchQuery('')
        return
      }
      
      const geocodeUrl = `https://geocode-api.arcgis.com/arcgis/rest/services/World/GeocodeServer/findAddressCandidates?singleLine=${encodeURIComponent(query)}&maxLocations=1&outFields=*&f=json`
      const response = await fetch(geocodeUrl)
      const data = await response.json()
      
      if (data.candidates && data.candidates.length > 0) {
        const result = data.candidates[0]
        const lat = result.location.y
        const lng = result.location.x
        handleCoordinateUpdate(lat, lng)
        setSearchQuery('')
      } else {
        alert('Local não encontrado. Tente outro nome.')
      }
    } catch (error) {
      console.error('Search error:', error)
      alert('Erro na busca. Tente novamente.')
    }
  };

  const handleCoordinateUpdate = (lat: number, lng: number) => {
    setCurrentCoordinates({ lat, lng })
    setSelectedLocation({ lat, lon: lng })
    
    if ((window as any).mapFunctions) {
      (window as any).mapFunctions.updateCoordinates(lat, lng)
    }
  };

  const handleManualCoordinates = () => {
    const lat = parseFloat(manualLat)
    const lng = parseFloat(manualLng)
    
    if (!isNaN(lat) && !isNaN(lng)) {
      handleCoordinateUpdate(lat, lng)
      setManualLat('')
      setManualLng('')
    }
  };

  const activateAreaTool = () => {
    if ((window as any).mapFunctions) {
      (window as any).mapFunctions.activateAreaTool()
    }
    setSelectedTool('area')
  };

  const activatePolygonTool = () => {
    if ((window as any).mapFunctions) {
      (window as any).mapFunctions.activatePolygonTool()
    }
    setSelectedTool('polygon')
  };

  const activatePointTool = () => {
    if ((window as any).mapFunctions) {
      (window as any).mapFunctions.activatePointTool()
    }
    setSelectedTool('point')
  };

  const clearSelection = () => {
    if ((window as any).mapFunctions) {
      (window as any).mapFunctions.clearSelection()
    }
    setSelectedTool(null)
    setSelectedArea({ points: 1, area: 0.25 })
  };

  return (
    <div className="h-screen bg-black flex flex-col overflow-hidden relative">
      {/* Matrix Rain Effect */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-full bg-[linear-gradient(180deg,transparent_0%,rgba(0,255,65,0.05)_50%,transparent_100%)]"></div>
        <div className="absolute inset-0">
          {Array.from({ length: 30 }).map((_, i) => (
            <div
              key={i}
              className="absolute top-0 text-green-400 text-xs font-mono opacity-30 animate-pulse"
              style={{
                left: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 5}s`,
                animationDuration: `${3 + Math.random() * 4}s`
              }}
            >
              {Array.from({ length: 20 }).map((_, j) => (
                <div key={j} className="mb-1">
                  {Math.random().toString(36).substring(2, 4)}
                </div>
              ))}
            </div>
          ))}
        </div>
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-green-500/5 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-lime-500/5 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>

      {/* Header - MATRIX HACKER */}
      <header className="bg-black/95 backdrop-blur-xl border-b border-green-500/30 px-8 py-6 flex items-center justify-between flex-shrink-0 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-green-500/10 to-lime-500/10"></div>
        <div className="flex items-center space-x-6 relative z-10">
          <div className="relative w-20 h-20">
            <div className="absolute inset-0 w-20 h-20 bg-gradient-to-br from-green-400 via-lime-500 to-emerald-400 rounded-full opacity-30 blur-sm animate-pulse"></div>
            <div className="absolute inset-2 w-16 h-16 bg-gradient-to-br from-green-400 via-lime-500 to-emerald-400 rounded-full flex items-center justify-center shadow-2xl shadow-green-500/60 border border-green-300/30">
              <div className="animate-spin" style={{ animationDuration: '12s' }}>
                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-black drop-shadow-xl">
                  <path d="M13 7 9 3 5 7l4 4"></path>
                  <path d="m17 11 4 4-4 4-4-4"></path>
                  <path d="m8 12 4 4 6-6-4-4Z"></path>
                  <path d="m16 8 3-3"></path>
                  <path d="M9 21a6 6 0 0 0-6-6"></path>
                </svg>
              </div>
            </div>
            <div className="absolute inset-0 bg-gradient-to-br from-green-400 via-lime-500 to-emerald-400 rounded-full opacity-20 blur-xl animate-pulse"></div>
          </div>
          <div className="space-y-1">
            <h1 className="text-4xl font-black text-green-400 font-mono tracking-wide filter drop-shadow-2xl">iAgroSat</h1>
            <p className="text-green-300 text-sm font-mono font-bold tracking-[0.3em] uppercase">MATRIX SURVEILLANCE</p>
          </div>
        </div>
        <div className="flex items-center space-x-6 relative z-10">
          <div className="flex items-center space-x-3">
            <div className="w-4 h-4 bg-green-400 rounded-full animate-pulse shadow-lg shadow-green-500/60"></div>
            <span className="text-sm text-green-300 font-mono font-bold tracking-wider">SYSTEM.ACTIVE</span>
          </div>
          <div className="flex items-center space-x-3">
            <div className="w-4 h-4 bg-lime-400 rounded-full animate-pulse shadow-lg shadow-lime-500/60"></div>
            <span className="text-sm text-lime-300 font-mono font-bold tracking-wider">SENTINEL.ONLINE</span>
          </div>
        </div>
      </header>

      {/* Main Content - MATRIX HACKER */}
      <div className="flex flex-1 overflow-hidden relative">
        {/* Matrix Control Terminal */}
        <div className="w-96 bg-black/90 backdrop-blur-xl border-r border-green-500/30 flex flex-col relative">
          <div className="absolute inset-0 bg-gradient-to-b from-green-500/10 to-lime-500/10"></div>
          <div className="absolute inset-0 bg-[repeating-linear-gradient(90deg,transparent,transparent_2px,rgba(0,255,65,0.03)_2px,rgba(0,255,65,0.03)_4px)]"></div>
          <div className="p-8 flex-1 flex flex-col justify-between space-y-8 relative z-10">
            <div className="space-y-8">
              {/* MATRIX SEARCH */}
              <div className="space-y-6">
                <h3 className="text-green-400 text-xl font-black tracking-widest font-mono flex items-center">
                  <div className="w-6 h-6 mr-3 bg-green-400 rounded-sm flex items-center justify-center shadow-lg shadow-green-500/50">
                    <span className="text-black text-xs font-black">></span>
                  </div>
                  SEARCH.EXE
                </h3>
                
                <div className="space-y-4">
                  <div className="relative group">
                    <div className="absolute -inset-1 bg-gradient-to-r from-green-400 to-lime-400 rounded-lg blur opacity-25 group-hover:opacity-75 transition duration-300"></div>
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="> São Paulo, Rio de Janeiro, Brasília..."
                      className="relative w-full px-6 py-4 bg-black text-green-400 border border-green-500/50 focus:border-green-400 focus:outline-none text-base placeholder-green-500/60 font-mono rounded-lg shadow-lg shadow-green-500/20"
                      onKeyPress={(e) => {
                        if (e.key === 'Enter') {
                          handleSearch()
                        }
                      }}
                    />
                  </div>
                  
                  <button 
                    onClick={handleSearch}
                    className="w-full bg-green-500 hover:bg-green-400 text-black py-4 font-black tracking-widest transition-all duration-300 text-base font-mono transform hover:scale-105 rounded-lg shadow-2xl shadow-green-500/40 border border-green-400"
                  >
                    EXECUTE
                  </button>
                </div>
              </div>

              {/* MATRIX COORDINATES */}
              <div className="space-y-6">
                <h3 className="text-lime-400 text-xl font-black tracking-widest font-mono flex items-center">
                  <div className="w-6 h-6 mr-3 bg-lime-400 rounded-sm flex items-center justify-center shadow-lg shadow-lime-500/50">
                    <span className="text-black text-xs font-black">#</span>
                  </div>
                  COORDS.SYS
                </h3>
                
                <div className="space-y-3">
                  <div className="relative">
                    <div className="absolute -inset-1 bg-lime-400/20 rounded-lg blur"></div>
                    <input
                      type="number"
                      value={manualLat}
                      onChange={(e) => setManualLat(e.target.value)}
                      placeholder="> LAT"
                      className="relative w-full px-4 py-3 bg-black text-lime-400 border border-lime-500/50 focus:border-lime-400 focus:outline-none text-sm font-mono rounded-lg shadow-lg shadow-lime-500/20"
                      step="any"
                    />
                  </div>
                  <div className="relative">
                    <div className="absolute -inset-1 bg-lime-400/20 rounded-lg blur"></div>
                    <input
                      type="number"
                      value={manualLng}
                      onChange={(e) => setManualLng(e.target.value)}
                      placeholder="> LNG"
                      className="relative w-full px-4 py-3 bg-black text-lime-400 border border-lime-500/50 focus:border-lime-400 focus:outline-none text-sm font-mono rounded-lg shadow-lg shadow-lime-500/20"
                      step="any"
                    />
                  </div>
                  <button 
                    onClick={handleManualCoordinates}
                    className="w-full bg-lime-500 hover:bg-lime-400 text-black py-3 font-black tracking-widest transition-all duration-300 text-sm font-mono transform hover:scale-105 rounded-lg shadow-2xl shadow-lime-500/40"
                  >
                    TELEPORT
                  </button>
                </div>
              </div>

              {/* MATRIX SELECTION */}
              <div className="space-y-6">
                <h3 className="text-emerald-400 text-xl font-black tracking-widest font-mono flex items-center">
                  <div className="w-6 h-6 mr-3 bg-emerald-400 rounded-sm flex items-center justify-center shadow-lg shadow-emerald-500/50">
                    <span className="text-black text-xs font-black">@</span>
                  </div>
                  STATUS.LOG
                </h3>
                
                <div className="bg-black border border-emerald-500/50 rounded-lg p-6 backdrop-blur-sm shadow-2xl shadow-emerald-500/20">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center font-mono">
                      <span className="text-emerald-300 text-sm tracking-wider">POINTS:</span>
                      <div className="flex items-center space-x-2">
                        <span className="text-green-400 text-xs">█</span>
                        <span className="text-emerald-400 text-lg font-black">{selectedArea.points}</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center font-mono">
                      <span className="text-emerald-300 text-sm tracking-wider">AREA:</span>
                      <div className="flex items-center space-x-2">
                        <span className="text-lime-400 text-xs">█</span>
                        <span className="text-lime-400 text-lg font-black">{selectedArea.area.toFixed(2)}km²</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center font-mono">
                      <span className="text-emerald-300 text-sm tracking-wider">TOOL:</span>
                      <div className="flex items-center space-x-2">
                        <span className="text-green-400 text-xs animate-pulse">█</span>
                        <span className="text-green-400 text-sm font-black">{selectedTool?.toUpperCase() || 'IDLE'}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* MATRIX ACTIONS */}
            <div className="space-y-4">
              <button 
                onClick={processAnalysis}
                className="w-full bg-gradient-to-r from-green-500 to-lime-500 hover:from-green-400 hover:to-lime-400 text-black py-5 font-black tracking-widest transition-all duration-300 text-lg font-mono transform hover:scale-105 rounded-lg shadow-2xl shadow-green-500/50 border border-green-400"
              >
                RUN.ANALYSIS
              </button>
              
              <button 
                onClick={clearSelection}
                className="w-full bg-red-600 hover:bg-red-500 text-white py-4 font-black tracking-widest transition-all duration-300 text-base font-mono transform hover:scale-105 rounded-lg shadow-2xl shadow-red-500/40"
              >
                CLEAR.MEMORY
              </button>
            </div>
          </div>
        </div>

        {/* Map - MATRIX HACKER */}
        <div className="flex-1 relative bg-black">
          <div className="h-full relative">
            <MapContainer
              onCoordinateSelect={(coords) => {
                setSelectedLocation({ lat: coords.lat, lon: coords.lon })
                setCurrentCoordinates({ lat: coords.lat, lng: coords.lon })
              }}
              onAreaSelect={(area) => {
                setSelectedArea({ 
                  points: 1, 
                  area: area.area ? area.area / 1000000 : 0.25 
                })
              }}
              onAnalysisStart={() => {
                processAnalysis()
              }}
              onToolActivated={(tool) => {
                setSelectedTool(tool)
              }}
            />

            {/* MATRIX Map Tools */}
            <div className="absolute top-6 right-6 flex flex-col space-y-3 z-50">
              <button 
                onClick={activateAreaTool}
                className={`w-16 h-16 flex items-center justify-center transition-all duration-300 rounded-lg backdrop-blur-sm border ${
                  selectedTool === 'area' 
                    ? 'bg-green-500 shadow-2xl shadow-green-500/70 border-green-400 text-black' 
                    : 'bg-black/80 hover:bg-black/60 border-green-500/50 hover:border-green-400 hover:shadow-2xl hover:shadow-green-500/40 text-green-400'
                }`}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect width="18" height="18" x="3" y="3" rx="2"/>
                </svg>
              </button>
              
              <button 
                onClick={activatePolygonTool}
                className={`w-16 h-16 flex items-center justify-center transition-all duration-300 rounded-lg backdrop-blur-sm border ${
                  selectedTool === 'polygon' 
                    ? 'bg-lime-500 shadow-2xl shadow-lime-500/70 border-lime-400 text-black' 
                    : 'bg-black/80 hover:bg-black/60 border-lime-500/50 hover:border-lime-400 hover:shadow-2xl hover:shadow-lime-500/40 text-lime-400'
                }`}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polygon points="13,2 3,14 12,14 11,22 21,10 12,10"/>
                </svg>
              </button>
              
              <button 
                onClick={activatePointTool}
                className={`w-16 h-16 flex items-center justify-center transition-all duration-300 rounded-lg backdrop-blur-sm border ${
                  selectedTool === 'point' 
                    ? 'bg-emerald-500 shadow-2xl shadow-emerald-500/70 border-emerald-400 text-black' 
                    : 'bg-black/80 hover:bg-black/60 border-emerald-500/50 hover:border-emerald-400 hover:shadow-2xl hover:shadow-emerald-500/40 text-emerald-400'
                }`}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                  <circle cx="12" cy="10" r="3"/>
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* MATRIX Footer */}
      <footer className="bg-black/95 backdrop-blur-xl border-t border-green-500/30 px-8 py-6 flex items-center justify-center flex-shrink-0 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-green-500/10 to-lime-500/10"></div>
        <div className="flex items-center space-x-8 relative z-10">
          <div className="flex items-center space-x-3">
            <div className="relative w-12 h-12">
              <div className="absolute inset-0 w-12 h-12 bg-gradient-to-br from-green-400 via-lime-500 to-emerald-400 rounded-full opacity-30 blur-sm animate-pulse"></div>
              <div className="absolute inset-1 w-10 h-10 bg-gradient-to-br from-green-400 via-lime-500 to-emerald-400 rounded-full flex items-center justify-center">
                <div className="animate-spin" style={{ animationDuration: '12s' }}>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-black">
                    <path d="M13 7 9 3 5 7l4 4"></path>
                    <path d="m17 11 4 4-4 4-4-4"></path>
                    <path d="m8 12 4 4 6-6-4-4Z"></path>
                    <path d="m16 8 3-3"></path>
                    <path d="M9 21a6 6 0 0 0-6-6"></path>
                  </svg>
                </div>
              </div>
            </div>
            <span className="text-green-300 text-base font-black font-mono tracking-wider">iAgroSat.MATRIX</span>
          </div>
          <div className="text-green-400 text-sm font-mono font-bold tracking-wider">
            REG: 61.579.333/0001-00
          </div>
          <div className="text-lime-400 text-sm font-mono font-bold tracking-wider">
            POWERED.BY.SENTINEL-2
          </div>
          <div className="text-emerald-400 text-sm font-mono font-bold tracking-wider">
            © 2024.MATRIX.CORP
          </div>
        </div>
      </footer>
    </div>
  )
}