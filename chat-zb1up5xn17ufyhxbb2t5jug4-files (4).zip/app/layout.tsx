import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import { JetBrains_Mono } from 'next/font/google'
import { Space_Grotesk } from 'next/font/google'
import { Orbitron } from 'next/font/google'
import { Fira_Code } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })
const jetbrainsMono = JetBrains_Mono({ 
  subsets: ['latin'],
  variable: '--font-jetbrains-mono'
})
const spaceGrotesk = Space_Grotesk({ 
  subsets: ['latin'],
  variable: '--font-space-grotesk'
})
const orbitron = Orbitron({ 
  subsets: ['latin'],
  variable: '--font-orbitron'
})
const firaCode = Fira_Code({ 
  subsets: ['latin'], 
  weight: ['300', '400', '500', '600', '700'],
  variable: '--font-fira-code'
})

export const metadata: Metadata = {
  title: 'iAgroSat - Análise Satelital',
  description: 'Sistema de análise satelital para agricultura',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR" className={`${inter.className} ${jetbrainsMono.variable} ${spaceGrotesk.variable} ${orbitron.variable} ${firaCode.variable}`}>
      <body>{children}</body>
    </html>
  );
}