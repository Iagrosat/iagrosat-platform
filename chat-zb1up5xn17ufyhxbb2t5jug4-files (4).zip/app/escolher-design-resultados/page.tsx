'use client'

import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { ArrowLeft, Beaker, Building, Terminal, Leaf } from 'lucide-react'

export default function EscolherDesignResultados() {
  const router = useRouter()

  const designs = [
    {
      id: 'cientifico',
      name: 'Científico Clássico',
      description: 'Design limpo e profissional focado em dados científicos',
      icon: Beaker,
      color: 'from-blue-500 to-indigo-600',
      features: [
        'Fundo branco limpo e minimalista',
        'Foco nas estatísticas descritivas',
        'Percentis e distribuições detalhadas',
        'Metadados técnicos completos',
        'Ideal para publicações acadêmicas'
      ],
      path: '/results-design-1-cientifico'
    },
    {
      id: 'corporativo',
      name: 'Corporativo Moderno',
      description: 'Visual executivo com gradientes sutis e KPIs',
      icon: Building,
      color: 'from-slate-600 to-blue-600',
      features: [
        'Header executivo elegante',
        'KPIs em destaque no topo',
        'Scores e tendências',
        'Gradientes sutis e profissionais',
        'Ideal para apresentações executivas'
      ],
      path: '/results-design-2-corporativo'
    },
    {
      id: 'tech',
      name: 'Tech Dashboard',
      description: 'Tema escuro estilo terminal com métricas técnicas',
      icon: Terminal,
      color: 'from-gray-800 to-cyan-600',
      features: [
        'Tema dark com acentos neon',
        'Estilo terminal/código',
        'Métricas de processamento',
        'Fórmulas matemáticas detalhadas',
        'Ideal para desenvolvedores/técnicos'
      ],
      path: '/results-design-3-tech'
    },
    {
      id: 'agricultura',
      name: 'Agricultura Natural',
      description: 'Design inspirado na natureza com foco agronômico',
      icon: Leaf,
      color: 'from-green-600 to-emerald-600',
      features: [
        'Tons naturais verdes e terrosos',
        'Recomendações agronômicas',
        'Status de saúde da vegetação',
        'Interpretação prática dos índices',
        'Ideal para agricultores e agrônomos'
      ],
      path: '/results-design-4-agricultura'
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-gray-200 px-6 py-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => router.push('/')}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Voltar ao Mapa
            </Button>
            <div className="h-6 w-px bg-gray-300"></div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                Escolha o Design dos Resultados
              </h1>
              <p className="text-gray-600 mt-1">
                Selecione o estilo visual que melhor atende às suas necessidades
              </p>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-8">
        {/* Introdução */}
        <div className="text-center mb-12">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">
            4 Designs Profissionais Baseados em Pesquisa Científica
          </h2>
          <p className="text-gray-600 max-w-3xl mx-auto">
            Cada design foi criado com base em pesquisa detalhada sobre índices de vegetação (NDVI, EVI, SAVI, GCI) 
            e suas aplicações em sensoriamento remoto. Escolha o que melhor reflete sua audiência e objetivos.
          </p>
        </div>

        {/* Grid de Designs */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {designs.map((design) => {
            const IconComponent = design.icon
            return (
              <div
                key={design.id}
                className="bg-white rounded-2xl shadow-xl border border-gray-200 overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:scale-105"
              >
                {/* Header do Card */}
                <div className={`bg-gradient-to-r ${design.color} p-6 text-white`}>
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                      <IconComponent className="h-6 w-6" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold">{design.name}</h3>
                      <p className="text-white/90 text-sm">{design.description}</p>
                    </div>
                  </div>
                </div>

                {/* Conteúdo do Card */}
                <div className="p-6">
                  <h4 className="font-bold text-gray-800 mb-4">Características:</h4>
                  <ul className="space-y-2 mb-6">
                    {design.features.map((feature, index) => (
                      <li key={index} className="flex items-start space-x-2">
                        <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                        <span className="text-gray-600 text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  {/* Botão para Visualizar */}
                  <Button
                    onClick={() => router.push(design.path)}
                    className={`w-full bg-gradient-to-r ${design.color} hover:opacity-90 text-white font-semibold py-3 rounded-lg transition-all`}
                  >
                    <IconComponent className="h-4 w-4 mr-2" />
                    Visualizar {design.name}
                  </Button>
                </div>
              </div>
            )
          })}
        </div>

        {/* Informações Adicionais */}
        <div className="mt-12 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-8 border border-blue-200">
          <h3 className="text-xl font-bold text-blue-900 mb-4">
            📊 Sobre os Índices de Vegetação
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
            <div>
              <h4 className="font-semibold text-blue-800 mb-2">NDVI - Índice de Vegetação por Diferença Normalizada</h4>
              <p className="text-blue-700">
                Mede a saúde geral da vegetação usando as bandas NIR e Red. Valores altos indicam vegetação saudável e densa.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-blue-800 mb-2">EVI - Índice de Vegetação Melhorado</h4>
              <p className="text-blue-700">
                Minimiza ruído atmosférico e do solo, sendo ideal para áreas com vegetação densa ou condições atmosféricas adversas.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-blue-800 mb-2">SAVI - Índice de Vegetação Ajustado ao Solo</h4>
              <p className="text-blue-700">
                Corrige interferências do solo exposto, sendo perfeito para análise de vegetação esparsa ou culturas jovens.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-blue-800 mb-2">GCI - Índice de Clorofila Verde</h4>
              <p className="text-blue-700">
                Estima o conteúdo de clorofila nas folhas, fornecendo informações sobre o estado nutricional das plantas.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}