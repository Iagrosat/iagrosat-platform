'use client';

import Link from 'next/link';

export default function DesignPreview() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-white mb-4">iAgroSat Design Options</h1>
          <p className="text-slate-400 text-lg">Choose your preferred professional satellite analysis interface</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Final Design - Fusion of 1 & 2 */}
          <div className="md:col-span-2 bg-slate-800/50 backdrop-blur-lg rounded-2xl border border-yellow-500/50 p-8 hover:border-yellow-400/70 transition-all duration-300">
            <div className="flex items-center space-x-4 mb-6">
              <div className="relative">
                {/* Terra Dourada */}
                <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 via-yellow-500 to-yellow-600 rounded-full flex items-center justify-center shadow-2xl border-2 border-yellow-300/20">
                  {/* Botão Verde Piscando no Centro */}
                  <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse shadow-lg"></div>
                  {/* Continentes na Terra */}
                  <div className="absolute top-2 left-2 w-1 h-1 bg-yellow-200 rounded-full opacity-60"></div>
                  <div className="absolute bottom-2 right-2 w-1 h-1 bg-yellow-200 rounded-full opacity-60"></div>
                </div>
                {/* Satélite Rotativo */}
                <div className="absolute -top-2 -right-2 w-6 h-6 animate-spin">
                  <div className="relative w-full h-full">
                    {/* Corpo do satélite */}
                    <div className="w-2 h-3 bg-slate-300 rounded-sm absolute top-1 left-2"></div>
                    {/* Painéis solares */}
                    <div className="w-1 h-4 bg-blue-400 absolute top-0.5 left-0"></div>
                    <div className="w-1 h-4 bg-blue-400 absolute top-0.5 right-0"></div>
                    {/* Antena */}
                    <div className="w-0.5 h-1 bg-yellow-400 absolute -top-0.5 left-2.5"></div>
                  </div>
                </div>
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">Design Final - Fusão Profissional</h2>
                <p className="text-yellow-400 text-sm">Combinação técnica-corporativa em português</p>
              </div>
            </div>
            
            <div className="grid md:grid-cols-2 gap-6 mb-6">
              <div>
                <h3 className="text-white font-semibold mb-2">Características:</h3>
                <ul className="text-slate-300 text-sm space-y-1">
                  <li>• Interface técnica-profissional</li>
                  <li>• Cores douradas (não laranja)</li>
                  <li>• Logo customizado: Terra + Satélite</li>
                  <li>• Todo conteúdo em português</li>
                </ul>
              </div>
              <div>
                <h3 className="text-white font-semibold mb-2">Elementos Técnicos:</h3>
                <ul className="text-slate-300 text-sm space-y-1">
                  <li>• Status do sistema em tempo real</li>
                  <li>• Fontes monospace para dados</li>
                  <li>• Configurações avançadas</li>
                  <li>• Interface limpa e funcional</li>
                </ul>
              </div>
            </div>

            <div className="mb-6">
              <h3 className="text-white font-semibold mb-2">Inspirado por:</h3>
              <p className="text-slate-300 text-sm">Sentinel Hub + ArcGIS Enterprise (Fusão dos designs 1 e 2)</p>
            </div>

            <Link href="/design-final" className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-yellow-600 to-yellow-700 hover:from-yellow-700 hover:to-yellow-800 text-slate-900 font-medium rounded-lg transition-all duration-200 transform hover:scale-105">
              Visualizar Design Final
              <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </Link>
          </div>
        </div>

        <div className="text-center mt-12">
          <p className="text-slate-400 text-sm">
            Each design option maintains professional satellite analysis capabilities while offering distinct visual approaches.
          </p>
          <Link href="/" className="inline-flex items-center mt-4 px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors">
            <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Back to Current Version
          </Link>
        </div>
      </div>
    </div>
  );
}