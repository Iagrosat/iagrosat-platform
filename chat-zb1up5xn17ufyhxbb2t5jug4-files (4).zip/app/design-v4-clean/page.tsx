'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { MapContainer } from '@/components/map-container'

export default function DesignV4Clean() {
  const [searchQuery, setSearchQuery] = useState('')
  const [currentCoordinates, setCurrentCoordinates] = useState({ lat: -23.5505, lng: -46.6333 })
  const [selectedTool, setSelectedTool] = useState<string | null>(null)
  const [selectedArea, setSelectedArea] = useState({ points: 1, area: 0.25 })
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleSearch = async () => {
    const query = searchQuery.trim()
    if (!query) return

    console.log("🔍 Buscando por:", query)
    
    try {
      // Detecta coordenadas (lat,lng)
      const coordMatch = query.match(/(-?\d+\.?\d*),?\s*(-?\d+\.?\d*)/)
      if (coordMatch) {
        const lat = parseFloat(coordMatch[1])
        const lng = parseFloat(coordMatch[2])
        console.log("📍 Coordenadas detectadas:", lat, lng)
        setCurrentCoordinates({ lat, lng })
        return
      }
      
      // Busca cidade via ESRI
      const geocodeUrl = `https://geocode-api.arcgis.com/arcgis/rest/services/World/GeocodeServer/findAddressCandidates?singleLine=${encodeURIComponent(query)}&maxLocations=1&outFields=*&f=json`
      
      const response = await fetch(geocodeUrl)
      const data = await response.json()
      
      if (data.candidates && data.candidates.length > 0) {
        const result = data.candidates[0]
        const lat = result.location.y
        const lng = result.location.x
        
        console.log("🌍 Local encontrado:", result.address, "em", lat, lng)
        setCurrentCoordinates({ lat, lng })
      } else {
        alert('Local não encontrado. Tente outro nome.')
      }
    } catch (error) {
      console.error('Erro na busca:', error)
      alert('Erro na busca. Tente novamente.')
    }
  }

  const processAnalysis = () => {
    console.log("🚀 Iniciando análise")
    setIsLoading(true)
    const jobId = `job-${Date.now()}`
    router.push(`/results/${jobId}`)
  }

  const clearSelection = () => {
    setSelectedArea({ points: 1, area: 0.25 })
    setSelectedTool(null)
  }

  return (
    <div className="h-screen bg-white flex flex-col">
      {/* Header Limpo */}
      <header className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
              <path d="M13 7 9 3 5 7l4 4"></path>
              <path d="m17 11 4 4-4 4-4-4"></path>
              <path d="m8 12 4 4 6-6-4-4Z"></path>
            </svg>
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">iAgroSat</h1>
            <p className="text-green-600 text-sm">Análise Satelital</p>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span className="text-sm text-gray-600">Backend Ativo</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
            <span className="text-sm text-gray-600">Sentinel Ativo</span>
          </div>
        </div>
      </header>

      {/* Conteúdo Principal */}
      <div className="flex flex-1 overflow-hidden">
        {/* Painel Lateral Limpo */}
        <div className="w-80 bg-gray-50 border-r border-gray-200 flex flex-col">
          <div className="p-6 flex-1 space-y-6">
            
            {/* Busca por Local */}
            <div>
              <h3 className="text-gray-700 mb-3 text-sm font-semibold">Buscar Local</h3>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="São Paulo, Rio de Janeiro, Brasília..."
                className="w-full px-4 py-3 bg-white text-gray-900 border border-gray-300 focus:border-green-500 focus:outline-none rounded-lg text-sm placeholder-gray-400"
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              />
              <button 
                onClick={handleSearch}
                className="w-full mt-3 bg-green-600 hover:bg-green-700 text-white py-3 font-medium text-sm rounded-lg transition-all"
              >
                Buscar & Localizar
              </button>
            </div>

            {/* Coordenadas Manuais */}
            <div>
              <h3 className="text-gray-700 mb-3 text-sm font-semibold">Coordenadas</h3>
              <div className="space-y-2">
                <input
                  type="number"
                  step="any"
                  placeholder="Latitude (ex: -23.5505)"
                  value={currentCoordinates.lat}
                  onChange={(e) => setCurrentCoordinates(prev => ({ ...prev, lat: parseFloat(e.target.value) || 0 }))}
                  className="w-full px-4 py-2 bg-white text-gray-900 border border-gray-300 focus:border-green-500 focus:outline-none rounded-lg text-sm placeholder-gray-400"
                />
                <input
                  type="number"
                  step="any"
                  placeholder="Longitude (ex: -46.6333)"
                  value={currentCoordinates.lng}
                  onChange={(e) => setCurrentCoordinates(prev => ({ ...prev, lng: parseFloat(e.target.value) || 0 }))}
                  className="w-full px-4 py-2 bg-white text-gray-900 border border-gray-300 focus:border-green-500 focus:outline-none rounded-lg text-sm placeholder-gray-400"
                />
              </div>
              <button 
                onClick={() => console.log("Indo para coordenadas:", currentCoordinates)}
                className="w-full mt-3 bg-blue-600 hover:bg-blue-700 text-white py-3 font-medium text-sm rounded-lg transition-all"
              >
                Ir para Coordenadas
              </button>
            </div>

            {/* Seleção Ativa */}
            <div>
              <h3 className="text-gray-700 mb-3 text-sm font-semibold">Seleção Ativa</h3>
              <div className="bg-white border border-gray-200 rounded-lg p-4 space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600 text-sm">Pontos:</span>
                  <span className="text-green-600 text-sm font-semibold">{selectedArea.points}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600 text-sm">Área:</span>
                  <span className="text-green-600 text-sm font-semibold">{selectedArea.area.toFixed(2)} km²</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600 text-sm">Status:</span>
                  <span className="text-green-600 text-sm font-semibold">Selecionado</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600 text-sm">Ferramenta:</span>
                  <span className="text-green-600 text-sm font-semibold">{selectedTool?.charAt(0).toUpperCase() + selectedTool?.slice(1) || 'Nenhuma'}</span>
                </div>
              </div>
            </div>

            {/* Botões de Ação */}
            <div className="space-y-3">
              <button 
                onClick={processAnalysis}
                className="w-full bg-green-600 hover:bg-green-700 text-white py-4 font-semibold text-sm rounded-lg transition-all"
              >
                Processar Análise
              </button>
              <button 
                onClick={clearSelection}
                className="w-full bg-red-600 hover:bg-red-700 text-white py-3 font-medium text-sm rounded-lg transition-all"
              >
                Limpar Seleção
              </button>
            </div>
          </div>
        </div>

        {/* Mapa */}
        <div className="flex-1 relative">
          <MapContainer
            onCoordinateSelect={(coords) => {
              setCurrentCoordinates({ lat: coords.lat, lng: coords.lon })
            }}
            onAreaSelect={(area) => {
              setSelectedArea({ points: 1, area: area.area ? area.area / 1000000 : 0.25 })
            }}
            onAnalysisStart={processAnalysis}
            onToolActivated={setSelectedTool}
          />
          
          {/* Ferramentas do Mapa */}
          <div className="absolute top-4 right-4 flex flex-col space-y-2 z-50">
            <button 
              onClick={() => setSelectedTool('area')}
              className={`w-12 h-12 flex items-center justify-center transition-all rounded-lg ${
                selectedTool === 'area' 
                  ? 'bg-green-600 shadow-lg' 
                  : 'bg-white hover:bg-gray-50 border border-gray-200 shadow-sm'
              }`}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={selectedTool === 'area' ? 'text-white' : 'text-gray-600'}>
                <rect width="18" height="18" x="3" y="3" rx="2"/>
              </svg>
            </button>
            
            <button 
              onClick={() => setSelectedTool('point')}
              className={`w-12 h-12 flex items-center justify-center transition-all rounded-lg ${
                selectedTool === 'point' 
                  ? 'bg-green-600 shadow-lg' 
                  : 'bg-white hover:bg-gray-50 border border-gray-200 shadow-sm'
              }`}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={selectedTool === 'point' ? 'text-white' : 'text-gray-600'}>
                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                <circle cx="12" cy="10" r="3"/>
              </svg>
            </button>
            
            <button 
              onClick={clearSelection}
              className="w-12 h-12 bg-red-600 hover:bg-red-700 flex items-center justify-center transition-all rounded-lg shadow-sm"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                <path d="M3 6h18"/>
                <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/>
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 px-6 py-3 flex items-center justify-center">
        <div className="flex items-center space-x-4 text-sm text-gray-600">
          <span>iAgroSat</span>
          <span>•</span>
          <span>CNPJ: 61.579.333/0001-00</span>
          <span>•</span>
          <span>Powered by SENTINEL-2</span>
          <span>•</span>
          <span>© 2024</span>
        </div>
      </footer>
    </div>
  )
}