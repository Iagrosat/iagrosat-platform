'use client'

import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ArrowLeft, Wheat, Satellite, Activity, Database } from 'lucide-react'
import { useRouter } from 'next/navigation'

export default function EscolherDesignTech() {
  const router = useRouter()

  const designs = [
    {
      id: 'agritech',
      title: 'AgriTech Analytics',
      subtitle: 'Análise Satelital para Agricultura',
      description: 'Design focado em métricas agrícolas com tabs interativas para índices espectrais NDVI, SAVI, EVI. Interface verde com elementos de agricultura moderna.',
      icon: Wheat,
      color: 'from-emerald-400 to-green-600',
      features: ['Tabs interativas', 'Métricas agrícolas', 'Recomendações', 'Status da análise'],
      route: '/results-design-5-agritech',
      preview: '🌿 Vegetação • 📊 Índices • 🎯 Recomendações'
    },
    {
      id: 'satellite-pro',
      title: 'SENTINEL-2 Analytics',
      subtitle: 'Professional Satellite Analysis',
      description: 'Interface profissional estilo missão espacial com dados espectrais detalhados, bandas Sentinel-2 e análise técnica completa.',
      icon: Satellite,
      color: 'from-cyan-400 to-blue-600',
      features: ['Dados espectrais', 'Bandas Sentinel', 'Análise técnica', 'Mission control'],
      route: '/results-design-6-satellite-pro',
      preview: '🛰️ Sentinel • 📡 Bandas • 🎯 Profissional'
    },
    {
      id: 'agri-dashboard',
      title: 'AgriTech Dashboard',
      subtitle: 'Monitoramento Inteligente de Culturas',
      description: 'Dashboard moderno com métricas de saúde da cultura, stress hídrico, exposição solar e risco de pragas com progressbars e indicadores.',
      icon: Activity,
      color: 'from-green-400 to-emerald-600',
      features: ['Métricas de cultura', 'Progress bars', 'Alertas', 'Próximas ações'],
      route: '/results-design-7-agri-dashboard',
      preview: '📈 Dashboard • 🌾 Culturas • ⚠️ Alertas'
    },
    {
      id: 'sentinel-analytics',
      title: 'Sentinel Analytics',
      subtitle: 'Advanced Earth Observation Platform',
      description: 'Plataforma avançada de observação terrestre com análise multi-band, classificação de uso do solo e métricas técnicas do programa Copernicus.',
      icon: Database,
      color: 'from-blue-400 to-cyan-600',
      features: ['Multi-band analysis', 'Uso do solo', 'Métricas ESA', 'Dados Copernicus'],
      route: '/results-design-8-sentinel-analytics',
      preview: '🌍 Earth Obs • 📊 Multi-band • 🔬 Técnico'
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-emerald-900 to-green-800">
      {/* Header */}
      <header className="bg-slate-900/95 backdrop-blur-md border-b border-emerald-500/30 p-6">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center space-x-4">
            <Button
              variant="outline"
              onClick={() => router.push('/')}
              className="flex items-center gap-2 bg-slate-800/80 border-emerald-500/30 text-emerald-400 hover:bg-slate-700/80"
            >
              <ArrowLeft className="h-4 w-4" />
              Voltar ao Mapa
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-white">Escolher Design Tech</h1>
              <p className="text-emerald-400">4 versões focadas em agricultura e análise satelital</p>
            </div>
          </div>
        </div>
      </header>

      <div className="p-8 max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Designs Tech para Resultados</h2>
          <p className="text-slate-300 max-w-2xl mx-auto">
            Escolha o design que melhor representa a análise satelital para agricultura. 
            Cada versão tem foco diferente mantendo a identidade tech.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {designs.map((design) => {
            const Icon = design.icon
            return (
              <Card key={design.id} className="bg-slate-900/80 border-emerald-500/30 hover:border-emerald-400/50 transition-all group">
                <CardHeader>
                  <div className="flex items-center space-x-4 mb-4">
                    <div className={`w-12 h-12 bg-gradient-to-br ${design.color} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform`}>
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-white">{design.title}</CardTitle>
                      <p className="text-emerald-400 text-sm">{design.subtitle}</p>
                    </div>
                  </div>
                  
                  <div className="text-slate-300 text-sm leading-relaxed mb-4">
                    {design.description}
                  </div>
                  
                  <div className="text-center py-3 px-4 bg-slate-800/60 rounded-lg border border-slate-700/50 mb-4">
                    <div className="text-slate-400 text-xs mb-1">Preview:</div>
                    <div className="text-emerald-400 text-sm font-medium">{design.preview}</div>
                  </div>
                </CardHeader>
                
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="text-white font-semibold text-sm mb-2">Características:</div>
                      <div className="flex flex-wrap gap-2">
                        {design.features.map((feature, index) => (
                          <Badge key={index} variant="outline" className="text-emerald-400 border-emerald-400/30 text-xs">
                            {feature}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    
                    <Button 
                      onClick={() => router.push(design.route)}
                      className={`w-full bg-gradient-to-r ${design.color} hover:opacity-90 text-white font-semibold py-3 transition-all`}
                    >
                      Ver Design {design.title.split(' ')[0]}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        <div className="mt-8 text-center">
          <div className="bg-slate-900/60 border border-emerald-500/30 rounded-xl p-6 max-w-2xl mx-auto">
            <h3 className="text-white font-bold mb-2">💡 Dica</h3>
            <p className="text-slate-300 text-sm">
              Cada design mantém a funcionalidade completa mas com foco diferente:
              <strong className="text-emerald-400"> AgriTech</strong> (agricultura), 
              <strong className="text-cyan-400"> Satellite Pro</strong> (técnico),
              <strong className="text-green-400"> Dashboard</strong> (monitoramento), 
              <strong className="text-blue-400"> Analytics</strong> (científico).
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}