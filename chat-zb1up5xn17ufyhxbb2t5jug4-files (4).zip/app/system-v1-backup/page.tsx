'use client'

import { useState } from 'react'
import { Header } from '@/components/header'
import { MapContainer } from '@/components/map-container'

export default function SystemV1Backup() {
  const [selectedLocation, setSelectedLocation] = useState<{lat: number, lon: number} | null>(null);
  const [selectedAreaData, setSelectedAreaData] = useState<{area: number, coordinates: number[][]} | null>(null);

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0 flex items-center">
                <div className="w-8 h-8 bg-green-600 rounded-lg flex items-center justify-center mr-3">
                  <span className="text-white font-bold">🛰️</span>
                </div>
                <span className="text-xl font-bold text-gray-900">iAgroSat</span>
                <span className="ml-2 text-sm text-gray-500">Sistema Elite de Análise Satelital</span>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-sm text-gray-600">
                <span className="inline-flex items-center">
                  <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                  Sistema Operacional
                </span>
              </div>
              <div className="text-sm text-gray-600">
                <span className="inline-flex items-center">
                  <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                  Análise Satelital Avançada
                </span>
              </div>
              <a
                href="/design-preview"
                className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors font-medium"
              >
                Design Options
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content - Full Width Map */}
      <main className="h-[calc(100vh-4rem)]">
        <MapContainer 
          onCoordinateSelect={(coords) => setSelectedLocation({ lat: coords.lat, lon: coords.lon })}
          onAreaSelect={setSelectedAreaData}
        />
      </main>
    </div>
  );
}