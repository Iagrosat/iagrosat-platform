"use client";

import { AuthProvider } from '@/contexts/auth-context';
import { EnterpriseLayout } from '@/components/enterprise/layout';
import { RouteGuard } from '@/components/enterprise/route-guard';

export default function EnterpriseRootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <AuthProvider>
      <RouteGuard>
        <EnterpriseLayout>
          {children}
        </EnterpriseLayout>
      </RouteGuard>
    </AuthProvider>
  );
}