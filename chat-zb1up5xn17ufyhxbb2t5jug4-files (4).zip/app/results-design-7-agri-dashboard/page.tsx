'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { ArrowLeft, Wheat, Droplets, Sun, AlertTriangle } from 'lucide-react'
import { useRouter } from 'next/navigation'

export default function AgriDashboardResults() {
  const router = useRouter()

  const cropMetrics = [
    { 
      name: 'Saúde da Cultura', 
      value: 87, 
      status: 'Excelente',
      color: 'text-green-500',
      icon: Wheat,
      description: 'Vegetação vigorosa com alta densidade'
    },
    { 
      name: 'Stress Hídrico', 
      value: 23, 
      status: 'Baixo',
      color: 'text-blue-500',
      icon: Droplets,
      description: 'Níveis adequados de umidade'
    },
    { 
      name: 'Exposição Solar', 
      value: 76, 
      status: 'Ideal',
      color: 'text-yellow-500',
      icon: Sun,
      description: 'Radiação solar otimizada'
    },
    { 
      name: 'Risco Pragas', 
      value: 15, 
      status: 'Baixo',
      color: 'text-orange-500',
      icon: AlertTriangle,
      description: 'Condições desfavoráveis para pragas'
    }
  ]

  const indices = [
    { name: 'NDVI', value: 0.734, max: 1, label: 'Índice de Vegetação', color: 'bg-green-500' },
    { name: 'SAVI', value: 0.652, max: 1, label: 'Solo-Vegetação Ajustado', color: 'bg-emerald-500' },
    { name: 'EVI', value: 0.583, max: 1, label: 'Vegetação Aprimorado', color: 'bg-lime-500' },
    { name: 'NDWI', value: 0.425, max: 1, label: 'Índice de Água', color: 'bg-blue-500' }
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Excelente': return 'text-green-400 bg-green-400/10 border-green-400/30'
      case 'Ideal': return 'text-yellow-400 bg-yellow-400/10 border-yellow-400/30'
      case 'Baixo': return 'text-blue-400 bg-blue-400/10 border-blue-400/30'
      default: return 'text-slate-400 bg-slate-400/10 border-slate-400/30'
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-950 via-emerald-900 to-slate-900">
      {/* Header */}
      <header className="bg-slate-900/95 backdrop-blur-md border-b border-emerald-500/30 p-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center space-x-4">
            <Button
              variant="outline"
              onClick={() => router.push('/')}
              className="flex items-center gap-2 bg-slate-800/80 border-emerald-500/30 text-emerald-400 hover:bg-slate-700/80"
            >
              <ArrowLeft className="h-4 w-4" />
              Voltar
            </Button>
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-emerald-600 rounded-xl flex items-center justify-center">
                <Wheat className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">AgriTech Dashboard</h1>
                <p className="text-emerald-400 text-sm">Monitoramento Inteligente de Culturas</p>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <div className="text-white font-semibold">São Paulo, SP</div>
              <div className="text-emerald-400 text-sm">Última atualização: {new Date().toLocaleTimeString('pt-BR')}</div>
            </div>
          </div>
        </div>
      </header>

      <div className="p-6 max-w-7xl mx-auto">
        {/* Key Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {cropMetrics.map((metric, index) => {
            const Icon = metric.icon
            return (
              <Card key={index} className="bg-slate-900/80 border-emerald-500/30 hover:border-emerald-400/50 transition-colors">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <Icon className={`h-6 w-6 ${metric.color}`} />
                    <span className={`text-xs px-2 py-1 rounded-full border ${getStatusColor(metric.status)}`}>
                      {metric.status}
                    </span>
                  </div>
                  <div className="mb-2">
                    <div className={`text-2xl font-bold ${metric.color}`}>
                      {metric.value}%
                    </div>
                    <div className="text-white text-sm font-medium">
                      {metric.name}
                    </div>
                  </div>
                  <div className="w-full bg-slate-700 rounded-full h-2 mb-2">
                    <div 
                      className={`h-2 rounded-full ${metric.color.replace('text-', 'bg-')}`}
                      style={{ width: `${metric.value}%` }}
                    ></div>
                  </div>
                  <div className="text-slate-400 text-xs">
                    {metric.description}
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Spectral Indices */}
          <div className="lg:col-span-2">
            <Card className="bg-slate-900/80 border-emerald-500/30">
              <CardHeader>
                <CardTitle className="text-white">Índices Espectrais Detalhados</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {indices.map((index, i) => (
                    <div key={i} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-white font-semibold">{index.name}</div>
                          <div className="text-slate-400 text-sm">{index.label}</div>
                        </div>
                        <div className="text-right">
                          <div className="text-white font-bold text-lg">{index.value.toFixed(3)}</div>
                          <div className="text-slate-400 text-sm">{((index.value / index.max) * 100).toFixed(0)}%</div>
                        </div>
                      </div>
                      <Progress 
                        value={(index.value / index.max) * 100} 
                        className="h-3"
                      />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Analysis Summary */}
          <div className="space-y-6">
            <Card className="bg-slate-900/80 border-emerald-500/30">
              <CardHeader>
                <CardTitle className="text-white">Resumo da Análise</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <div className="text-sm text-slate-300">
                    <div className="text-white font-medium">Estado Geral</div>
                    <div>Cultura em excelente estado</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                  <div className="text-sm text-slate-300">
                    <div className="text-white font-medium">Irrigação</div>
                    <div>Níveis adequados de umidade</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                  <div className="text-sm text-slate-300">
                    <div className="text-white font-medium">Crescimento</div>
                    <div>Taxa de crescimento acelerada</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 bg-emerald-500 rounded-full"></div>
                  <div className="text-sm text-slate-300">
                    <div className="text-white font-medium">Produtividade</div>
                    <div>Estimativa 15% acima da média</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-900/80 border-emerald-500/30">
              <CardHeader>
                <CardTitle className="text-white">Próximas Ações</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="bg-green-400/10 border border-green-400/30 rounded-lg p-3">
                  <div className="text-green-400 font-medium text-sm">Recomendado</div>
                  <div className="text-slate-300 text-xs mt-1">Manter regime atual de irrigação</div>
                </div>
                <div className="bg-blue-400/10 border border-blue-400/30 rounded-lg p-3">
                  <div className="text-blue-400 font-medium text-sm">Monitoramento</div>
                  <div className="text-slate-300 text-xs mt-1">Próxima análise em 7 dias</div>
                </div>
                <div className="bg-yellow-400/10 border border-yellow-400/30 rounded-lg p-3">
                  <div className="text-yellow-400 font-medium text-sm">Atenção</div>
                  <div className="text-slate-300 text-xs mt-1">Verificar proteção contra pragas</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}