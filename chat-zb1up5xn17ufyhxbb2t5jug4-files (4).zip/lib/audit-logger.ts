import { AuditLog } from '@/types/auth'

export class AuditLogger {
  private static logs: AuditLog[] = []
  
  static log(params: {
    userId: string
    userName: string
    action: string
    resource: string
    details?: Record<string, any>
    ip?: string
    userAgent?: string
  }) {
    const auditLog: AuditLog = {
      id: `audit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      userId: params.userId,
      userName: params.userName,
      action: params.action,
      resource: params.resource,
      details: params.details,
      timestamp: new Date().toISOString(),
      ip: params.ip,
      userAgent: params.userAgent
    }
    
    // Store in memory (in production, send to database/log service)
    this.logs.push(auditLog)
    
    // Keep only last 1000 logs in memory
    if (this.logs.length > 1000) {
      this.logs = this.logs.slice(-1000)
    }
    
    // Log to console for immediate visibility
    console.log(`🔍 AUDIT: ${params.action} on ${params.resource} by ${params.userName} (${params.userId})`)
    
    // In production, send to external logging service
    this.sendToLogService(auditLog)
  }
  
  static getRecentLogs(limit: number = 100): AuditLog[] {
    return this.logs.slice(-limit).reverse()
  }
  
  static getUserLogs(userId: string, limit: number = 50): AuditLog[] {
    return this.logs
      .filter(log => log.userId === userId)
      .slice(-limit)
      .reverse()
  }
  
  static getResourceLogs(resource: string, limit: number = 50): AuditLog[] {
    return this.logs
      .filter(log => log.resource === resource)
      .slice(-limit)
      .reverse()
  }
  
  private static sendToLogService(auditLog: AuditLog) {
    // In production, send to external logging service like:
    // - AWS CloudWatch
    // - Google Cloud Logging
    // - Datadog
    // - Custom logging API
    
    // For now, just structured console logging
    console.log(JSON.stringify({
      type: 'AUDIT_LOG',
      timestamp: auditLog.timestamp,
      userId: auditLog.userId,
      action: auditLog.action,
      resource: auditLog.resource,
      ip: auditLog.ip,
      details: auditLog.details
    }))
  }
  
  // Security actions
  static logLogin(userId: string, userName: string, ip: string, userAgent: string) {
    this.log({
      userId,
      userName,
      action: 'LOGIN',
      resource: 'AUTH',
      ip,
      userAgent
    })
  }
  
  static logLogout(userId: string, userName: string, ip: string) {
    this.log({
      userId,
      userName,
      action: 'LOGOUT',
      resource: 'AUTH',
      ip
    })
  }
  
  static logFailedLogin(email: string, ip: string, userAgent: string) {
    this.log({
      userId: 'unknown',
      userName: email,
      action: 'LOGIN_FAILED',
      resource: 'AUTH',
      details: { email },
      ip,
      userAgent
    })
  }
  
  // Analysis actions
  static logAnalysisCreated(userId: string, userName: string, jobId: string, coordinates: { lat: number, lon: number }, ip: string) {
    this.log({
      userId,
      userName,
      action: 'ANALYSIS_CREATED',
      resource: 'ANALYSIS',
      details: { jobId, coordinates },
      ip
    })
  }
  
  static logAnalysisViewed(userId: string, userName: string, jobId: string, ip: string) {
    this.log({
      userId,
      userName,
      action: 'ANALYSIS_VIEWED',
      resource: 'ANALYSIS',
      details: { jobId },
      ip
    })
  }
  
  static logAnalysisDownloaded(userId: string, userName: string, jobId: string, fileType: string, ip: string) {
    this.log({
      userId,
      userName,
      action: 'ANALYSIS_DOWNLOADED',
      resource: 'ANALYSIS',
      details: { jobId, fileType },
      ip
    })
  }
  
  // Security incidents
  static logSecurityIncident(action: string, details: Record<string, any>, ip: string, userAgent?: string) {
    this.log({
      userId: 'SYSTEM',
      userName: 'SECURITY_MONITOR',
      action: `SECURITY_${action}`,
      resource: 'SECURITY',
      details,
      ip,
      userAgent
    })
  }
}

// Export functions for backward compatibility
export const logAudit = AuditLogger.log
export const getRecentLogs = AuditLogger.getRecentLogs
export const getUserLogs = AuditLogger.getUserLogs
export const getResourceLogs = AuditLogger.getResourceLogs
export const logLogin = AuditLogger.logLogin
export const logLogout = AuditLogger.logLogout
export const logFailedLogin = AuditLogger.logFailedLogin
export const logAnalysisCreated = AuditLogger.logAnalysisCreated
export const logAnalysisViewed = AuditLogger.logAnalysisViewed
export const logAnalysisDownloaded = AuditLogger.logAnalysisDownloaded
export const logSecurityEvent = AuditLogger.logSecurityIncident
export const logSecurityIncident = AuditLogger.logSecurityIncident