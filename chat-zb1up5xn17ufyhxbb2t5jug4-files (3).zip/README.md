# IAGROSAT - Plataforma de Análise Espectral de Satélites

Uma plataforma web completa para análise espectral de imagens Sentinel-2, permitindo cálculo de índices de vegetação (NDVI, EVI, SAVI, GCI) com interface interativa e visualização de alta resolução.

## 🛰️ Funcionalidades

### Análise Espectral Completa
- **NDVI** - Índice de Vegetação por Diferença Normalizada
- **EVI** - Índice de Vegetação Melhorado  
- **SAVI** - Índice de Vegetação Ajustado ao Solo
- **GCI** - Índice de Clorofila Verde

### Interface Interativa
- Mapa interativo com seleção de coordenadas
- Ferramentas de desenho (ponto, retângulo, círculo, polígono)
- Busca por endereço/CEP/coordenadas
- Visualização em tempo real de coordenadas

### Processamento em Tempo Real
- Tracking de progresso com 10 etapas detalhadas
- Logs em tempo real do processamento
- Estimativas de tempo para cada etapa
- Notificações de status

### Resultados Avançados
- Imagens de alta resolução para cada índice
- Tiles XYZ para superzoom e navegação detalhada
- Estatísticas completas (min, max, média)
- Downloads individuais de todas as imagens
- Metadados completos da análise

## 🚀 Configuração

### 1. Configurar Backend
Crie um arquivo `.env.local` baseado no `.env.example`:

```bash
cp .env.example .env.local
```

Configure a URL do seu backend IAGROSAT:
```env
BACKEND_URL=http://localhost:8000
```

### 2. Instalar Dependências
```bash
npm install
```

### 3. Executar em Desenvolvimento
```bash
npm run dev
```

### 4. Build para Produção
```bash
npm run build
npm start
```

## 🗺️ Uso da Plataforma

### 1. Seleção de Área
- **Clique no mapa** para selecionar um ponto
- **Use ferramentas de desenho** para áreas customizadas
- **Busque por endereço** na barra de pesquisa
- **Coordenadas em tempo real** no canto inferior esquerdo

### 2. Iniciar Análise
- Coordenadas selecionadas aparecem no painel lateral
- Opcionalmente adicione AOI customizada (GeoJSON)
- Clique em "Iniciar Análise Espectral"

### 3. Acompanhar Progresso
- **Aba "Progresso"** mostra etapas em tempo real
- **Barra de progresso** com percentual concluído
- **Logs detalhados** de cada operação
- **Tempo estimado** para conclusão

### 4. Visualizar Resultados
- **Aba "Resultados"** com todos os índices
- **Tabs separadas** para NDVI, EVI, SAVI, GCI
- **Clique nas imagens** para visualização em tela cheia
- **Downloads individuais** de cada resultado

## 🔧 Arquitetura Técnica

### Frontend (Next.js)
- **React 18** com TypeScript
- **Tailwind CSS** para estilização
- **Leaflet** para mapas interativos
- **shadcn/ui** para componentes
- **Lucide React** para ícones

### Integração Backend
- **API Proxy** para comunicação com backend IAGROSAT
- **Polling automático** para status de jobs
- **Servir arquivos estáticos** (imagens, tiles)
- **Tratamento de erros** robusto

### Endpoints Disponíveis
- `POST /api/full-report?lat=X&lon=Y` - Iniciar análise
- `GET /api/full-report/status?job_id=X` - Verificar status
- `GET /api/static/[...path]` - Servir arquivos estáticos

## 🎨 Design System

### Paleta de Cores
- **Primary**: `#1e40af` (blue-800) - Confiabilidade técnica
- **Secondary**: `#059669` (emerald-600) - Vegetação/NDVI
- **Accent**: `#dc2626` (red-600) - Alertas
- **Background**: `#f8fafc` (slate-50) - Neutro científico
- **Text**: `#1e293b` (slate-800) - Alta legibilidade

### Tipografia
- **UI**: Inter (clean, moderno)
- **Dados técnicos**: JetBrains Mono (legibilidade)

## 📊 Fluxo de Processamento

### Etapas do Backend (100-150s total)
1. **Busca imagens Sentinel-2** (5-10s)
2. **Download das bandas** (10-40s) 
3. **Validação de cobertura** (2-5s)
4. **Recorte para AOI** (2-5s)
5. **Remoção de nuvens** (2-3s)
6. **Geração RGB** (3-6s)
7. **Cálculo de índices** (5-10s)
8. **Mapas coloridos** (3-6s)
9. **Tiles superzoom** (20-40s)
10. **Finalização** (1-2s)

## 🛠️ Desenvolvimento

### Estrutura de Componentes
```
components/
├── header.tsx              # Cabeçalho da aplicação
├── map-container.tsx       # Mapa interativo Leaflet
├── side-panel.tsx          # Painel lateral com tabs
├── analysis-control.tsx    # Controles de análise
├── progress-tracker.tsx    # Tracking de progresso
├── results-viewer.tsx      # Visualização de resultados
└── logs-viewer.tsx         # Logs técnicos
```

### APIs
```
app/api/
├── full-report/
│   ├── route.ts           # Iniciar análise
│   └── status/
│       └── route.ts       # Status do job
└── static/
    └── [...path]/
        └── route.ts       # Arquivos estáticos
```

## 🔍 Debugging

### Logs do Sistema
- **Browser logs**: Console do navegador
- **Server logs**: Logs do Next.js
- **Backend logs**: Via endpoint de status

### Endpoints de Debug
- Todos endpoints fazem log detalhado
- Tempos de resposta monitorados
- Erros capturados e reportados

---

**Desenvolvido para integração completa com backend IAGROSAT** 🛰️