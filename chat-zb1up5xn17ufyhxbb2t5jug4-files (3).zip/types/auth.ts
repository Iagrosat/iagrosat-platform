export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  company?: string;
  department?: string;
  permissions: Permission[];
  createdAt: string;
  lastLogin?: string;
  isActive: boolean;
  avatar?: string;
}

export enum UserRole {
  SUPER_ADMIN = 'SUPER_ADMIN',
  ADMIN = 'ADMIN',
  MANAGER = 'MANAGER',
  ANALYST = 'ANALYST',
  VIEWER = 'VIEWER',
}

export enum Permission {
  // Analysis permissions
  CREATE_ANALYSIS = 'CREATE_ANALYSIS',
  VIEW_ANALYSIS = 'VIEW_ANALYSIS',
  DELETE_ANALYSIS = 'DELETE_ANALYSIS',
  EXPORT_ANALYSIS = 'EXPORT_ANALYSIS',
  
  // User management
  MANAGE_USERS = 'MANAGE_USERS',
  VIEW_USERS = 'VIEW_USERS',
  INVITE_USERS = 'INVITE_USERS',
  
  // System administration
  MANAGE_SYSTEM = 'MANAGE_SYSTEM',
  VIEW_AUDIT_LOGS = 'VIEW_AUDIT_LOGS',
  MANAGE_SETTINGS = 'MANAGE_SETTINGS',
  
  // Data access
  ACCESS_HISTORICAL_DATA = 'ACCESS_HISTORICAL_DATA',
  BULK_OPERATIONS = 'BULK_OPERATIONS',
}

export interface AuthSession {
  user: User;
  token: string;
  expires: string;
}

export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  action: string;
  resource: string;
  details?: Record<string, any>;
  timestamp: string;
  ip?: string;
  userAgent?: string;
}

export interface Company {
  id: string;
  name: string;
  domain: string;
  settings: CompanySettings;
  createdAt: string;
  isActive: boolean;
  logo?: string;
}

export interface CompanySettings {
  maxUsers: number;
  maxAnalysisPerMonth: number;
  retentionDays: number;
  allowedDomains: string[];
  requireTwoFactor: boolean;
  allowGuestAccess: boolean;
  customBranding: boolean;
}