'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { MapContainer } from '@/components/map-container'

export default function DesignHolografico() {
  const router = useRouter()
  const [selectedTool, setSelectedTool] = useState<string | null>(null)
  const [currentCoordinates, setCurrentCoordinates] = useState({ lat: -23.5505, lng: -46.6333 })
  const [selectedArea, setSelectedArea] = useState({ points: 1, area: 0.25 })
  const [isLoading, setIsLoading] = useState(false)
  const [selectedLocation, setSelectedLocation] = useState<{lat: number, lon: number} | null>({ lat: -23.5505, lon: -46.6333 })
  const [searchQuery, setSearchQuery] = useState('')
  const [manualLat, setManualLat] = useState('')
  const [manualLng, setManualLng] = useState('')

  const processAnalysis = () => {
    console.log("🚀 Starting analysis process")
    setIsLoading(true)
    const jobId = `job-${Date.now()}`
    router.push(`/results/${jobId}`)
  };

  const handleSearch = async () => {
    const query = searchQuery.trim()
    if (!query) return

    console.log("🔍 Searching for:", query)
    
    try {
      const coordMatch = query.match(/(-?\d+\.?\d*),?\s*(-?\d+\.?\d*)/)
      if (coordMatch) {
        const lat = parseFloat(coordMatch[1])
        const lng = parseFloat(coordMatch[2])
        handleCoordinateUpdate(lat, lng)
        setSearchQuery('')
        return
      }
      
      const geocodeUrl = `https://geocode-api.arcgis.com/arcgis/rest/services/World/GeocodeServer/findAddressCandidates?singleLine=${encodeURIComponent(query)}&maxLocations=1&outFields=*&f=json`
      const response = await fetch(geocodeUrl)
      const data = await response.json()
      
      if (data.candidates && data.candidates.length > 0) {
        const result = data.candidates[0]
        const lat = result.location.y
        const lng = result.location.x
        handleCoordinateUpdate(lat, lng)
        setSearchQuery('')
      } else {
        alert('Local não encontrado. Tente outro nome.')
      }
    } catch (error) {
      console.error('Search error:', error)
      alert('Erro na busca. Tente novamente.')
    }
  };

  const handleCoordinateUpdate = (lat: number, lng: number) => {
    setCurrentCoordinates({ lat, lng })
    setSelectedLocation({ lat, lon: lng })
    
    if ((window as any).mapFunctions) {
      (window as any).mapFunctions.updateCoordinates(lat, lng)
    }
  };

  const handleManualCoordinates = () => {
    const lat = parseFloat(manualLat)
    const lng = parseFloat(manualLng)
    
    if (!isNaN(lat) && !isNaN(lng)) {
      handleCoordinateUpdate(lat, lng)
      setManualLat('')
      setManualLng('')
    }
  };

  const activateAreaTool = () => {
    if ((window as any).mapFunctions) {
      (window as any).mapFunctions.activateAreaTool()
    }
    setSelectedTool('area')
  };

  const activatePolygonTool = () => {
    if ((window as any).mapFunctions) {
      (window as any).mapFunctions.activatePolygonTool()
    }
    setSelectedTool('polygon')
  };

  const activatePointTool = () => {
    if ((window as any).mapFunctions) {
      (window as any).mapFunctions.activatePointTool()
    }
    setSelectedTool('point')
  };

  const clearSelection = () => {
    if ((window as any).mapFunctions) {
      (window as any).mapFunctions.clearSelection()
    }
    setSelectedTool(null)
    setSelectedArea({ points: 1, area: 0.25 })
  };

  return (
    <div className="h-screen bg-gradient-to-br from-indigo-950 via-slate-900 to-violet-950 flex flex-col overflow-hidden relative">
      {/* Holographic Grid Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/10 to-violet-500/10"></div>
        <div className="absolute top-1/3 left-1/3 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/3 right-1/3 w-80 h-80 bg-violet-500/5 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>

      {/* Header - HOLOGRAPHIC */}
      <header className="bg-black/80 backdrop-blur-xl border-b border-violet-500/30 px-8 py-6 flex items-center justify-between flex-shrink-0 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-violet-500/5 to-blue-500/5"></div>
        <div className="flex items-center space-x-6 relative z-10">
          <div className="relative w-20 h-20">
            <div className="absolute inset-0 w-20 h-20 bg-gradient-to-br from-violet-400 via-blue-500 to-indigo-400 rounded-full opacity-30 blur-sm animate-pulse"></div>
            <div className="absolute inset-2 w-16 h-16 bg-gradient-to-br from-violet-400 via-blue-500 to-indigo-400 rounded-full flex items-center justify-center shadow-2xl shadow-violet-500/60 border border-violet-300/30">
              <div className="animate-spin" style={{ animationDuration: '12s' }}>
                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white drop-shadow-2xl">
                  <path d="M13 7 9 3 5 7l4 4"></path>
                  <path d="m17 11 4 4-4 4-4-4"></path>
                  <path d="m8 12 4 4 6-6-4-4Z"></path>
                  <path d="m16 8 3-3"></path>
                  <path d="M9 21a6 6 0 0 0-6-6"></path>
                </svg>
              </div>
            </div>
            <div className="absolute inset-0 bg-gradient-to-br from-violet-400 via-blue-500 to-indigo-400 rounded-full opacity-20 blur-xl animate-pulse"></div>
          </div>
          <div className="space-y-1">
            <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-violet-400 via-blue-400 to-indigo-400 font-fira tracking-wide filter drop-shadow-2xl">iAgroSat</h1>
            <p className="text-violet-300 text-sm font-fira font-bold tracking-[0.3em] uppercase">HOLOGRAPHIC INTERFACE</p>
          </div>
        </div>
        <div className="flex items-center space-x-6 relative z-10">
          <div className="flex items-center space-x-3">
            <div className="w-4 h-4 bg-violet-400 rounded-full animate-pulse shadow-lg shadow-violet-500/60"></div>
            <span className="text-sm text-violet-300 font-fira font-bold tracking-wider">BACKEND SYNCHRONIZED</span>
          </div>
          <div className="flex items-center space-x-3">
            <div className="w-4 h-4 bg-blue-400 rounded-full animate-pulse shadow-lg shadow-blue-500/60"></div>
            <span className="text-sm text-blue-300 font-fira font-bold tracking-wider">SENTINEL LINKED</span>
          </div>
        </div>
      </header>

      {/* Main Content - HOLOGRAPHIC */}
      <div className="flex flex-1 overflow-hidden relative">
        {/* Holographic Control Panel */}
        <div className="w-96 bg-black/70 backdrop-blur-xl border-r border-violet-500/30 flex flex-col relative">
          <div className="absolute inset-0 bg-gradient-to-b from-violet-500/5 to-blue-500/5"></div>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_50%,rgba(139,69,244,0.1),transparent_70%)]"></div>
          <div className="p-8 flex-1 flex flex-col justify-between space-y-8 relative z-10">
            <div className="space-y-8">
              {/* HOLOGRAPHIC SEARCH */}
              <div className="space-y-6">
                <h3 className="text-violet-400 text-xl font-black tracking-widest font-fira flex items-center">
                  <div className="w-6 h-6 mr-3 bg-gradient-to-br from-violet-400 to-blue-400 rounded-full flex items-center justify-center shadow-lg shadow-violet-500/50">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                      <circle cx="11" cy="11" r="8"/>
                      <path d="m21 21-4.35-4.35"/>
                    </svg>
                  </div>
                  BUSCAR LOCAL
                </h3>
                
                <div className="space-y-4">
                  <div className="relative group">
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="São Paulo, Rio de Janeiro, Brasília..."
                      className="w-full px-6 py-4 bg-black/60 text-violet-300 border-2 border-violet-500/40 focus:border-violet-400 focus:outline-none text-base placeholder-violet-500/60 transition-all duration-300 font-fira rounded-xl backdrop-blur-sm shadow-lg shadow-violet-500/20"
                      onKeyPress={(e) => {
                        if (e.key === 'Enter') {
                          handleSearch()
                        }
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-r from-violet-400/10 to-blue-400/10 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
                    <div className="absolute inset-0 border-2 border-violet-400/20 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
                  </div>
                  
                  <button 
                    onClick={handleSearch}
                    className="w-full bg-gradient-to-r from-violet-500 to-blue-500 hover:from-violet-600 hover:to-blue-600 text-white py-4 font-black tracking-widest transition-all duration-300 text-base font-fira transform hover:scale-105 rounded-xl shadow-2xl shadow-violet-500/40 border border-violet-400/40"
                  >
                    BUSCAR
                  </button>
                </div>
              </div>

              {/* HOLOGRAPHIC COORDINATES */}
              <div className="space-y-6">
                <h3 className="text-blue-400 text-xl font-black tracking-widest font-fira flex items-center">
                  <div className="w-6 h-6 mr-3 bg-gradient-to-br from-blue-400 to-indigo-400 rounded-full flex items-center justify-center shadow-lg shadow-blue-500/50">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                      <circle cx="12" cy="10" r="3"/>
                    </svg>
                  </div>
                  COORDENADAS
                </h3>
                
                <div className="space-y-3">
                  <input
                    type="number"
                    value={manualLat}
                    onChange={(e) => setManualLat(e.target.value)}
                    placeholder="Latitude"
                    className="w-full px-4 py-3 bg-black/60 text-blue-300 border-2 border-blue-500/40 focus:border-blue-400 focus:outline-none text-sm font-fira rounded-xl shadow-lg shadow-blue-500/20"
                    step="any"
                  />
                  <input
                    type="number"
                    value={manualLng}
                    onChange={(e) => setManualLng(e.target.value)}
                    placeholder="Longitude"
                    className="w-full px-4 py-3 bg-black/60 text-blue-300 border-2 border-blue-500/40 focus:border-blue-400 focus:outline-none text-sm font-fira rounded-xl shadow-lg shadow-blue-500/20"
                    step="any"
                  />
                  <button 
                    onClick={handleManualCoordinates}
                    className="w-full bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600 text-white py-3 font-black tracking-widest transition-all duration-300 text-sm font-fira transform hover:scale-105 rounded-xl shadow-2xl shadow-blue-500/40"
                  >
                    IR
                  </button>
                </div>
              </div>

              {/* HOLOGRAPHIC SELECTION */}
              <div className="space-y-6">
                <h3 className="text-indigo-400 text-xl font-black tracking-widest font-fira flex items-center">
                  <div className="w-6 h-6 mr-3 bg-gradient-to-br from-indigo-400 to-purple-400 rounded-full flex items-center justify-center shadow-lg shadow-indigo-500/50">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                      <circle cx="12" cy="12" r="3"/>
                      <path d="M12 1v6m0 12v6"/>
                    </svg>
                  </div>
                  SELEÇÃO ATIVA
                </h3>
                
                <div className="bg-gradient-to-br from-indigo-900/40 to-violet-900/40 border-2 border-indigo-500/40 rounded-2xl p-6 backdrop-blur-sm shadow-2xl shadow-indigo-500/30">
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-indigo-300 text-sm font-fira font-bold tracking-wider">PONTOS:</span>
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-indigo-400 rounded-full animate-pulse"></div>
                        <span className="text-indigo-400 text-xl font-black font-fira">{selectedArea.points}</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-indigo-300 text-sm font-fira font-bold tracking-wider">ÁREA:</span>
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-violet-400 rounded-full animate-pulse"></div>
                        <span className="text-violet-400 text-xl font-black font-fira">{selectedArea.area.toFixed(2)} km²</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-indigo-300 text-sm font-fira font-bold tracking-wider">FERRAMENTA:</span>
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                        <span className="text-blue-400 text-sm font-black font-fira">{selectedTool?.toUpperCase() || 'STANDBY'}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* HOLOGRAPHIC ACTIONS */}
            <div className="space-y-4">
              <button 
                onClick={processAnalysis}
                className="w-full bg-gradient-to-r from-violet-500 via-blue-500 to-indigo-500 hover:from-violet-600 hover:via-blue-600 hover:to-indigo-600 text-white py-5 font-black tracking-widest transition-all duration-300 text-lg font-fira transform hover:scale-105 rounded-xl shadow-2xl shadow-violet-500/50 border border-violet-400/40"
              >
                PROCESSAR ANÁLISE
              </button>
              
              <button 
                onClick={clearSelection}
                className="w-full bg-gradient-to-r from-red-500 to-rose-500 hover:from-red-600 hover:to-rose-600 text-white py-4 font-black tracking-widest transition-all duration-300 text-base font-fira transform hover:scale-105 rounded-xl shadow-2xl shadow-red-500/40"
              >
                LIMPAR SELEÇÃO
              </button>
            </div>
          </div>
        </div>

        {/* Map - HOLOGRAPHIC */}
        <div className="flex-1 relative bg-black/70">
          <div className="h-full relative">
            <MapContainer
              onCoordinateSelect={(coords) => {
                setSelectedLocation({ lat: coords.lat, lon: coords.lon })
                setCurrentCoordinates({ lat: coords.lat, lng: coords.lon })
              }}
              onAreaSelect={(area) => {
                setSelectedArea({ 
                  points: 1, 
                  area: area.area ? area.area / 1000000 : 0.25 
                })
              }}
              onAnalysisStart={() => {
                processAnalysis()
              }}
              onToolActivated={(tool) => {
                setSelectedTool(tool)
              }}
            />

            {/* HOLOGRAPHIC Map Tools */}
            <div className="absolute top-6 right-6 flex flex-col space-y-3 z-50">
              <button 
                onClick={activateAreaTool}
                className={`w-16 h-16 flex items-center justify-center transition-all duration-300 rounded-2xl backdrop-blur-sm border-2 ${
                  selectedTool === 'area' 
                    ? 'bg-gradient-to-br from-violet-500 to-blue-500 shadow-2xl shadow-violet-500/70 border-violet-400/70' 
                    : 'bg-black/80 hover:bg-black/60 border-violet-500/40 hover:border-violet-400/70 hover:shadow-2xl hover:shadow-violet-500/40'
                }`}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                  <rect width="18" height="18" x="3" y="3" rx="2"/>
                </svg>
              </button>
              
              <button 
                onClick={activatePolygonTool}
                className={`w-16 h-16 flex items-center justify-center transition-all duration-300 rounded-2xl backdrop-blur-sm border-2 ${
                  selectedTool === 'polygon' 
                    ? 'bg-gradient-to-br from-blue-500 to-indigo-500 shadow-2xl shadow-blue-500/70 border-blue-400/70' 
                    : 'bg-black/80 hover:bg-black/60 border-blue-500/40 hover:border-blue-400/70 hover:shadow-2xl hover:shadow-blue-500/40'
                }`}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                  <polygon points="13,2 3,14 12,14 11,22 21,10 12,10"/>
                </svg>
              </button>
              
              <button 
                onClick={activatePointTool}
                className={`w-16 h-16 flex items-center justify-center transition-all duration-300 rounded-2xl backdrop-blur-sm border-2 ${
                  selectedTool === 'point' 
                    ? 'bg-gradient-to-br from-indigo-500 to-purple-500 shadow-2xl shadow-indigo-500/70 border-indigo-400/70' 
                    : 'bg-black/80 hover:bg-black/60 border-indigo-500/40 hover:border-indigo-400/70 hover:shadow-2xl hover:shadow-indigo-500/40'
                }`}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                  <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                  <circle cx="12" cy="10" r="3"/>
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* HOLOGRAPHIC Footer */}
      <footer className="bg-black/80 backdrop-blur-xl border-t border-violet-500/30 px-8 py-6 flex items-center justify-center flex-shrink-0 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-violet-500/5 to-blue-500/5"></div>
        <div className="flex items-center space-x-8 relative z-10">
          <div className="flex items-center space-x-3">
            <div className="relative w-12 h-12">
              <div className="absolute inset-0 w-12 h-12 bg-gradient-to-br from-violet-400 via-blue-500 to-indigo-400 rounded-full opacity-30 blur-sm animate-pulse"></div>
              <div className="absolute inset-1 w-10 h-10 bg-gradient-to-br from-violet-400 via-blue-500 to-indigo-400 rounded-full flex items-center justify-center">
                <div className="animate-spin" style={{ animationDuration: '12s' }}>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                    <path d="M13 7 9 3 5 7l4 4"></path>
                    <path d="m17 11 4 4-4 4-4-4"></path>
                    <path d="m8 12 4 4 6-6-4-4Z"></path>
                    <path d="m16 8 3-3"></path>
                    <path d="M9 21a6 6 0 0 0-6-6"></path>
                  </svg>
                </div>
              </div>
            </div>
            <span className="text-violet-300 text-base font-black font-fira tracking-wider">iAgroSat HOLO</span>
          </div>
          <div className="text-violet-400 text-sm font-fira font-bold tracking-wider">
            REG: 61.579.333/0001-00
          </div>
          <div className="text-blue-400 text-sm font-fira font-bold tracking-wider">
            POWERED BY SENTINEL-2
          </div>
          <div className="text-indigo-400 text-sm font-fira font-bold tracking-wider">
            © 2024 HOLOGRAPHIC RIGHTS
          </div>
        </div>
      </footer>
    </div>
  )
}