'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function SatelliteOptions() {
  const [selectedSatellite, setSelectedSatellite] = useState(null);
  const [selectedFont, setSelectedFont] = useState('space-grotesk');

  const satellites = [
    // DESIGN ESCOLHIDO - Lucide Satellite
    {
      id: 'professional',
      name: 'Lucide Satellite Elite',
      description: 'Design profissional do Lucide Icons com animação suave',
      component: (
        <div className="bg-gradient-to-br from-green-600 to-yellow-500 p-6 rounded-lg border-2 border-yellow-400 relative">
          <div className="absolute -top-2 -right-2 bg-yellow-400 text-black px-3 py-1 rounded-full text-sm font-bold">
            ESCOLHIDO ✓
          </div>
          <h3 className="text-xl font-semibold text-white mb-4">Lucide Satellite Elite</h3>
          <div className="w-24 h-24 mx-auto mb-4 bg-gray-800 rounded-lg flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-400 animate-spin" style={{animationDuration: '8s'}}>
              <path d="M13 7 9 3 5 7l4 4"></path>
              <path d="m17 11 4 4-4 4-4-4"></path>
              <path d="m8 12 4 4 6-6-4-4Z"></path>
              <path d="m16 8 3-3"></path>
              <path d="M9 21a6 6 0 0 0-6-6"></path>
            </svg>
          </div>
          <p className="text-white text-sm">Design profissional do Lucide Icons com animação suave</p>
        </div>
      )
    },
    // SpaceX Style - Minimalista e Moderno
    {
      id: 'spacex',
      name: 'SpaceX Elite',
      description: 'Design minimalista inspirado na SpaceX',
      component: (
        <div className="relative w-16 h-16">
          <div className="w-12 h-12 bg-black rounded-lg flex items-center justify-center border-2 border-white shadow-2xl">
            <div className="relative">
              <div className="w-6 h-1 bg-white rounded-full"></div>
              <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-0.5 h-6 bg-white rounded-full"></div>
              <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-3 h-3 border-2 border-white rounded-full bg-emerald-400"></div>
              <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-emerald-400 rounded-full animate-pulse"></div>
            </div>
          </div>
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-400 rounded-full animate-pulse"></div>
        </div>
      )
    },
    // NASA Style - Clássico e Técnico
    {
      id: 'nasa',
      name: 'NASA Classic',
      description: 'Design técnico inspirado na NASA',
      component: (
        <div className="relative w-16 h-16">
          <div className="w-12 h-12 bg-gradient-to-br from-blue-800 to-blue-900 rounded-full flex items-center justify-center shadow-2xl border-2 border-blue-400">
            <div className="relative">
              <svg viewBox="0 0 40 40" className="w-8 h-8 text-white">
                <circle cx="20" cy="20" r="15" fill="none" stroke="currentColor" strokeWidth="1"/>
                <circle cx="20" cy="20" r="8" fill="none" stroke="currentColor" strokeWidth="1"/>
                <circle cx="20" cy="20" r="3" fill="currentColor"/>
                <path d="M20 5 L25 15 L35 15 L27 23 L30 33 L20 27 L10 33 L13 23 L5 15 L15 15 Z" fill="none" stroke="currentColor" strokeWidth="0.5"/>
              </svg>
            </div>
          </div>
          <div className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
          <div className="absolute bottom-0 left-0 w-2 h-2 bg-yellow-400 rounded-full animate-pulse" style={{animationDelay: '0.5s'}}></div>
        </div>
      )
    },
    // ESA Style - Europeu e Sofisticado
    {
      id: 'esa',
      name: 'ESA European',
      description: 'Design sofisticado inspirado na ESA',
      component: (
        <div className="relative w-16 h-16">
          <div className="w-12 h-12 bg-gradient-to-br from-purple-700 to-purple-900 rounded-xl flex items-center justify-center shadow-2xl border-2 border-purple-400">
            <div className="relative">
              <div className="w-8 h-8 border-2 border-purple-200 rounded-full flex items-center justify-center">
                <div className="w-4 h-4 bg-purple-200 rounded-full flex items-center justify-center">
                  <div className="w-2 h-2 bg-purple-700 rounded-full"></div>
                </div>
              </div>
              <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-4 h-1 bg-purple-200 rounded-full"></div>
              <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-4 h-1 bg-purple-200 rounded-full"></div>
              <div className="absolute -left-2 top-1/2 transform -translate-y-1/2 w-1 h-4 bg-purple-200 rounded-full"></div>
              <div className="absolute -right-2 top-1/2 transform -translate-y-1/2 w-1 h-4 bg-purple-200 rounded-full"></div>
            </div>
          </div>
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-purple-400 rounded-full animate-pulse"></div>
        </div>
      )
    },
    // Blue Origin Style - Futurista
    {
      id: 'blue-origin',
      name: 'Blue Origin',
      description: 'Design futurista inspirado na Blue Origin',
      component: (
        <div className="relative w-16 h-16">
          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-700 rounded-2xl flex items-center justify-center shadow-2xl border-2 border-blue-300">
            <div className="relative">
              <div className="w-8 h-8 bg-blue-200 rounded-full flex items-center justify-center">
                <div className="w-4 h-4 bg-blue-600 rounded-full animate-pulse"></div>
              </div>
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 w-2 h-6 bg-blue-200 rounded-full"></div>
              <div className="absolute -bottom-3 left-1/2 transform -translate-x-1/2 w-2 h-6 bg-blue-200 rounded-full"></div>
              <div className="absolute -left-3 top-1/2 transform -translate-y-1/2 w-6 h-2 bg-blue-200 rounded-full"></div>
              <div className="absolute -right-3 top-1/2 transform -translate-y-1/2 w-6 h-2 bg-blue-200 rounded-full"></div>
            </div>
          </div>
          <div className="absolute top-0 left-0 w-full h-full border-2 border-blue-300 rounded-2xl animate-spin" style={{animation: 'spin 12s linear infinite'}}></div>
        </div>
      )
    },
    // Virgin Galactic Style - Dinâmico
    {
      id: 'virgin',
      name: 'Virgin Galactic',
      description: 'Design dinâmico inspirado na Virgin Galactic',
      component: (
        <div className="relative w-16 h-16">
          <div className="w-12 h-12 bg-gradient-to-br from-red-600 to-red-800 rounded-full flex items-center justify-center shadow-2xl border-2 border-red-400">
            <div className="relative">
              <div className="w-6 h-6 bg-red-100 rounded-full flex items-center justify-center">
                <div className="w-3 h-3 bg-red-600 rounded-full animate-pulse"></div>
              </div>
              <div className="absolute -top-2 -left-2 w-3 h-3 bg-red-300 rounded-full"></div>
              <div className="absolute -top-2 -right-2 w-3 h-3 bg-red-300 rounded-full"></div>
              <div className="absolute -bottom-2 -left-2 w-3 h-3 bg-red-300 rounded-full"></div>
              <div className="absolute -bottom-2 -right-2 w-3 h-3 bg-red-300 rounded-full"></div>
            </div>
          </div>
          <div className="absolute inset-0 border-2 border-red-400 rounded-full animate-ping"></div>
        </div>
      )
    },
    // Abstrato Cristal
    {
      id: 'crystal',
      name: 'Cristal Orbital',
      description: 'Design abstrato em cristal',
      component: (
        <div className="relative w-16 h-16">
          <div className="w-12 h-12 bg-gradient-to-br from-cyan-400 to-cyan-600 rounded-lg rotate-45 flex items-center justify-center shadow-2xl border-2 border-cyan-200">
            <div className="relative -rotate-45">
              <div className="w-6 h-6 bg-white rounded-lg flex items-center justify-center">
                <div className="w-3 h-3 bg-cyan-600 rounded-full animate-pulse"></div>
              </div>
              <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-2 h-2 bg-cyan-200 rounded-full"></div>
              <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-2 h-2 bg-cyan-200 rounded-full"></div>
              <div className="absolute -left-1 top-1/2 transform -translate-y-1/2 w-2 h-2 bg-cyan-200 rounded-full"></div>
              <div className="absolute -right-1 top-1/2 transform -translate-y-1/2 w-2 h-2 bg-cyan-200 rounded-full"></div>
            </div>
          </div>
          <div className="absolute inset-0 border-2 border-cyan-300 rounded-lg rotate-45 animate-pulse"></div>
        </div>
      )
    },
    // Hexagonal Militar
    {
      id: 'military',
      name: 'Hexagonal Militar',
      description: 'Design militar hexagonal',
      component: (
        <div className="relative w-16 h-16">
          <div className="w-12 h-12 bg-gradient-to-br from-green-700 to-green-900 mx-auto mt-2 flex items-center justify-center shadow-2xl border-2 border-green-400" style={{clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)'}}>
            <div className="relative">
              <div className="w-6 h-6 bg-green-200 rounded-full flex items-center justify-center">
                <div className="w-3 h-3 bg-green-800 rounded-full animate-pulse"></div>
              </div>
              <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-1 h-4 bg-green-200"></div>
              <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-1 h-4 bg-green-200"></div>
            </div>
          </div>
          <div className="absolute top-0 left-0 w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
          <div className="absolute bottom-0 right-0 w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
        </div>
      )
    },
    // Quantum Tech
    {
      id: 'quantum',
      name: 'Quantum Tech',
      description: 'Design tecnológico quantum',
      component: (
        <div className="relative w-16 h-16">
          <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center shadow-2xl border-2 border-purple-300">
            <div className="relative">
              <div className="w-6 h-6 border-2 border-purple-100 rounded-full flex items-center justify-center">
                <div className="w-2 h-2 bg-purple-100 rounded-full animate-pulse"></div>
              </div>
              <div className="absolute inset-0 border-2 border-purple-200 rounded-full animate-spin" style={{animation: 'spin 3s linear infinite'}}></div>
              <div className="absolute inset-0 border-2 border-pink-200 rounded-full animate-spin" style={{animation: 'spin 4s linear infinite reverse'}}></div>
            </div>
          </div>
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-pink-400 rounded-full animate-bounce"></div>
          <div className="absolute -bottom-1 -left-1 w-3 h-3 bg-purple-400 rounded-full animate-bounce" style={{animationDelay: '0.5s'}}></div>
        </div>
      )
    },
    // Orbital Station
    {
      id: 'station',
      name: 'Estação Orbital',
      description: 'Design de estação espacial',
      component: (
        <div className="relative w-16 h-16">
          <div className="w-12 h-12 bg-gradient-to-br from-slate-600 to-slate-800 rounded-lg flex items-center justify-center shadow-2xl border-2 border-slate-400">
            <div className="relative">
              <div className="w-6 h-1 bg-slate-200 rounded-full"></div>
              <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-1 h-6 bg-slate-200 rounded-full"></div>
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-3 h-3 bg-slate-200 rounded-full flex items-center justify-center">
                <div className="w-1.5 h-1.5 bg-slate-800 rounded-full animate-pulse"></div>
              </div>
              <div className="absolute -top-1 -left-1 w-2 h-2 bg-blue-400 rounded-full"></div>
              <div className="absolute -top-1 -right-1 w-2 h-2 bg-blue-400 rounded-full"></div>
              <div className="absolute -bottom-1 -left-1 w-2 h-2 bg-blue-400 rounded-full"></div>
              <div className="absolute -bottom-1 -right-1 w-2 h-2 bg-blue-400 rounded-full"></div>
            </div>
          </div>
          <div className="absolute inset-0 border-2 border-slate-300 rounded-lg animate-pulse"></div>
        </div>
      )
    },
    // Starlink Style
    {
      id: 'starlink',
      name: 'Starlink Network',
      description: 'Design inspirado no Starlink',
      component: (
        <div className="relative w-16 h-16">
          <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-orange-700 rounded-2xl flex items-center justify-center shadow-2xl border-2 border-orange-300">
            <div className="relative">
              <div className="w-4 h-4 bg-orange-100 rounded-full flex items-center justify-center">
                <div className="w-2 h-2 bg-orange-700 rounded-full animate-pulse"></div>
              </div>
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-orange-200 rounded-full"></div>
              <div className="absolute -bottom-3 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-orange-200 rounded-full"></div>
              <div className="absolute -left-3 top-1/2 transform -translate-y-1/2 w-1 h-1 bg-orange-200 rounded-full"></div>
              <div className="absolute -right-3 top-1/2 transform -translate-y-1/2 w-1 h-1 bg-orange-200 rounded-full"></div>
              <div className="absolute -top-2 -left-2 w-1 h-1 bg-orange-200 rounded-full"></div>
              <div className="absolute -top-2 -right-2 w-1 h-1 bg-orange-200 rounded-full"></div>
              <div className="absolute -bottom-2 -left-2 w-1 h-1 bg-orange-200 rounded-full"></div>
              <div className="absolute -bottom-2 -right-2 w-1 h-1 bg-orange-200 rounded-full"></div>
            </div>
          </div>
          <div className="absolute inset-0 border border-orange-300 rounded-2xl animate-pulse"></div>
        </div>
      )
    },
    // Holographic
    {
      id: 'holographic',
      name: 'Holográfico',
      description: 'Design holográfico futurista',
      component: (
        <div className="relative w-16 h-16">
          <div className="w-12 h-12 bg-gradient-to-br from-teal-400 via-blue-500 to-purple-600 rounded-full flex items-center justify-center shadow-2xl border-2 border-teal-300">
            <div className="relative">
              <div className="w-6 h-6 bg-white/20 backdrop-blur rounded-full flex items-center justify-center">
                <div className="w-3 h-3 bg-white rounded-full animate-pulse"></div>
              </div>
              <div className="absolute inset-0 border-2 border-white/30 rounded-full animate-spin" style={{animation: 'spin 2s linear infinite'}}></div>
              <div className="absolute inset-0 border-2 border-teal-300/50 rounded-full animate-spin" style={{animation: 'spin 3s linear infinite reverse'}}></div>
              <div className="absolute inset-0 border-2 border-purple-300/50 rounded-full animate-spin" style={{animation: 'spin 4s linear infinite'}}></div>
            </div>
          </div>
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-gradient-to-br from-teal-400 to-purple-600 rounded-full animate-pulse"></div>
        </div>
      )
    }
  ];

  const fonts = [
    { id: 'inter', name: 'Inter', class: 'font-sans', description: 'Moderno e limpo' },
    { id: 'mono', name: 'JetBrains Mono', class: 'font-mono', description: 'Código profissional' },
    { id: 'orbitron', name: 'Orbitron', class: 'font-mono', description: 'Futurista espacial' },
    { id: 'roboto', name: 'Roboto', class: 'font-sans', description: 'Google Material' },
    { id: 'fira', name: 'Fira Code', class: 'font-mono', description: 'Developer favorito' },
    { id: 'space', name: 'Space Grotesk', class: 'font-sans', description: 'Tecnológico moderno' },
    { id: 'source', name: 'Source Code Pro', class: 'font-mono', description: 'Adobe professional' },
    { id: 'ibm', name: 'IBM Plex', class: 'font-sans', description: 'Corporativo elegante' }
  ];

  return (
    <div className="min-h-screen bg-slate-900 p-8">
      <div className="max-w-7xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-white mb-4">Configuração Visual</h1>
          <p className="text-slate-300 text-lg">Escolha o satélite e tipografia perfeitos para o iAgroSat</p>
        </div>

        {/* Satélites */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold text-emerald-400 mb-8 text-center">🛰️ Designs de Satélite</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* DESIGN ESCOLHIDO - Lucide Satellite */}
            <div className="bg-gradient-to-br from-green-600 to-yellow-500 p-6 rounded-lg border-2 border-yellow-400 relative">
              <div className="absolute -top-2 -right-2 bg-yellow-400 text-black px-3 py-1 rounded-full text-sm font-bold">
                ESCOLHIDO ✓
              </div>
              <h3 className="text-xl font-semibold text-white mb-4">Lucide Satellite Elite</h3>
              <div className="w-24 h-24 mx-auto mb-4 bg-gray-800 rounded-lg flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-400 animate-spin" style={{animationDuration: '8s'}}>
                  <path d="M13 7 9 3 5 7l4 4"></path>
                  <path d="m17 11 4 4-4 4-4-4"></path>
                  <path d="m8 12 4 4 6-6-4-4Z"></path>
                  <path d="m16 8 3-3"></path>
                  <path d="M9 21a6 6 0 0 0-6-6"></path>
                </svg>
              </div>
              <p className="text-white text-sm">Design profissional do Lucide Icons com animação suave</p>
            </div>

            {/* Outras opções com opacity reduzida */}
            <div className="bg-gray-800 p-6 rounded-lg opacity-50">
              <h3 className="text-xl font-semibold text-green-400 mb-4">Alternativo 1</h3>
              <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-yellow-500 to-green-600 rounded-full flex items-center justify-center relative">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                  <path d="M12 2a10 10 0 0 1 7.07 17.07l-2.05-2.05a6 6 0 0 0-8.54-8.54l-2.05-2.05A10 10 0 0 1 12 2"></path>
                  <path d="M12 22a10 10 0 0 1-7.07-17.07l2.05 2.05a6 6 0 0 0 8.54 8.54l2.05 2.05A10 10 0 0 1 12 22"></path>
                </svg>
              </div>
              <p className="text-gray-300 text-sm">Radar alternativo</p>
            </div>

            <div className="bg-gray-800 p-6 rounded-lg opacity-50">
              <h3 className="text-xl font-semibold text-green-400 mb-4">Alternativo 2</h3>
              <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-yellow-500 to-green-600 rounded-full flex items-center justify-center relative">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                  <circle cx="12" cy="12" r="10"/>
                  <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/>
                  <path d="M2 12h20"/>
                </svg>
              </div>
              <p className="text-gray-300 text-sm">Globo simples</p>
            </div>
          </div>
        </div>

        {/* NOVO: Sistema Completo de Ícones Lucide */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold text-white mb-6">🎨 Sistema Completo de Ícones Lucide</h2>
          
          {/* Ícones de Navegação */}
          <div className="mb-8">
            <h3 className="text-xl font-semibold text-green-400 mb-4">📍 Navegação & Localização</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              
              <div className="bg-gray-800 p-4 rounded-lg text-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-400 mx-auto mb-2">
                  <path d="M9 11a3 3 0 1 0 6 0a3 3 0 0 0-6 0"></path>
                  <path d="M17.657 16.657L13.414 20.9a1.998 1.998 0 0 1-2.827 0l-4.244-4.243a8 8 0 1 1 11.314 0z"></path>
                </svg>
                <p className="text-white text-sm">map-pin</p>
              </div>

              <div className="bg-gray-800 p-4 rounded-lg text-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-400 mx-auto mb-2">
                  <circle cx="11" cy="11" r="8"></circle>
                  <path d="M21 21l-4.35-4.35"></path>
                </svg>
                <p className="text-white text-sm">search</p>
              </div>

              <div className="bg-gray-800 p-4 rounded-lg text-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-400 mx-auto mb-2">
                  <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                  <circle cx="12" cy="10" r="3"></circle>
                </svg>
                <p className="text-white text-sm">map-pin-alt</p>
              </div>

              <div className="bg-gray-800 p-4 rounded-lg text-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-400 mx-auto mb-2">
                  <path d="M12 22s8-4 8-10V6l-8-2-8 2v6c0 6 8 10 8 10z"></path>
                </svg>
                <p className="text-white text-sm">shield</p>
              </div>

              <div className="bg-gray-800 p-4 rounded-lg text-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-400 mx-auto mb-2">
                  <path d="M3 3v18h18"></path>
                  <path d="M18.7 8a3 3 0 0 0-5.4 0l-3 6a3 3 0 0 0 5.4 0l3-6z"></path>
                </svg>
                <p className="text-white text-sm">trending-up</p>
              </div>

              <div className="bg-gray-800 p-4 rounded-lg text-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-400 mx-auto mb-2">
                  <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                </svg>
                <p className="text-white text-sm">crosshair</p>
              </div>
            </div>
          </div>

          {/* Ícones de Análise */}
          <div className="mb-8">
            <h3 className="text-xl font-semibold text-yellow-400 mb-4">🔬 Análise & Dados</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              
              <div className="bg-gray-800 p-4 rounded-lg text-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-yellow-400 mx-auto mb-2">
                  <path d="M3 3v18h18"></path>
                  <path d="M9 9l3 3l5-5"></path>
                </svg>
                <p className="text-white text-sm">bar-chart</p>
              </div>

              <div className="bg-gray-800 p-4 rounded-lg text-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-yellow-400 mx-auto mb-2">
                  <path d="M8 3v3a2 2 0 0 1-2 2H3"></path>
                  <path d="M21 8h-3a2 2 0 0 1-2-2V3"></path>
                  <path d="M3 16h3a2 2 0 0 1 2 2v3"></path>
                  <path d="M16 21v-3a2 2 0 0 1 2-2h3"></path>
                </svg>
                <p className="text-white text-sm">scan</p>
              </div>

              <div className="bg-gray-800 p-4 rounded-lg text-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-yellow-400 mx-auto mb-2">
                  <path d="M9 12l2 2 4-4"></path>
                  <path d="M21 12c-1 0-3-1-3-3s2-3 3-3 3 1 3 3-2 3-3 3"></path>
                  <path d="M3 12c1 0 3-1 3-3s-2-3-3-3-3 1-3 3 2 3 3 3"></path>
                </svg>
                <p className="text-white text-sm">activity</p>
              </div>

              <div className="bg-gray-800 p-4 rounded-lg text-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-yellow-400 mx-auto mb-2">
                  <path d="M22 12h-4l-3 9L9 3l-3 9H2"></path>
                </svg>
                <p className="text-white text-sm">zap</p>
              </div>

              <div className="bg-gray-800 p-4 rounded-lg text-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-yellow-400 mx-auto mb-2">
                  <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
                  <polyline points="3.27,6.96 12,12.01 20.73,6.96"></polyline>
                  <line x1="12" y1="22.08" x2="12" y2="12"></line>
                </svg>
                <p className="text-white text-sm">box</p>
              </div>

              <div className="bg-gray-800 p-4 rounded-lg text-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-yellow-400 mx-auto mb-2">
                  <path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"></path>
                </svg>
                <p className="text-white text-sm">thumbs-up</p>
              </div>
            </div>
          </div>

          {/* Ícones de Interface */}
          <div className="mb-8">
            <h3 className="text-xl font-semibold text-blue-400 mb-4">⚙️ Interface & Controles</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              
              <div className="bg-gray-800 p-4 rounded-lg text-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-400 mx-auto mb-2">
                  <circle cx="12" cy="12" r="3"></circle>
                  <path d="M12 1v6m0 6v6"></path>
                  <path d="M4.22 4.22l4.24 4.24m5.08 5.08l4.24 4.24"></path>
                  <path d="M1 12h6m6 0h6"></path>
                  <path d="M4.22 19.78l4.24-4.24m5.08-5.08l4.24-4.24"></path>
                </svg>
                <p className="text-white text-sm">settings</p>
              </div>

              <div className="bg-gray-800 p-4 rounded-lg text-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-400 mx-auto mb-2">
                  <path d="M5 12h14"></path>
                  <path d="M12 5l7 7-7 7"></path>
                </svg>
                <p className="text-white text-sm">arrow-right</p>
              </div>

              <div className="bg-gray-800 p-4 rounded-lg text-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-400 mx-auto mb-2">
                  <circle cx="12" cy="12" r="10"></circle>
                  <polyline points="12,6 12,12 16,14"></polyline>
                </svg>
                <p className="text-white text-sm">clock</p>
              </div>

              <div className="bg-gray-800 p-4 rounded-lg text-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-400 mx-auto mb-2">
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                  <polyline points="14,2 14,8 20,8"></polyline>
                  <line x1="16" y1="13" x2="8" y2="13"></line>
                  <line x1="16" y1="17" x2="8" y2="17"></line>
                  <polyline points="10,9 9,9 8,9"></polyline>
                </svg>
                <p className="text-white text-sm">file-text</p>
              </div>

              <div className="bg-gray-800 p-4 rounded-lg text-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-400 mx-auto mb-2">
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                </svg>
                <p className="text-white text-sm">message</p>
              </div>

              <div className="bg-gray-800 p-4 rounded-lg text-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-400 mx-auto mb-2">
                  <path d="M15 3h6v6"></path>
                  <path d="M10 14L21 3"></path>
                  <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                </svg>
                <p className="text-white text-sm">external-link</p>
              </div>
            </div>
          </div>
        </div>

        {/* Sistema de Cores e Tipografia */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold text-white mb-6">🎨 Mapeamento Visual do Sistema</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Paleta de Cores */}
            <div className="bg-slate-800 p-6 rounded-lg">
              <h3 className="text-xl font-semibold text-white mb-4">🎯 Paleta de Cores Expandida</h3>
              <div className="space-y-4">
                
                {/* VERDES */}
                <div>
                  <h4 className="text-emerald-400 mb-2 font-semibold">🌿 Família Verde</h4>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-4">
                      <div className="w-8 h-8 bg-emerald-300 rounded-full border-2 border-white"></div>
                      <span className="text-white">Verde Claro: <code className="text-emerald-300">#6EE7B7</code></span>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-8 h-8 bg-emerald-500 rounded-full border-2 border-white"></div>
                      <span className="text-white">Verde Principal: <code className="text-emerald-400">#10B981</code></span>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-8 h-8 bg-green-600 rounded-full border-2 border-white"></div>
                      <span className="text-white">Verde Musgo: <code className="text-green-400">#059669</code></span>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-8 h-8 bg-green-800 rounded-full border-2 border-white"></div>
                      <span className="text-white">Verde Escuro: <code className="text-green-400">#065F46</code></span>
                    </div>
                  </div>
                </div>

                {/* DOURADOS */}
                <div>
                  <h4 className="text-amber-400 mb-2 font-semibold">✨ Família Dourado</h4>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-4">
                      <div className="w-8 h-8 bg-amber-300 rounded-full border-2 border-white"></div>
                      <span className="text-white">Dourado Claro: <code className="text-amber-300">#FCD34D</code></span>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-8 h-8 bg-amber-500 rounded-full border-2 border-white"></div>
                      <span className="text-white">Dourado Principal: <code className="text-amber-400">#F59E0B</code></span>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-8 h-8 bg-yellow-600 rounded-full border-2 border-white"></div>
                      <span className="text-white">Dourado Intenso: <code className="text-yellow-400">#D97706</code></span>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-8 h-8 bg-yellow-800 rounded-full border-2 border-white"></div>
                      <span className="text-white">Dourado Escuro: <code className="text-yellow-400">#92400E</code></span>
                    </div>
                  </div>
                </div>

                {/* FUNDO ALTERNATIVO SEM CINZA */}
                <div>
                  <h4 className="text-blue-400 mb-2 font-semibold">🌌 Fundos Alternativos</h4>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-4">
                      <div className="w-8 h-8 bg-slate-900 rounded-full border-2 border-white"></div>
                      <span className="text-white">Azul Noite: <code className="text-slate-400">#0F172A</code></span>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-8 h-8 bg-gradient-to-r from-slate-900 to-green-900 rounded-full border-2 border-white"></div>
                      <span className="text-white">Gradiente Verde: <code className="text-green-400">slate-900 → green-900</code></span>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-8 h-8 bg-green-950 rounded-full border-2 border-white"></div>
                      <span className="text-white">Verde Profundo: <code className="text-green-400">#052E16</code></span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Hierarquia Tipográfica */}
            <div className="bg-gray-800 p-6 rounded-lg">
              <h3 className="text-xl font-semibold text-white mb-4">📝 Hierarquia Tipográfica</h3>
              <div className="space-y-3">
                <div>
                  <h4 className="text-3xl font-bold text-white">iAgroSat</h4>
                  <p className="text-sm text-gray-400">Título Principal - Bold 3xl</p>
                </div>
                <div>
                  <h4 className="text-xl font-semibold text-green-400">Análise Satelital</h4>
                  <p className="text-sm text-gray-400">Subtítulo - Semibold xl</p>
                </div>
                <div>
                  <h4 className="text-base font-medium text-white">Seção de Dados</h4>
                  <p className="text-sm text-gray-400">Cabeçalho - Medium base</p>
                </div>
                <div>
                  <h4 className="text-sm text-slate-300">Texto descritivo</h4>
                  <p className="text-sm text-gray-400">Corpo - Regular sm</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Componentes do Sistema */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold text-white mb-6">🧩 Componentes do Sistema</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Header/Navigation */}
            <div className="bg-gray-800 p-6 rounded-lg">
              <h3 className="text-lg font-semibold text-green-400 mb-4">🏠 Header & Navigation</h3>
              <div className="space-y-2 text-sm text-white">
                <p>• Logo: Esfera verde-dourada + satélite</p>
                <p>• Status: Indicadores verde/amarelo</p>
                <p>• Navegação: Ícones Lucide clean</p>
                <p>• Fundo: Gradiente slate-900 to slate-800</p>
              </div>
            </div>

            {/* Console/Sidebar */}
            <div className="bg-gray-800 p-6 rounded-lg">
              <h3 className="text-lg font-semibold text-green-400 mb-4">🎛️ Console Lateral</h3>
              <div className="space-y-2 text-sm text-white">
                <p>• Busca: Input com ícone search</p>
                <p>• Coordenadas: Campos numéricos</p>
                <p>• Status: Cards com ícones</p>
                <p>• Botões: Verde para ação, vermelho para reset</p>
              </div>
            </div>

            {/* Map Area */}
            <div className="bg-gray-800 p-6 rounded-lg">
              <h3 className="text-lg font-semibold text-green-400 mb-4">🗺️ Área do Mapa</h3>
              <div className="space-y-2 text-sm text-white">
                <p>• Fundo: Imagem satelital/terrestre</p>
                <p>• Ferramentas: Painel direito flutuante</p>
                <p>• Marcadores: Verde-dourado</p>
                <p>• Zoom: Controles +/- clean</p>
              </div>
            </div>

            {/* Loading States */}
            <div className="bg-gray-800 p-6 rounded-lg">
              <h3 className="text-lg font-semibold text-yellow-400 mb-4">⏳ Estados de Loading</h3>
              <div className="space-y-2 text-sm text-white">
                <p>• Spinner: Satélite girando</p>
                <p>• Progress: Barra verde-dourada</p>
                <p>• Skeleton: Cinza sutil</p>
                <p>• Animação: Pulse suave</p>
              </div>
            </div>

            {/* Results/Data */}
            <div className="bg-gray-800 p-6 rounded-lg">
              <h3 className="text-lg font-semibold text-yellow-400 mb-4">📊 Resultados & Dados</h3>
              <div className="space-y-2 text-sm text-white">
                <p>• Cards: Fundo cinza com bordas</p>
                <p>• Gráficos: Verde-dourado accent</p>
                <p>• Tabelas: Zebra stripe sutil</p>
                <p>• Badges: Status colorido</p>
              </div>
            </div>

            {/* Alerts/Notifications */}
            <div className="bg-gray-800 p-6 rounded-lg">
              <h3 className="text-lg font-semibold text-blue-400 mb-4">🔔 Alertas & Notificações</h3>
              <div className="space-y-2 text-sm text-white">
                <p>• Sucesso: Verde com ícone check</p>
                <p>• Erro: Vermelho com ícone X</p>
                <p>• Aviso: Amarelo com ícone alert</p>
                <p>• Info: Azul com ícone info</p>
              </div>
            </div>
          </div>
        </div>

        {/* Tipografia */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold text-emerald-400 mb-8 text-center">🔤 Tipografia</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {fonts.map((font) => (
              <div 
                key={font.id}
                className={`bg-slate-800 rounded-lg p-6 border-2 cursor-pointer transition-all duration-300 hover:scale-105 ${
                  selectedFont === font.id 
                    ? 'border-emerald-500 bg-slate-700' 
                    : 'border-slate-600 hover:border-emerald-400'
                }`}
                onClick={() => setSelectedFont(font.id)}
              >
                <div className="text-center mb-4">
                  <div className={`${font.class} text-2xl text-white mb-2`}>
                    iAgroSat
                  </div>
                  <div className={`${font.class} text-sm text-slate-300`}>
                    ANÁLISE SATELITAL
                  </div>
                </div>
                <h3 className="text-emerald-400 font-mono text-sm mb-1">{font.name}</h3>
                <p className="text-slate-300 text-xs">{font.description}</p>
                {selectedFont === font.id && (
                  <div className="mt-3 text-center">
                    <span className="bg-emerald-500 text-white px-3 py-1 rounded-full text-xs font-mono">
                      ✓ ATIVA
                    </span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* LIBRARIES PROFISSIONAIS */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold text-white mb-6">🔧 Libraries Técnicas Sofisticadas</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Three.js + React Three Fiber */}
            <div className="bg-gray-800 p-6 rounded-lg">
              <h3 className="text-xl font-semibold text-green-400 mb-4">Three.js + React Three Fiber</h3>
              <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                <div className="text-white font-bold text-lg">3D</div>
              </div>
              <p className="text-gray-300 text-sm mb-3">Renderização 3D WebGL sofisticada com React</p>
              <code className="text-xs bg-gray-900 p-2 rounded text-green-400 block">npm install three @react-three/fiber</code>
            </div>

            {/* satellite.js */}
            <div className="bg-gray-800 p-6 rounded-lg">
              <h3 className="text-xl font-semibold text-green-400 mb-4">satellite.js</h3>
              <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-green-500 to-blue-600 rounded-lg flex items-center justify-center">
                <div className="w-4 h-4 bg-white rounded-full animate-pulse"></div>
              </div>
              <p className="text-gray-300 text-sm mb-3">Cálculos orbitais reais SGP4/SDP4</p>
              <code className="text-xs bg-gray-900 p-2 rounded text-green-400 block">npm install satellite.js</code>
            </div>

            {/* CesiumJS */}
            <div className="bg-gray-800 p-6 rounded-lg">
              <h3 className="text-xl font-semibold text-green-400 mb-4">CesiumJS</h3>
              <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-blue-600 to-green-500 rounded-full flex items-center justify-center">
                <div className="w-12 h-12 bg-blue-400 rounded-full opacity-80"></div>
              </div>
              <p className="text-gray-300 text-sm mb-3">Globos 3D geoespaciais profissionais</p>
              <code className="text-xs bg-gray-900 p-2 rounded text-green-400 block">npm install cesium</code>
            </div>

            {/* CELESTRAK API */}
            <div className="bg-gray-800 p-6 rounded-lg">
              <h3 className="text-xl font-semibold text-green-400 mb-4">CELESTRAK API</h3>
              <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-yellow-500 to-red-600 rounded-lg flex items-center justify-center">
                <div className="text-white font-bold text-xs">API</div>
              </div>
              <p className="text-gray-300 text-sm mb-3">Dados orbitais reais em tempo real</p>
              <code className="text-xs bg-gray-900 p-2 rounded text-green-400 block">fetch('https://celestrak.org/NORAD/elements/')</code>
            </div>
          </div>
        </div>

        {/* Rodapé */}
        <div className="text-center py-8 border-t border-slate-700">
          <div className="flex justify-center space-x-6 mb-6">
            <Link href="/design-option-2" className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-3 rounded-lg font-semibold transition-all duration-300 hover:scale-105">
              ← Voltar ao Design
            </Link>
            <button className="bg-yellow-600 hover:bg-yellow-700 text-white px-8 py-3 rounded-lg font-semibold transition-all duration-300 hover:scale-105">
              Aplicar Configuração
            </button>
          </div>
          <div className="text-slate-400 text-sm">
            <p className="mb-1">Configuração Atual:</p>
            <p>Tipografia: <span className="text-emerald-400">{fonts.find(f => f.id === selectedFont)?.name}</span></p>
          </div>
        </div>
      </div>
    </div>
  );
}