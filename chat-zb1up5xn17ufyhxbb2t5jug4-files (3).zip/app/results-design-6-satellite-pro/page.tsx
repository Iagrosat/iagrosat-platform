'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ArrowLeft, Satellite, Activity, Globe, TrendingUp } from 'lucide-react'
import { useRouter } from 'next/navigation'

export default function SatelliteProResults() {
  const router = useRouter()

  const spectralData = [
    { band: 'B2 (Blue)', value: '0.0847', wavelength: '490nm', color: 'text-blue-400' },
    { band: 'B3 (Green)', value: '0.1124', wavelength: '560nm', color: 'text-green-400' },
    { band: 'B4 (Red)', value: '0.0763', wavelength: '665nm', color: 'text-red-400' },
    { band: 'B8 (NIR)', value: '0.4285', wavelength: '842nm', color: 'text-purple-400' },
  ]

  const indices = [
    { name: 'NDVI', value: '0.734', status: 'Excelente', trend: '+2.1%', icon: Activity },
    { name: 'SAVI', value: '0.652', status: 'Bom', trend: '+1.8%', icon: TrendingUp },
    { name: 'EVI', value: '0.583', status: 'Moderado', trend: '+0.9%', icon: Globe },
    { name: 'LAI', value: '4.2', status: 'Alto', trend: '+3.2%', icon: Satellite },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950">
      {/* Header */}
      <header className="bg-slate-900/98 backdrop-blur-md border-b border-cyan-500/20 p-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center space-x-4">
            <Button
              variant="outline"
              onClick={() => router.push('/')}
              className="flex items-center gap-2 bg-slate-800/80 border-cyan-500/30 text-cyan-400 hover:bg-slate-700/80"
            >
              <ArrowLeft className="h-4 w-4" />
              Voltar
            </Button>
            <div className="flex items-center space-x-3">
              <div className="relative w-12 h-12">
                <div className="absolute inset-0 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-lg opacity-20 animate-pulse"></div>
                <div className="absolute inset-1 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-lg flex items-center justify-center">
                  <Satellite className="h-6 w-6 text-white" />
                </div>
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">SENTINEL-2 Analytics</h1>
                <p className="text-cyan-400 text-sm">Professional Satellite Analysis</p>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-4 text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-green-400">LIVE</span>
            </div>
            <div className="text-slate-400">Job ID: sao-paulo-demo</div>
          </div>
        </div>
      </header>

      <div className="p-6 max-w-7xl mx-auto">
        {/* Mission Control Panel */}
        <div className="bg-slate-900/90 backdrop-blur-md rounded-xl border border-cyan-500/20 p-6 mb-6">
          <div className="grid md:grid-cols-5 gap-6">
            <div className="text-center">
              <div className="text-lg font-mono text-cyan-400 mb-1">COORDINATES</div>
              <div className="text-white text-sm">-23.5505, -46.6333</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-mono text-cyan-400 mb-1">TILE</div>
              <div className="text-white text-sm">23KMQ</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-mono text-cyan-400 mb-1">RESOLUTION</div>
              <div className="text-white text-sm">10m/pixel</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-mono text-cyan-400 mb-1">CLOUD COVER</div>
              <div className="text-white text-sm">2.3%</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-mono text-cyan-400 mb-1">ACQUISITION</div>
              <div className="text-white text-sm">{new Date().toLocaleDateString('pt-BR')}</div>
            </div>
          </div>
        </div>

        {/* Main Grid */}
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Spectral Bands */}
          <Card className="bg-slate-900/90 border-cyan-500/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Activity className="h-5 w-5 mr-2 text-cyan-400" />
                Dados Espectrais
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {spectralData.map((band, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-slate-800/60 rounded-lg border border-slate-700/50">
                    <div className="flex items-center space-x-3">
                      <div className={`w-3 h-3 rounded-full ${band.color.replace('text-', 'bg-')}`}></div>
                      <div>
                        <div className="text-white font-mono text-sm">{band.band}</div>
                        <div className="text-slate-400 text-xs">{band.wavelength}</div>
                      </div>
                    </div>
                    <div className={`font-mono font-bold ${band.color}`}>
                      {band.value}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Vegetation Indices */}
          <Card className="bg-slate-900/90 border-cyan-500/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <TrendingUp className="h-5 w-5 mr-2 text-cyan-400" />
                Índices de Vegetação
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                {indices.map((index, i) => {
                  const Icon = index.icon
                  return (
                    <div key={i} className="bg-slate-800/60 rounded-lg border border-slate-700/50 p-4">
                      <div className="flex items-center justify-between mb-2">
                        <Icon className="h-4 w-4 text-cyan-400" />
                        <Badge variant="outline" className="text-xs text-green-400 border-green-400/30">
                          {index.trend}
                        </Badge>
                      </div>
                      <div className="text-white font-mono text-lg font-bold mb-1">
                        {index.value}
                      </div>
                      <div className="text-cyan-400 text-sm font-medium mb-1">
                        {index.name}
                      </div>
                      <div className="text-slate-400 text-xs">
                        {index.status}
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Analysis Summary */}
        <Card className="bg-slate-900/90 border-cyan-500/20 mt-6">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Globe className="h-5 w-5 mr-2 text-cyan-400" />
              Relatório de Análise
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="space-y-3">
                <h4 className="text-cyan-400 font-semibold">Estado da Vegetação</h4>
                <div className="text-slate-300 text-sm leading-relaxed">
                  A análise espectral indica vegetação em estado saudável com valores NDVI superiores a 0.7, 
                  sugerindo alta atividade fotossintética e densidade de biomassa verde.
                </div>
              </div>
              <div className="space-y-3">
                <h4 className="text-cyan-400 font-semibold">Condições Ambientais</h4>
                <div className="text-slate-300 text-sm leading-relaxed">
                  Baixa cobertura de nuvens (2.3%) garantiu aquisição de dados de alta qualidade. 
                  Condições ideais para análise temporal e monitoramento de mudanças.
                </div>
              </div>
              <div className="space-y-3">
                <h4 className="text-cyan-400 font-semibold">Recomendações</h4>
                <div className="text-slate-300 text-sm leading-relaxed">
                  Manter monitoramento regular utilizando índices NDVI e SAVI. 
                  Próxima análise recomendada em 16 dias (próximo ciclo Sentinel-2).
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}