'use client'

import { useState } from 'react'
import { Monitor, Image, BarChart3, MapPin, Target, Activity, Zap, TrendingUp, FileText, Calendar } from 'lucide-react'
import { WebsiteScreenshot } from '@/components/website-screenshot'
import { Leaf, Mountain } from 'lucide-react'
import { Search, Cloud, Download, Eye, Calendar, Shield } from 'lucide-react'
import { Cpu, Database, Code, Globe } from 'lucide-react'

export default function LandingPage() {
  const [activeTab, setActiveTab] = useState('platform')

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      {/* Header */}
      <header className="bg-slate-900/95 backdrop-blur-md border-b border-emerald-500/30 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="relative">
              <div className="w-12 h-12 bg-gradient-to-br from-emerald-400 to-amber-400 rounded-full flex items-center justify-center animate-spin" style={{ animationDuration: '20s' }}>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                  <path d="M13 7 9 3 5 7l4 4"></path>
                  <path d="m17 11 4 4-4 4-4-4"></path>
                  <path d="m8 12 4 4 6-6-4-4Z"></path>
                  <path d="m16 8 3-3"></path>
                  <path d="M9 21a6 6 0 0 0-6-6"></path>
                </svg>
              </div>
            </div>
            <div className="flex flex-col">
              <h1 className="text-2xl font-bold text-white">iAgroSat</h1>
              <p className="text-emerald-400 text-sm font-semibold">ANÁLISE SATELITAL AVANÇADA</p>
            </div>
          </div>
          <div className="flex items-center space-x-6">
            <a href="/system" className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg font-semibold transition-all">
              ACESSAR PLATAFORMA
            </a>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-6xl font-bold mb-6 bg-gradient-to-r from-emerald-400 to-amber-400 bg-clip-text text-transparent">
            Monitoramento Satelital
            <br />
            <span className="text-5xl">em Tempo Real</span>
          </h1>
          <p className="text-xl text-slate-300 mb-8 max-w-3xl mx-auto">
            A primeira plataforma brasileira com acesso direto ao Sentinel-2. 
            Análise espectral completa em 3 minutos, não 24 horas.
          </p>
          
          {/* Key Differentials */}
          <div className="grid md:grid-cols-4 gap-6 max-w-4xl mx-auto mb-12">
            <div className="bg-slate-800/50 border border-emerald-500/30 rounded-lg p-6">
              <div className="text-3xl font-bold text-emerald-400 mb-2">3min</div>
              <div className="text-sm text-slate-300">Tempo de Processamento</div>
            </div>
            <div className="bg-slate-800/50 border border-emerald-500/30 rounded-lg p-6">
              <div className="text-3xl font-bold text-amber-400 mb-2">10m</div>
              <div className="text-sm text-slate-300">Resolução Espacial</div>
            </div>
            <div className="bg-slate-800/50 border border-emerald-500/30 rounded-lg p-6">
              <div className="text-3xl font-bold text-emerald-400 mb-2">Global</div>
              <div className="text-sm text-slate-300">Cobertura Mundial</div>
            </div>
            <div className="bg-slate-800/50 border border-emerald-500/30 rounded-lg p-6">
              <div className="text-3xl font-bold text-amber-400 mb-2">100%</div>
              <div className="text-sm text-slate-300">Open Source</div>
            </div>
          </div>

          <div className="flex justify-center space-x-4">
            <a href="/system" className="bg-white text-emerald-600 px-8 py-3 rounded-lg font-bold text-lg transition-all transform hover:scale-105">
              TESTAR GRÁTIS
            </a>
            <button className="bg-emerald-700 hover:bg-emerald-800 text-white px-8 py-3 rounded-lg font-bold text-lg transition-all">
              FALAR COM ESPECIALISTA
            </button>
          </div>
        </div>
      </section>

      {/* Platform Capabilities */}
      <section className="py-20 px-6 bg-slate-900/50">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12 text-white">
            Capacidades da Plataforma
          </h2>
          
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Detailed Platform Features */}
            <div className="bg-slate-800 border border-emerald-500/30 rounded-lg p-6 shadow-2xl">
              <div className="space-y-6">
                <div className="text-center mb-6">
                  <h3 className="text-2xl font-bold text-emerald-400 mb-2">Interface Completa do Sistema</h3>
                  <p className="text-slate-300 text-sm">Todas as ferramentas profissionais em uma interface intuitiva</p>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-slate-900/50 rounded-lg p-4 text-center">
                    <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center mx-auto mb-2">
                      <MapPin className="w-4 h-4 text-white" />
                    </div>
                    <div className="text-white font-bold text-sm">Busca Inteligente</div>
                    <div className="text-slate-400 text-xs">Cidade, CEP, coordenadas</div>
                  </div>
                  
                  <div className="bg-slate-900/50 rounded-lg p-4 text-center">
                    <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center mx-auto mb-2">
                      <Target className="w-4 h-4 text-white" />
                    </div>
                    <div className="text-white font-bold text-sm">Seleção Precisa</div>
                    <div className="text-slate-400 text-xs">Pin, retângulo, polígono</div>
                  </div>
                  
                  <div className="bg-slate-900/50 rounded-lg p-4 text-center">
                    <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center mx-auto mb-2">
                      <Activity className="w-4 h-4 text-white" />
                    </div>
                    <div className="text-white font-bold text-sm">Processamento</div>
                    <div className="text-slate-400 text-xs">Status em tempo real</div>
                  </div>
                  
                  <div className="bg-slate-900/50 rounded-lg p-4 text-center">
                    <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center mx-auto mb-2">
                      <FileText className="w-4 h-4 text-white" />
                    </div>
                    <div className="text-white font-bold text-sm">Relatórios</div>
                    <div className="text-slate-400 text-xs">PDF, CSV, imagens</div>
                  </div>
                </div>
                
                <div className="border-t border-slate-700 pt-4">
                  <h4 className="text-emerald-400 font-bold mb-2">Tecnologia Integrada:</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-emerald-400 rounded-full"></div>
                      <span className="text-slate-300">Maps: ArcGIS + Leaflet + OpenStreetMap</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-emerald-400 rounded-full"></div>
                      <span className="text-slate-300">Backend: FastAPI + Python + GDAL</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-emerald-400 rounded-full"></div>
                      <span className="text-slate-300">Data: STAC API + Sentinel-2 Direct Access</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M8 2v4l-3 3h18l-3-3V2Z"/>
                    <path d="M8 4h8"/>
                  </svg>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-emerald-400 mb-2">Processamento Instantâneo</h3>
                  <p className="text-slate-300">Análise completa de RGB, NDVI, EVI, SAVI e GCI em minutos. Sem filas, sem espera.</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M3 7v10a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2Z"/>
                    <polyline points="8,10 12,14 16,10"/>
                  </svg>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-emerald-400 mb-2">Múltiplas Ferramentas</h3>
                  <p className="text-slate-300">Pin, retângulo, polígono, GeoJSON. Selecione áreas do seu jeito.</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                    <polyline points="7,10 12,15 17,10"/>
                    <line x1="12" y1="15" x2="12" y2="3"/>
                  </svg>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-emerald-400 mb-2">Exportação Completa</h3>
                  <p className="text-slate-300">Imagens, relatórios, mapas interativos. Todos os formatos que você precisa.</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M13 7 9 3 5 7l4 4"/>
                    <path d="m17 11 4 4-4 4-4-4"/>
                    <path d="m8 12 4 4 6-6-4-4Z"/>
                    <path d="m16 8 3-3"/>
                    <path d="M9 21a6 6 0 0 0-6-6"/>
                  </svg>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-emerald-400 mb-2">Acesso Direto Sentinel-2</h3>
                  <p className="text-slate-300">Integração nativa com a base global. Dados atualizados a cada 5 dias.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Results Showcase */}
      <section className="py-20 px-6 bg-slate-900/30">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12 text-white">
            Resultados em Tempo Real
          </h2>
          
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="bg-slate-800/50 border border-emerald-500/30 rounded-lg p-6">
                <h3 className="text-xl font-bold text-emerald-400 mb-4">5 Índices Vegetativos</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex items-center space-x-3">
                    <div className="w-4 h-4 bg-red-500 rounded-full"></div>
                    <div>
                      <span className="text-white font-semibold">RGB Natural</span>
                      <p className="text-slate-400 text-xs">Cores naturais como vistas pelo olho humano</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-4 h-4 bg-green-500 rounded-full"></div>
                    <div>
                      <span className="text-white font-semibold">NDVI</span>
                      <p className="text-slate-400 text-xs">Densidade e saúde da vegetação (padrão mundial)</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-4 h-4 bg-blue-500 rounded-full"></div>
                    <div>
                      <span className="text-white font-semibold">EVI</span>
                      <p className="text-slate-400 text-xs">Melhorado para áreas de alta biomassa</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-4 h-4 bg-orange-500 rounded-full"></div>
                    <div>
                      <span className="text-white font-semibold">SAVI</span>
                      <p className="text-slate-400 text-xs">Corrige influência do solo exposto</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-4 h-4 bg-purple-500 rounded-full"></div>
                    <div>
                      <span className="text-white font-semibold">GCI</span>
                      <p className="text-slate-400 text-xs">Detecta estresse nutricional</p>
                    </div>
                  </div>
                </div>
                <div className="mt-4 text-xs text-slate-400 border-t border-slate-700 pt-3">
                  Validação automática com mínimo 71% de pixels válidos
                </div>
              </div>
              
              <div className="bg-slate-800/50 border border-emerald-500/30 rounded-lg p-6">
                <h3 className="text-xl font-bold text-emerald-400 mb-4">Estatísticas Completas</h3>
                <div className="space-y-2 text-sm text-slate-300">
                  <div className="flex justify-between">
                    <span>Valor Médio:</span>
                    <span className="text-emerald-400 font-bold">Calculado</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Min/Max:</span>
                    <span className="text-emerald-400 font-bold">Detectado</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Percentis:</span>
                    <span className="text-emerald-400 font-bold">25% / 75%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Pixels Válidos:</span>
                    <span className="text-emerald-400 font-bold">Contados</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-slate-800/50 border border-emerald-500/30 rounded-lg p-6">
                <h3 className="text-xl font-bold text-emerald-400 mb-4">Exportação</h3>
                <div className="space-y-2 text-sm text-slate-300">
                  <div className="flex items-center space-x-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-emerald-400">
                      <path d="M20 6 9 17l-5-5"/>
                    </svg>
                    <span>Imagens PNG de alta qualidade</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-emerald-400">
                      <path d="M20 6 9 17l-5-5"/>
                    </svg>
                    <span>Relatórios PDF detalhados</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-emerald-400">
                      <path d="M20 6 9 17l-5-5"/>
                    </svg>
                    <span>Dados CSV para análise</span>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Results Screenshot */}
            <div className="lg:w-1/2">
              <div className="bg-slate-800 backdrop-blur-sm border border-emerald-500/30 rounded-lg overflow-hidden shadow-2xl">
                <div className="p-4 bg-slate-900/50 border-b border-emerald-500/20">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-red-400 rounded-full"></div>
                    <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
                    <div className="w-3 h-3 bg-green-400 rounded-full"></div>
                    <span className="ml-2 text-gray-300 text-sm">Relatório Completo - São Paulo</span>
                  </div>
                </div>
                <img 
                  src="https://files.edgestore.dev/ktemsd3elqhezqp2/publicImages/_public/7e47a8f9-c08b-403c-9bb3-a3c16f3e9346.png"
                  alt="Screenshot do relatório completo iAgroSat mostrando imagem RGB Sentinel-2, índices NDVI/EVI/SAVI/GCI, estatísticas e metadados técnicos"
                  className="w-full h-auto"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12 text-white">
            Como Funciona
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-emerald-600 to-teal-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-white">1</span>
              </div>
              <h3 className="text-xl font-bold text-emerald-400 mb-4">Selecione a Área</h3>
              <p className="text-slate-300">
                Use pin, retângulo, polígono ou importe GeoJSON. 
                Busque por cidade, CEP ou coordenadas.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-emerald-600 to-teal-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-white">2</span>
              </div>
              <h3 className="text-xl font-bold text-emerald-400 mb-4">Processamento Automático</h3>
              <p className="text-slate-300">
                Nossa IA busca as melhores imagens Sentinel-2 
                e gera todos os índices vegetativos.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-emerald-600 to-teal-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-white">3</span>
              </div>
              <h3 className="text-xl font-bold text-emerald-400 mb-4">Receba os Resultados</h3>
              <p className="text-slate-300">
                Visualize mapas interativos, baixe imagens 
                e acesse relatórios detalhados.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Competitor Comparison - Essential Section */}
      <section className="py-20 px-6 bg-slate-900/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-white mb-4">
              Por Que iAgroSat vs Concorrentes?
            </h2>
            <p className="text-xl text-slate-300">
              Primeira plataforma brasileira com transparência total e dados abertos
            </p>
          </div>
          
          {/* Unique Selling Points */}
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <div className="bg-slate-800/50 border border-emerald-500/30 rounded-lg p-6">
              <h3 className="text-2xl font-bold text-emerald-400 mb-4">O que iAgroSat Mostra</h3>
              <div className="space-y-3 text-sm">
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-emerald-400 rounded-full"></div>
                  <span className="text-white">ID da imagem Sentinel-2 usado</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-emerald-400 rounded-full"></div>
                  <span className="text-white">Data e hora exata da captura</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-emerald-400 rounded-full"></div>
                  <span className="text-white">Percentual de nuvens na imagem</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-emerald-400 rounded-full"></div>
                  <span className="text-white">Metadados técnicos completos</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-emerald-400 rounded-full"></div>
                  <span className="text-white">Logs de processamento em tempo real</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-emerald-400 rounded-full"></div>
                  <span className="text-white">Download dos resultados GeoTIFF</span>
                </div>
              </div>
            </div>
            
            <div className="bg-slate-800/50 border border-red-500/30 rounded-lg p-6">
              <h3 className="text-2xl font-bold text-red-400 mb-4">O que Outros Escondem</h3>
              <div className="space-y-3 text-sm">
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                  <span className="text-slate-300">Qual imagem foi usada (caixa preta)</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                  <span className="text-slate-300">Como foi processado (algoritmo fechado)</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                  <span className="text-slate-300">Qualidade da imagem original</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                  <span className="text-slate-300">Dados presos na plataforma</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                  <span className="text-slate-300">Dependência de insumos/marcas</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                  <span className="text-slate-300">Impossível auditar resultados</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Detailed Comparison Table */}
          <div className="bg-slate-800/30 border border-emerald-500/20 rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-900/50">
                  <tr>
                    <th className="text-left p-4 text-white font-bold">Característica</th>
                    <th className="text-center p-4 text-emerald-400 font-bold">iAgroSat</th>
                    <th className="text-center p-4 text-slate-400 font-bold">FieldView<br/>(Bayer)</th>
                    <th className="text-center p-4 text-slate-400 font-bold">Cropwise<br/>(Syngenta)</th>
                    <th className="text-center p-4 text-slate-400 font-bold">Auravant</th>
                    <th className="text-center p-4 text-slate-400 font-bold">Agrosmart</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-t border-slate-700">
                    <td className="p-4 text-white font-semibold">Tempo Processamento</td>
                    <td className="p-4 text-center text-emerald-400 font-bold">3 minutos</td>
                    <td className="p-4 text-center text-slate-400">24-48h automático</td>
                    <td className="p-4 text-center text-slate-400">Tempo real*</td>
                    <td className="p-4 text-center text-slate-400">Automático semanal</td>
                    <td className="p-4 text-center text-slate-400">A cada 5 dias</td>
                  </tr>
                  <tr className="border-t border-slate-700 bg-slate-900/20">
                    <td className="p-4 text-white font-semibold">Transparência Dados</td>
                    <td className="p-4 text-center text-emerald-400 font-bold">✓ Total</td>
                    <td className="p-4 text-center text-slate-400">✗ Índice proprietário CCI</td>
                    <td className="p-4 text-center text-slate-400">✗ NDVI sintético</td>
                    <td className="p-4 text-center text-slate-400">✗ Fechado</td>
                    <td className="p-4 text-center text-slate-400">✗ Filtro NDVI</td>
                  </tr>
                  <tr className="border-t border-slate-700">
                    <td className="p-4 text-white font-semibold">Download Dados</td>
                    <td className="p-4 text-center text-emerald-400 font-bold">✓ GeoTIFF completo</td>
                    <td className="p-4 text-center text-slate-400">✗ Apenas visualização</td>
                    <td className="p-4 text-center text-slate-400">✗ Relatórios PDF</td>
                    <td className="p-4 text-center text-slate-400">⚠ Limitado</td>
                    <td className="p-4 text-center text-slate-400">✗ Painel web</td>
                  </tr>
                  <tr className="border-t border-slate-700 bg-slate-900/20">
                    <td className="p-4 text-white font-semibold">Escolha Manual Imagem</td>
                    <td className="p-4 text-center text-emerald-400 font-bold">✓ Qualquer data</td>
                    <td className="p-4 text-center text-slate-400">✗ Automático</td>
                    <td className="p-4 text-center text-slate-400">✗ Sistema escolhe</td>
                    <td className="p-4 text-center text-slate-400">✗ Timeline automática</td>
                    <td className="p-4 text-center text-slate-400">✗ Periodicidade fixa</td>
                  </tr>
                  <tr className="border-t border-slate-700">
                    <td className="p-4 text-white font-semibold">Índices Disponíveis</td>
                    <td className="p-4 text-center text-emerald-400 font-bold">5 simultâneos</td>
                    <td className="p-4 text-center text-slate-400">CCI próprio</td>
                    <td className="p-4 text-center text-slate-400">NDVI + SAVI</td>
                    <td className="p-4 text-center text-slate-400">NDVI principal</td>
                    <td className="p-4 text-center text-slate-400">NDVI + RGB</td>
                  </tr>
                  <tr className="border-t border-slate-700 bg-slate-900/20">
                    <td className="p-4 text-white font-semibold">Dependência Insumos</td>
                    <td className="p-4 text-center text-emerald-400 font-bold">✓ Independente</td>
                    <td className="p-4 text-center text-slate-400">✗ Integrado Bayer</td>
                    <td className="p-4 text-center text-slate-400">✗ Integrado Syngenta</td>
                    <td className="p-4 text-center text-slate-400">⚠ Neutro</td>
                    <td className="p-4 text-center text-slate-400">⚠ Neutro</td>
                  </tr>
                  <tr className="border-t border-slate-700">
                    <td className="p-4 text-white font-semibold">Custo Base</td>
                    <td className="p-4 text-center text-emerald-400 font-bold">Acessível</td>
                    <td className="p-4 text-center text-slate-400">R$ 250-1500/ano</td>
                    <td className="p-4 text-center text-slate-400">Empresarial</td>
                    <td className="p-4 text-center text-slate-400">Freemium</td>
                    <td className="p-4 text-center text-slate-400">2000ha/ano</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          
          <div className="text-center mt-8">
            <p className="text-slate-400 text-sm">
              * Baseado em pesquisa detalhada de funcionalidades públicas dos concorrentes
            </p>
          </div>
        </div>
      </section>

      {/* V2 Roadmap */}
      <section className="py-16 px-6 bg-slate-900/50">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-white mb-8">
            Roadmap V2 - IA e Machine Learning
          </h2>
          
          <div className="bg-gradient-to-r from-emerald-900/20 to-amber-900/20 border border-emerald-500/30 rounded-lg p-6">
            <div className="grid md:grid-cols-3 gap-6 text-center">
              <div>
                <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-white font-bold">IA</span>
                </div>
                <h3 className="text-lg font-bold text-emerald-400 mb-2">Previsão de Safra</h3>
                <p className="text-slate-300 text-sm">Machine Learning para produtividade</p>
              </div>
              <div>
                <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-white font-bold">IA</span>
                </div>
                <h3 className="text-lg font-bold text-emerald-400 mb-2">Análise de Risco</h3>
                <p className="text-slate-300 text-sm">Modelos preditivos para crédito</p>
              </div>
              <div>
                <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-white font-bold">IA</span>
                </div>
                <h3 className="text-lg font-bold text-emerald-400 mb-2">Integração EMBRAPA</h3>
                <p className="text-slate-300 text-sm">Dados climáticos e meteorológicos</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Capacidades Técnicas */}
      <section className="mb-16">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-4">Capacidades Técnicas Implementadas</h2>
          <p className="text-gray-300 text-lg">
            Stack geoespacial profissional com 23,986 linhas de código
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-slate-800/50 border border-emerald-500/20 rounded-lg p-6">
            <div className="flex items-center gap-3 mb-4">
              <Cpu className="w-6 h-6 text-emerald-400" />
              <h3 className="text-white font-semibold">Processamento</h3>
            </div>
            <ul className="space-y-2 text-gray-300 text-sm">
              <li>• STAC Client para Sentinel-2</li>
              <li>• GDAL/Rasterio para GeoTIFF</li>
              <li>• Reprojeção automática</li>
              <li>• Validação de pixels (71% mín)</li>
              <li>• Processamento paralelo</li>
            </ul>
          </div>

          <div className="bg-slate-800/50 border border-emerald-500/20 rounded-lg p-6">
            <div className="flex items-center gap-3 mb-4">
              <Database className="w-6 h-6 text-emerald-400" />
              <h3 className="text-white font-semibold">Dados</h3>
            </div>
            <ul className="space-y-2 text-gray-300 text-sm">
              <li>• Sentinel-2 L2A (10m)</li>
              <li>• Histórico desde 2015</li>
              <li>• Metadados completos</li>
              <li>• Filtering de nuvens</li>
              <li>• Tile XYZ dinâmico</li>
            </ul>
          </div>

          <div className="bg-slate-800/50 border border-emerald-500/20 rounded-lg p-6">
            <div className="flex items-center gap-3 mb-4">
              <Code className="w-6 h-6 text-emerald-400" />
              <h3 className="text-white font-semibold">Backend</h3>
            </div>
            <ul className="space-y-2 text-gray-300 text-sm">
              <li>• FastAPI + Python</li>
              <li>• Threading assíncrono</li>
              <li>• Job queue system</li>
              <li>• Logs estruturados</li>
              <li>• API REST completa</li>
            </ul>
          </div>

          <div className="bg-slate-800/50 border border-emerald-500/20 rounded-lg p-6">
            <div className="flex items-center gap-3 mb-4">
              <Globe className="w-6 h-6 text-emerald-400" />
              <h3 className="text-white font-semibold">Frontend</h3>
            </div>
            <ul className="space-y-2 text-gray-300 text-sm">
              <li>• Next.js 14 + React</li>
              <li>• Leaflet/ArcGIS maps</li>
              <li>• Tailwind CSS</li>
              <li>• TypeScript</li>
              <li>• Responsive design</li>
            </ul>
          </div>
        </div>

        <div className="mt-8 bg-slate-800/30 border border-emerald-500/20 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-4">
            <Activity className="w-6 h-6 text-emerald-400" />
            <h3 className="text-white font-semibold">Arquitetura de Produção</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="text-gray-300">
              <strong className="text-white">Bibliotecas Geoespaciais:</strong>
              <br />Rasterio, GDAL, PyProj, Shapely, PySTAC
            </div>
            <div className="text-gray-300">
              <strong className="text-white">Processamento de Imagem:</strong>
              <br />NumPy, OpenCV, Matplotlib, PIL
            </div>
            <div className="text-gray-300">
              <strong className="text-white">Deploy & Scaling:</strong>
              <br />Docker, Vercel, serverless ready
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-emerald-500/30 py-8 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-br from-emerald-600 to-teal-600 rounded-lg flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                    <path d="M13 7 9 3 5 7l4 4"/>
                    <path d="m17 11 4 4-4 4-4-4"/>
                    <path d="m8 12 4 4 6-6-4-4Z"/>
                    <path d="m16 8 3-3"/>
                    <path d="M9 21a6 6 0 0 0-6-6"/>
                  </svg>
                </div>
                <span className="text-xl font-bold text-white">iAgroSat</span>
              </div>
              <p className="text-slate-400 text-sm">
                Primeira plataforma brasileira com acesso direto ao Sentinel-2. 
                Análise satelital transparente e open source.
              </p>
            </div>
            
            <div className="space-y-4">
              <h4 className="font-semibold text-white">Plataforma</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li><a href="/system" className="hover:text-emerald-400 transition-colors">Análise Satelital</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition-colors">Índices Vegetativos</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition-colors">Mapas Interativos</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition-colors">Exportação</a></li>
              </ul>
            </div>
            
            <div className="space-y-4">
              <h4 className="font-semibold text-white">Recursos</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li><a href="#" className="hover:text-emerald-400 transition-colors">Documentação</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition-colors">API</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition-colors">Tutoriais</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition-colors">Suporte</a></li>
              </ul>
            </div>
            
            <div className="space-y-4">
              <h4 className="font-semibold text-white">Empresa</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li><a href="#" className="hover:text-emerald-400 transition-colors">Sobre</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition-colors">Contato</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition-colors">Termos</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition-colors">Privacidade</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-slate-800 mt-8 pt-8 text-center">
            <p className="text-slate-400 text-sm">
              © 2025 iAgroSat. Todos os direitos reservados. Expertise em processamento geoespacial e bibliotecas científicas.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}