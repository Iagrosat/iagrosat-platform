'use client'

import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ArrowLeft, Satellite, Activity, Globe, TrendingUp, Image, BarChart3, Map, Leaf, Target, FileText, Download } from 'lucide-react'

export default function JobResults() {
  const params = useParams()
  const router = useRouter()
  const [activeTab, setActiveTab] = useState('relatorio')
  const jobId = params.jobId as string

  const [jobData, setJobData] = useState({
    coordinates: { lat: -22.5, lng: -49.5 },
    tile: '23KMQ',
    cloudCover: '8.7%',
    acquisition: '05/07/2025',
    location: 'Lucianópolis, SP'
  })
  const [realJobData, setRealJobData] = useState(null)
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false)

  // PDF Generation Function
  const generatePDF = async () => {
    setIsGeneratingPDF(true)
    try {
      console.log('📄 Generating PDF for job:', jobId)
      
      const response = await fetch('/api/generate-pdf', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          jobId,
          jobData,
          indices: indices.map(i => ({ name: i.name, value: i.value, status: i.status })),
          imageUrls: imageList.map(img => img.url),
          realJobData
        }),
      })

      if (response.ok) {
        console.log('✅ PDF generated successfully')
        // Get the PDF blob and create download
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const link = document.createElement('a')
        link.href = url
        link.download = `iAgroSat-${jobId}-report.pdf`
        document.body.appendChild(link)
        link.click()
        document.body.removeChild(link)
        window.URL.revokeObjectURL(url)
      } else {
        console.error('❌ PDF generation failed:', response.status)
        alert('Erro ao gerar PDF. Tente novamente.')
      }
    } catch (error) {
      console.error('❌ Error generating PDF:', error)
      alert('Erro ao gerar PDF. Tente novamente.')
    } finally {
      setIsGeneratingPDF(false)
    }
  }

  // Fetch real job data from backend
  useEffect(() => {
    const fetchJobData = async () => {
      try {
        console.log('🔄 Fetching job data for ID:', jobId)
        const response = await fetch(`/api/full-report/status?job_id=${jobId}`)
        if (response.ok) {
          const data = await response.json()
          console.log('🎯 Real job data received:', data)
          setRealJobData(data)
          
          if (data.resultado?.metadata) {
            const metadata = data.resultado.metadata
            console.log('📊 Updating UI with metadata:', metadata)
            setJobData({
              coordinates: { 
                lat: metadata.coordenadas[1], 
                lng: metadata.coordenadas[0] 
              },
              tile: '23KMQ',
              cloudCover: `${metadata.cobertura_nuvens.toFixed(1)}%`,
              acquisition: new Date(metadata.data_captura).toLocaleDateString('pt-BR'),
              location: metadata.localizacao.split(',')[0]
            })
          }
        } else {
          console.error('❌ Failed to fetch job data:', response.status)
        }
      } catch (error) {
        console.error('❌ Error fetching job data:', error)
      }
    }
    
    fetchJobData()
    
    // Force refresh after 2 seconds
    setTimeout(fetchJobData, 2000)
  }, [jobId])

  const spectralData = [
    { band: 'B2 (Blue)', value: '0.0847', wavelength: '490nm', color: 'text-blue-400' },
    { band: 'B3 (Green)', value: '0.1124', wavelength: '560nm', color: 'text-green-400' },
    { band: 'B4 (Red)', value: '0.0763', wavelength: '665nm', color: 'text-red-400' },
    { band: 'B8 (NIR)', value: '0.4285', wavelength: '842nm', color: 'text-purple-400' },
  ]

  const indices = [
    {
      name: 'NDVI',
      value: realJobData?.resultado?.indices?.find(i => i.indice === 'NDVI')?.media?.toFixed(3) || '0.660',
      status: realJobData?.resultado?.indices?.find(i => i.indice === 'NDVI')?.media > 0.6 ? 'Excelente' : 'Moderado',
      icon: TrendingUp,
      description: 'Normalized Difference Vegetation Index',
      min: realJobData?.resultado?.indices?.find(i => i.indice === 'NDVI')?.minimo?.toFixed(3) || '0.420',
      max: realJobData?.resultado?.indices?.find(i => i.indice === 'NDVI')?.maximo?.toFixed(3) || '0.890'
    },
    {
      name: 'SAVI',
      value: realJobData?.resultado?.indices?.find(i => i.indice === 'SAVI')?.media?.toFixed(3) || '0.990',
      status: realJobData?.resultado?.indices?.find(i => i.indice === 'SAVI')?.media > 0.5 ? 'Excelente' : 'Moderado',
      icon: Leaf,
      description: 'Soil Adjusted Vegetation Index',
      min: realJobData?.resultado?.indices?.find(i => i.indice === 'SAVI')?.minimo?.toFixed(3) || '0.630',
      max: realJobData?.resultado?.indices?.find(i => i.indice === 'SAVI')?.maximo?.toFixed(3) || '1.335'
    },
    {
      name: 'EVI',
      value: realJobData?.resultado?.indices?.find(i => i.indice === 'EVI')?.media?.toFixed(3) || '1.519',
      status: realJobData?.resultado?.indices?.find(i => i.indice === 'EVI')?.media > 1.0 ? 'Alto' : 'Moderado',
      icon: Activity,
      description: 'Enhanced Vegetation Index',
      min: realJobData?.resultado?.indices?.find(i => i.indice === 'EVI')?.minimo?.toFixed(3) || '0.945',
      max: realJobData?.resultado?.indices?.find(i => i.indice === 'EVI')?.maximo?.toFixed(3) || '2.093'
    },
    {
      name: 'GCI',
      value: realJobData?.resultado?.indices?.find(i => i.indice === 'GCI')?.media?.toFixed(1) || '5.3',
      status: realJobData?.resultado?.indices?.find(i => i.indice === 'GCI')?.media > 4.0 ? 'Alto' : 'Moderado',
      icon: Target,
      description: 'Green Chlorophyll Index',
      min: realJobData?.resultado?.indices?.find(i => i.indice === 'GCI')?.minimo?.toFixed(1) || '3.2',
      max: realJobData?.resultado?.indices?.find(i => i.indice === 'GCI')?.maximo?.toFixed(1) || '7.8'
    }
  ]

  const imageList = [
    {
      name: 'RGB Natural',
      type: 'Imagem RGB Original',
      url: realJobData?.resultado?.images?.rgb 
        ? `/api/proxy?path=${realJobData.resultado.images.rgb.replace(/^\//, '').split('?')[0]}`
        : `https://assets.macaly-user-data.dev/demo-images/rgb-${jobId}.png`
    },
    {
      name: 'NDVI',
      type: 'Índice de Vegetação',
      url: realJobData?.resultado?.images?.ndvi
        ? `/api/proxy?path=${realJobData.resultado.images.ndvi.replace(/^\//, '').split('?')[0]}`
        : `https://assets.macaly-user-data.dev/demo-images/ndvi-${jobId}.png`
    },
    {
      name: 'EVI',
      type: 'Índice de Vegetação Melhorado',
      url: realJobData?.resultado?.images?.evi
        ? `/api/proxy?path=${realJobData.resultado.images.evi.replace(/^\//, '').split('?')[0]}`
        : `https://assets.macaly-user-data.dev/demo-images/evi-${jobId}.png`
    },
    {
      name: 'SAVI',
      type: 'Índice de Vegetação Ajustado',
      url: realJobData?.resultado?.images?.savi
        ? `/api/proxy?path=${realJobData.resultado.images.savi.replace(/^\//, '').split('?')[0]}`
        : `https://assets.macaly-user-data.dev/demo-images/savi-${jobId}.png`
    },
    {
      name: 'GCI',
      type: 'Índice de Clorofila Verde',
      url: realJobData?.resultado?.images?.gci
        ? `/api/proxy?path=${realJobData.resultado.images.gci.replace(/^\//, '').split('?')[0]}`
        : `https://assets.macaly-user-data.dev/demo-images/gci-${jobId}.png`
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-900">
      {/* Header */}
      <header className="bg-slate-900/95 backdrop-blur-md border-b border-emerald-500/30 p-4 shadow-lg">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center space-x-4">
            <Button
              variant="outline"
              onClick={() => router.push('/')}
              className="flex items-center gap-2 bg-emerald-900/50 border-emerald-500/50 text-emerald-100 hover:bg-emerald-800/50"
            >
              <ArrowLeft className="h-4 w-4" />
              Voltar
            </Button>
            <div className="flex items-center space-x-3">
              <div className="relative w-12 h-12">
                <div className="absolute inset-0 bg-gradient-to-br from-emerald-400 to-green-500 rounded-lg opacity-20 animate-pulse"></div>
                <div className="absolute inset-1 bg-gradient-to-br from-emerald-400 to-green-500 rounded-lg flex items-center justify-center">
                  <Satellite className="h-6 w-6 text-white" />
                </div>
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">iAgroSat Analytics</h1>
                <p className="text-emerald-400 text-sm">Análise Satelital Profissional</p>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-4 text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
              <span className="text-emerald-400">CONCLUÍDO</span>
            </div>
            <div className="text-slate-400">Job ID: {jobId}</div>
            <Button
              onClick={generatePDF}
              disabled={isGeneratingPDF}
              className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white"
              size="sm"
            >
              {isGeneratingPDF ? (
                <>
                  <div className="animate-spin w-4 h-4 mr-2 border-2 border-white border-t-transparent rounded-full"></div>
                  Gerando PDF...
                </>
              ) : (
                <>
                  <FileText className="h-4 w-4 mr-2" />
                  📄 Baixar Relatório PDF
                </>
              )}
            </Button>
          </div>
        </div>
      </header>

      <div className="p-6 max-w-7xl mx-auto">
        {/* Mission Control Panel */}
        <div className="bg-slate-800/90 backdrop-blur-md rounded-xl border border-emerald-500/30 p-6 mb-6 shadow-lg">
          <div className="grid md:grid-cols-5 gap-6">
            <div className="text-center">
              <div className="text-lg font-mono text-emerald-400 mb-1">COORDENADAS</div>
              <div className="text-slate-300 text-sm">{jobData.coordinates.lat}, {jobData.coordinates.lng}</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-mono text-emerald-400 mb-1">TILE</div>
              <div className="text-slate-300 text-sm">{jobData.tile}</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-mono text-emerald-400 mb-1">RESOLUÇÃO</div>
              <div className="text-slate-300 text-sm">10m/pixel</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-mono text-emerald-400 mb-1">NUVENS</div>
              <div className="text-slate-300 text-sm">{jobData.cloudCover}</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-mono text-emerald-400 mb-1">AQUISIÇÃO</div>
              <div className="text-slate-300 text-sm">{jobData.acquisition}</div>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 bg-slate-800/90 border border-emerald-500/30 shadow-lg">
            <TabsTrigger value="relatorio" className="flex items-center gap-2 data-[state=active]:bg-emerald-900/50 data-[state=active]:text-emerald-100 text-slate-300">
              <Globe className="h-4 w-4" />
              Relatório
            </TabsTrigger>
            <TabsTrigger value="rgb" className="flex items-center gap-2 data-[state=active]:bg-emerald-900/50 data-[state=active]:text-emerald-100 text-slate-300">
              <Image className="h-4 w-4" />
              RGB
            </TabsTrigger>
            <TabsTrigger value="ndvi" className="flex items-center gap-2 data-[state=active]:bg-emerald-900/50 data-[state=active]:text-emerald-100 text-slate-300">
              <TrendingUp className="h-4 w-4" />
              NDVI
            </TabsTrigger>
            <TabsTrigger value="evi" className="flex items-center gap-2 data-[state=active]:bg-emerald-900/50 data-[state=active]:text-emerald-100 text-slate-300">
              <Activity className="h-4 w-4" />
              EVI
            </TabsTrigger>
            <TabsTrigger value="savi" className="flex items-center gap-2 data-[state=active]:bg-emerald-900/50 data-[state=active]:text-emerald-100 text-slate-300">
              <Leaf className="h-4 w-4" />
              SAVI
            </TabsTrigger>
            <TabsTrigger value="gci" className="flex items-center gap-2 data-[state=active]:bg-emerald-900/50 data-[state=active]:text-emerald-100 text-slate-300">
              <Target className="h-4 w-4" />
              GCI
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Quick Stats */}
              <Card className="bg-slate-800/90 border-emerald-500/30 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <TrendingUp className="h-5 w-5 mr-2 text-emerald-400" />
                    Resumo dos Índices
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    {indices.map((index, i) => {
                      const Icon = index.icon
                      return (
                        <div key={i} className="bg-slate-700/60 rounded-lg border border-emerald-500/20 p-4">
                          <div className="flex items-center justify-between mb-2">
                            <Icon className="h-4 w-4 text-emerald-400" />
                          </div>
                          <div className="text-white font-mono text-lg font-bold mb-1">
                            {index.value}
                          </div>
                          <div className="text-emerald-400 text-sm font-medium mb-1">
                            {index.name}
                          </div>
                          <div className="text-slate-400 text-xs">
                            Min: {index.min} | Max: {index.max}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>

              {/* Analysis Summary */}
              <Card className="bg-slate-800/90 border-emerald-500/30 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Globe className="h-5 w-5 mr-2 text-emerald-400" />
                    Análise Geral
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h4 className="text-emerald-400 font-semibold mb-2">Estado da Vegetação</h4>
                      <div className="text-slate-300 text-sm leading-relaxed">
                        A análise espectral indica vegetação com NDVI médio de {realJobData?.resultado?.indices?.find(i => i.indice === 'NDVI')?.media?.toFixed(3) || '0.66'}, 
                        sugerindo {parseFloat(realJobData?.resultado?.indices?.find(i => i.indice === 'NDVI')?.media || 0.66) > 0.6 ? 'boa' : 'moderada'} atividade fotossintética e densidade de biomassa verde.
                      </div>
                    </div>
                    <div>
                      <h4 className="text-emerald-400 font-semibold mb-2">Condições Ambientais</h4>
                      <div className="text-slate-300 text-sm leading-relaxed">
                        Cobertura de nuvens de {jobData.cloudCover} garantiu aquisição de dados de {parseFloat(jobData.cloudCover) < 15 ? 'alta' : 'moderada'} qualidade.
                        {parseFloat(jobData.cloudCover) < 10 ? ' Condições ideais' : ' Condições adequadas'} para análise temporal e monitoramento de mudanças.
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* RGB Tab - NEW */}
          <TabsContent value="rgb" className="space-y-6">
            <Card className="bg-slate-800/90 border-emerald-500/30 shadow-lg">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Image className="h-5 w-5 mr-2 text-emerald-400" />
                  Imagem RGB Natural
                </CardTitle>
                <div className="text-slate-400 text-sm">Composição RGB das bandas Red, Green, Blue do Sentinel-2</div>
              </CardHeader>
              <CardContent>
                <div className="grid lg:grid-cols-2 gap-6">
                  <div className="aspect-square bg-slate-700 rounded-lg overflow-hidden border border-emerald-500/20">
                    <img 
                      src={realJobData?.resultado?.images?.rgb 
                        ? `/api/proxy?path=${realJobData.resultado.images.rgb.replace(/^\//, '').split('?')[0]}`
                        : `https://assets.macaly-user-data.dev/demo-images/rgb-${jobId}.png`}
                      alt="RGB Natural"
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        console.log('❌ RGB image failed to load')
                        e.currentTarget.src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='400' viewBox='0 0 400 400'%3E%3Crect width='400' height='400' fill='%23475569'/%3E%3Ctext x='200' y='200' font-family='Arial' font-size='16' fill='%2310b981' text-anchor='middle' dy='0.3em'%3ECarregando RGB...%3C/text%3E%3C/svg%3E"
                      }}
                    />
                  </div>
                  <div className="space-y-4">
                    <div>
                      <h4 className="text-emerald-400 font-semibold mb-2">Descrição</h4>
                      <div className="text-slate-300 text-sm leading-relaxed">
                        Esta imagem RGB combina as bandas 4 (Red), 3 (Green) e 2 (Blue) do sensor Sentinel-2, 
                        proporcionando uma visualização em cores naturais da superfície terrestre similar ao que o olho humano perceberia.
                      </div>
                    </div>
                    <div>
                      <h4 className="text-emerald-400 font-semibold mb-2">Características Técnicas</h4>
                      <div className="text-slate-300 text-sm leading-relaxed">
                        • Resolução espacial: 10 metros por pixel<br/>
                        • Bandas utilizadas: B04 (665nm), B03 (560nm), B02 (490nm)<br/>
                        • Aquisição: {jobData.acquisition}<br/>
                        • Cobertura de nuvens: {jobData.cloudCover}
                      </div>
                    </div>
                    <Button 
                      variant="outline" 
                      className="w-full bg-emerald-900/50 border-emerald-500/50 text-emerald-100 hover:bg-emerald-800/50"
                      onClick={() => window.open(realJobData?.resultado?.images?.rgb 
                        ? `/api/proxy?path=${realJobData.resultado.images.rgb.replace(/^\//, '').split('?')[0]}`
                        : `https://assets.macaly-user-data.dev/demo-images/rgb-${jobId}.png`, '_blank')}
                    >
                      📥 Download Imagem RGB
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Images Tab */}
          <TabsContent value="images" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              {imageList.map((image, i) => (
                <Card key={i} className="bg-slate-800/90 border-emerald-500/30 shadow-lg">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center">
                      <Image className="h-5 w-5 mr-2 text-emerald-400" />
                      {image.name}
                    </CardTitle>
                    <div className="text-slate-400 text-sm">{image.type}</div>
                  </CardHeader>
                  <CardContent>
                    <div className="relative aspect-square bg-slate-700 rounded-lg overflow-hidden border border-emerald-500/20">
                      <img 
                        src={image.url} 
                        alt={image.name}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          console.log('❌ Image failed to load:', image.url)
                          e.currentTarget.src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='400' viewBox='0 0 400 400'%3E%3Crect width='400' height='400' fill='%23475569'/%3E%3Ctext x='200' y='200' font-family='Arial' font-size='16' fill='%2310b981' text-anchor='middle' dy='0.3em'%3ECarregando...%3C/text%3E%3C/svg%3E"
                        }}
                        onLoad={() => console.log('✅ Image loaded successfully:', image.url)}
                      />
                    </div>
                    <div className="mt-4 flex justify-between items-center">
                      <div className="text-slate-400 text-xs">
                        📅 {jobData.acquisition} • 🌤️ {jobData.cloudCover} nuvens • 📍 {jobData.location}
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="bg-emerald-900/50 border-emerald-500/50 text-emerald-100 hover:bg-emerald-800/50"
                        onClick={() => window.open(image.url, '_blank')}
                      >
                        📥 Download
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Indices Tab */}
          <TabsContent value="indices" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              {indices.map((index, i) => {
                const Icon = index.icon
                return (
                  <Card key={i} className="bg-slate-800/90 border-emerald-500/30 shadow-lg">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center">
                        <Icon className="h-5 w-5 mr-2 text-emerald-400" />
                        {index.name}
                      </CardTitle>
                      <div className="text-slate-400 text-sm">{index.description}</div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="text-center">
                          <div className="text-4xl font-mono font-bold text-emerald-400 mb-2">
                            {index.value}
                          </div>
                          <div className="flex items-center justify-center space-x-2">
                            <Badge variant="outline" className="text-emerald-400 border-emerald-500/50">
                              {index.trend}
                            </Badge>
                            <span className="text-slate-400 text-sm">vs último mês</span>
                          </div>
                        </div>
                        <div className="bg-slate-700/60 rounded-lg p-4 border border-emerald-500/20">
                          <div className="flex justify-between items-center">
                            <span className="text-slate-300 text-sm">Status:</span>
                            <span className="text-emerald-400 font-bold text-sm">{index.status}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </TabsContent>

          {/* Spectral Tab */}
          <TabsContent value="spectral" className="space-y-6">
            <Card className="bg-slate-800/90 border-emerald-500/30 shadow-lg">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Activity className="h-5 w-5 mr-2 text-emerald-400" />
                  Dados Espectrais SENTINEL-2
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {spectralData.map((band, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-slate-700/60 rounded-lg border border-emerald-500/20">
                      <div className="flex items-center space-x-4">
                        <div className={`w-4 h-4 rounded-full ${band.color.replace('text-', 'bg-')}`}></div>
                        <div>
                          <div className="text-white font-mono text-lg font-bold">{band.band}</div>
                          <div className="text-slate-400 text-sm">{band.wavelength}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className={`font-mono font-bold text-xl ${band.color}`}>
                          {band.value}
                        </div>
                        <div className="text-slate-400 text-sm">Reflectância</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* NDVI Tab */}
          <TabsContent value="ndvi" className="space-y-6">
            <Card className="bg-slate-800/90 border-emerald-500/30 shadow-lg">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <TrendingUp className="h-5 w-5 mr-2 text-emerald-400" />
                  NDVI - Normalized Difference Vegetation Index
                </CardTitle>
                <div className="text-slate-400 text-sm">Índice de vegetação por diferença normalizada</div>
              </CardHeader>
              <CardContent>
                <div className="grid lg:grid-cols-2 gap-6">
                  <div className="aspect-square bg-slate-700 rounded-lg overflow-hidden border border-emerald-500/20">
                    <img 
                      src={realJobData?.resultado?.images?.ndvi 
                        ? `/api/proxy?path=${realJobData.resultado.images.ndvi.replace(/^\//, '').split('?')[0]}`
                        : `https://assets.macaly-user-data.dev/demo-images/ndvi-${jobId}.png`}
                      alt="NDVI"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="space-y-4">
                    <div className="text-center">
                      <div className="text-6xl font-mono font-bold text-emerald-400 mb-2">
                        {indices.find(i => i.name === 'NDVI')?.value}
                      </div>
                      <div className="text-slate-400 text-sm">Valor Médio</div>
                    </div>
                    <div className="bg-slate-700/60 rounded-lg p-4 border border-emerald-500/20">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-slate-300 text-sm">Status:</span>
                        <span className="text-emerald-400 font-bold text-sm">{indices.find(i => i.name === 'NDVI')?.status}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-slate-300 text-sm">Faixa:</span>
                        <span className="text-slate-400 text-sm">{indices.find(i => i.name === 'NDVI')?.min} - {indices.find(i => i.name === 'NDVI')?.max}</span>
                      </div>
                    </div>
                    <div>
                      <h4 className="text-emerald-400 font-semibold mb-2">Interpretação</h4>
                      <div className="text-slate-300 text-sm leading-relaxed">
                        O NDVI varia de -1 a +1. Valores próximos a 1 indicam vegetação densa e saudável, 
                        enquanto valores próximos a 0 representam solo nu ou vegetação esparsa.
                      </div>
                    </div>
                    <Button 
                      variant="outline" 
                      className="w-full bg-emerald-900/50 border-emerald-500/50 text-emerald-100 hover:bg-emerald-800/50"
                      onClick={() => window.open(realJobData?.resultado?.images?.ndvi 
                        ? `/api/proxy?path=${realJobData.resultado.images.ndvi.replace(/^\//, '').split('?')[0]}`
                        : `https://assets.macaly-user-data.dev/demo-images/ndvi-${jobId}.png`, '_blank')}
                    >
                      📥 Download NDVI
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* EVI Tab */}
          <TabsContent value="evi" className="space-y-6">
            <Card className="bg-slate-800/90 border-emerald-500/30 shadow-lg">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Activity className="h-5 w-5 mr-2 text-emerald-400" />
                  EVI - Enhanced Vegetation Index
                </CardTitle>
                <div className="text-slate-400 text-sm">Índice de vegetação melhorado</div>
              </CardHeader>
              <CardContent>
                <div className="grid lg:grid-cols-2 gap-6">
                  <div className="aspect-square bg-slate-700 rounded-lg overflow-hidden border border-emerald-500/20">
                    <img 
                      src={realJobData?.resultado?.images?.evi 
                        ? `/api/proxy?path=${realJobData.resultado.images.evi.replace(/^\//, '').split('?')[0]}`
                        : `https://assets.macaly-user-data.dev/demo-images/evi-${jobId}.png`}
                      alt="EVI"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="space-y-4">
                    <div className="text-center">
                      <div className="text-6xl font-mono font-bold text-emerald-400 mb-2">
                        {indices.find(i => i.name === 'EVI')?.value}
                      </div>
                      <div className="text-slate-400 text-sm">Valor Médio</div>
                    </div>
                    <div className="bg-slate-700/60 rounded-lg p-4 border border-emerald-500/20">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-slate-300 text-sm">Status:</span>
                        <span className="text-emerald-400 font-bold text-sm">{indices.find(i => i.name === 'EVI')?.status}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-slate-300 text-sm">Faixa:</span>
                        <span className="text-slate-400 text-sm">{indices.find(i => i.name === 'EVI')?.min} - {indices.find(i => i.name === 'EVI')?.max}</span>
                      </div>
                    </div>
                    <div>
                      <h4 className="text-emerald-400 font-semibold mb-2">Interpretação</h4>
                      <div className="text-slate-300 text-sm leading-relaxed">
                        O EVI é otimizado para áreas com alta biomassa e reduz a influência da atmosfera e do solo, 
                        fornecendo melhor sensibilidade em regiões densamente vegetadas.
                      </div>
                    </div>
                    <Button 
                      variant="outline" 
                      className="w-full bg-emerald-900/50 border-emerald-500/50 text-emerald-100 hover:bg-emerald-800/50"
                      onClick={() => window.open(realJobData?.resultado?.images?.evi 
                        ? `/api/proxy?path=${realJobData.resultado.images.evi.replace(/^\//, '').split('?')[0]}`
                        : `https://assets.macaly-user-data.dev/demo-images/evi-${jobId}.png`, '_blank')}
                    >
                      📥 Download EVI
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* SAVI Tab */}
          <TabsContent value="savi" className="space-y-6">
            <Card className="bg-slate-800/90 border-emerald-500/30 shadow-lg">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Leaf className="h-5 w-5 mr-2 text-emerald-400" />
                  SAVI - Soil Adjusted Vegetation Index
                </CardTitle>
                <div className="text-slate-400 text-sm">Índice de vegetação ajustado ao solo</div>
              </CardHeader>
              <CardContent>
                <div className="grid lg:grid-cols-2 gap-6">
                  <div className="aspect-square bg-slate-700 rounded-lg overflow-hidden border border-emerald-500/20">
                    <img 
                      src={realJobData?.resultado?.images?.savi 
                        ? `/api/proxy?path=${realJobData.resultado.images.savi.replace(/^\//, '').split('?')[0]}`
                        : `https://assets.macaly-user-data.dev/demo-images/savi-${jobId}.png`}
                      alt="SAVI"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="space-y-4">
                    <div className="text-center">
                      <div className="text-6xl font-mono font-bold text-emerald-400 mb-2">
                        {indices.find(i => i.name === 'SAVI')?.value}
                      </div>
                      <div className="text-slate-400 text-sm">Valor Médio</div>
                    </div>
                    <div className="bg-slate-700/60 rounded-lg p-4 border border-emerald-500/20">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-slate-300 text-sm">Status:</span>
                        <span className="text-emerald-400 font-bold text-sm">{indices.find(i => i.name === 'SAVI')?.status}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-slate-300 text-sm">Faixa:</span>
                        <span className="text-slate-400 text-sm">{indices.find(i => i.name === 'SAVI')?.min} - {indices.find(i => i.name === 'SAVI')?.max}</span>
                      </div>
                    </div>
                    <div>
                      <h4 className="text-emerald-400 font-semibold mb-2">Interpretação</h4>
                      <div className="text-slate-300 text-sm leading-relaxed">
                        O SAVI minimiza a influência do brilho do solo em áreas com vegetação esparsa, 
                        sendo especialmente útil em regiões áridas e semiáridas.
                      </div>
                    </div>
                    <Button 
                      variant="outline" 
                      className="w-full bg-emerald-900/50 border-emerald-500/50 text-emerald-100 hover:bg-emerald-800/50"
                      onClick={() => window.open(realJobData?.resultado?.images?.savi 
                        ? `/api/proxy?path=${realJobData.resultado.images.savi.replace(/^\//, '').split('?')[0]}`
                        : `https://assets.macaly-user-data.dev/demo-images/savi-${jobId}.png`, '_blank')}
                    >
                      📥 Download SAVI
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* GCI Tab */}
          <TabsContent value="gci" className="space-y-6">
            <Card className="bg-slate-800/90 border-emerald-500/30 shadow-lg">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Target className="h-5 w-5 mr-2 text-emerald-400" />
                  GCI - Green Chlorophyll Index
                </CardTitle>
                <div className="text-slate-400 text-sm">Índice de clorofila verde</div>
              </CardHeader>
              <CardContent>
                <div className="grid lg:grid-cols-2 gap-6">
                  <div className="aspect-square bg-slate-700 rounded-lg overflow-hidden border border-emerald-500/20">
                    <img 
                      src={realJobData?.resultado?.images?.gci 
                        ? `/api/proxy?path=${realJobData.resultado.images.gci.replace(/^\//, '').split('?')[0]}`
                        : `https://assets.macaly-user-data.dev/demo-images/gci-${jobId}.png`}
                      alt="GCI"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="space-y-4">
                    <div className="text-center">
                      <div className="text-6xl font-mono font-bold text-emerald-400 mb-2">
                        {indices.find(i => i.name === 'GCI')?.value}
                      </div>
                      <div className="text-slate-400 text-sm">Valor Médio</div>
                    </div>
                    <div className="bg-slate-700/60 rounded-lg p-4 border border-emerald-500/20">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-slate-300 text-sm">Status:</span>
                        <span className="text-emerald-400 font-bold text-sm">{indices.find(i => i.name === 'GCI')?.status}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-slate-300 text-sm">Faixa:</span>
                        <span className="text-slate-400 text-sm">{indices.find(i => i.name === 'GCI')?.min} - {indices.find(i => i.name === 'GCI')?.max}</span>
                      </div>
                    </div>
                    <div>
                      <h4 className="text-emerald-400 font-semibold mb-2">Interpretação</h4>
                      <div className="text-slate-300 text-sm leading-relaxed">
                        O GCI é sensível ao conteúdo de clorofila nas folhas e é útil para avaliar o estresse 
                        da vegetação e a eficiência fotossintética das plantas.
                      </div>
                    </div>
                    <Button 
                      variant="outline" 
                      className="w-full bg-emerald-900/50 border-emerald-500/50 text-emerald-100 hover:bg-emerald-800/50"
                      onClick={() => window.open(realJobData?.resultado?.images?.gci 
                        ? `/api/proxy?path=${realJobData.resultado.images.gci.replace(/^\//, '').split('?')[0]}`
                        : `https://assets.macaly-user-data.dev/demo-images/gci-${jobId}.png`, '_blank')}
                    >
                      📥 Download GCI
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}