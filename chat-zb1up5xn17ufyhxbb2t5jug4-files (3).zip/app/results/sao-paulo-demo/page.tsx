'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { ArrowLeft } from 'lucide-react'
import ResultsViewer from '@/components/results-viewer'

export default function SaoPauloResults() {
  const router = useRouter()

  // Demo results data with proper structure for ResultsViewer
  const demoResults = {
    metadata: {
      job_id: 'sao-paulo-demo',
      satelite: 'Sentinel-2 L2A',
      data_captura: '2024-07-06',
      cobertura_nuvens: 15,
      coordenadas: [-46.6333, -23.5505],
      resolucao: '10m',
      localizacao: 'São Paulo, SP'
    },
    images: {
      rgb: '/api/demo-static/rgb.png',
      ndvi: '/api/demo-static/ndvi.png', 
      evi: '/api/demo-static/evi.png',
      savi: '/api/demo-static/savi.png',
      gci: '/api/demo-static/gci.png'
    },
    indices: [
      { indice: 'NDVI', min: 0.1, media: 0.65, max: 0.9, percentil_25: 0.3, percentil_75: 0.8, pixels_validos: 125643 },
      { indice: 'EVI', min: 0.05, media: 0.45, max: 0.8, percentil_25: 0.2, percentil_75: 0.6, pixels_validos: 125643 },
      { indice: 'SAVI', min: 0.08, media: 0.5, max: 0.85, percentil_25: 0.25, percentil_75: 0.7, pixels_validos: 125643 },
      { indice: 'GCI', min: 1.2, media: 2.8, max: 4.5, percentil_25: 1.8, percentil_75: 3.4, pixels_validos: 125643 }
    ]
  }

  return (
    <div className="h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-green-900 flex flex-col">
      {/* Header */}
      <header className="bg-slate-900/95 backdrop-blur-md border-b border-emerald-500/30 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="relative w-16 h-16">
            <div className="absolute inset-0 w-16 h-16 bg-gradient-to-br from-emerald-400 via-green-500 to-amber-400 rounded-full opacity-30"></div>
            <div className="absolute inset-2 w-12 h-12 bg-gradient-to-br from-emerald-400 via-green-500 to-amber-400 rounded-full flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                <path d="M13 7 9 3 5 7l4 4"></path>
                <path d="m17 11 4 4-4 4-4-4"></path>
                <path d="m8 12 4 4 6-6-4-4Z"></path>
                <path d="m16 8 3-3"></path>
                <path d="M9 21a6 6 0 0 0-6-6"></path>
              </svg>
            </div>
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white font-fira">iAgroSat</h1>
            <p className="text-emerald-300 text-sm font-fira font-medium">ANÁLISE SATELITAL AVANÇADA</p>
          </div>
        </div>
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-400">
              <path d="M20 6 9 17l-5-5"/>
            </svg>
            <span className="text-sm text-slate-300 font-fira font-medium">SISTEMA OPERACIONAL</span>
          </div>
          <div className="flex items-center space-x-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-amber-400">
              <path d="M13 7 9 3 5 7l4 4"></path>
              <path d="m17 11 4 4-4 4-4-4"></path>
              <path d="m8 12 4 4 6-6-4-4Z"></path>
              <path d="m16 8 3-3"></path>
              <path d="M9 21a6 6 0 0 0-6-6"></path>
            </svg>
            <span className="text-sm text-slate-300 font-fira font-medium">ANÁLISE SATELITAL AVANÇADA</span>
          </div>
        </div>
      </header>
      
      <div className="flex-1 p-8 overflow-auto">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-8">
            <Button
              variant="outline"
              onClick={() => router.push('/')}
              className="flex items-center gap-2 mb-4 bg-slate-800/80 border-emerald-500/30 text-emerald-400 hover:bg-slate-700/80"
            >
              <ArrowLeft className="h-4 w-4" />
              Voltar ao Início
            </Button>
            <h1 className="text-3xl font-bold text-white mb-2 font-fira">
              🛰️ SENTINEL-2 ANALYSIS COMPLETE
            </h1>
            <p className="text-slate-300 font-mono font-fira">
              High-resolution satellite data processing completed
            </p>
          </div>
          
          {/* Use Original ResultsViewer Component */}
          <div className="bg-white rounded-lg shadow-lg p-1">
            <ResultsViewer results={demoResults} />
          </div>
        </div>
      </div>
    </div>
  )
}