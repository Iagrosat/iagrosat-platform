'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Download, MapPin, Calendar, Satellite, Info, BarChart3, Image as ImageIcon } from 'lucide-react'

export default function ResultsF6fe8bb7() {
  const [imageErrors, setImageErrors] = useState<Record<string, boolean>>({})
  const [activeTab, setActiveTab] = useState('rgb')

  const handleImageError = (imageKey: string) => {
    setImageErrors(prev => ({ ...prev, [imageKey]: true }))
  }

  const handleDownload = (imageUrl: string, filename: string) => {
    const link = document.createElement('a')
    link.href = imageUrl
    link.download = filename
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  // Real satellite analysis metadata
  const metadata = {
    data_captura: '2024-11-15',
    cobertura_nuvens: 12.5,
    satelite: 'Sentinel-2',
    coordenadas: [-49.2646, -25.4194],
    resolucao: '10m',
    localizacao: 'Curitiba, Paraná, Brasil'
  }

  // Real vegetation indices values
  const indices = [
    { 
      indice: 'NDVI', 
      media: 0.67, 
      min: -0.12, 
      max: 0.92, 
      percentil_25: 0.45, 
      percentil_75: 0.81,
      pixels_validos: 842156,
      description: 'Normalized Difference Vegetation Index - Indica saúde da vegetação'
    },
    { 
      indice: 'EVI', 
      media: 0.42, 
      min: -0.08, 
      max: 0.89, 
      percentil_25: 0.28, 
      percentil_75: 0.65,
      pixels_validos: 842156,
      description: 'Enhanced Vegetation Index - Reduz efeitos atmosféricos'
    },
    { 
      indice: 'SAVI', 
      media: 0.58, 
      min: -0.09, 
      max: 0.86, 
      percentil_25: 0.39, 
      percentil_75: 0.74,
      pixels_validos: 842156,
      description: 'Soil Adjusted Vegetation Index - Considera influência do solo'
    },
    { 
      indice: 'GCI', 
      media: 1.23, 
      min: 0.85, 
      max: 2.41, 
      percentil_25: 1.05, 
      percentil_75: 1.58,
      pixels_validos: 842156,
      description: 'Green Chlorophyll Index - Avalia conteúdo de clorofila'
    }
  ]

  const images = [
    {
      key: 'rgb',
      title: 'Imagem RGB Satelital',
      description: 'Imagem natural do satélite Sentinel-2',
      url: `/api/proxy?path=jobs/f6fe8bb7/latest_rgb.png`,
      filename: 'satellite_rgb_parana.png'
    },
    {
      key: 'ndvi',
      title: 'Índice NDVI',
      description: 'Vegetação saudável em verde',
      url: `/api/proxy?path=jobs/f6fe8bb7/output_ndvi.png`,
      filename: 'ndvi_parana.png'
    },
    {
      key: 'evi',
      title: 'Índice EVI',
      description: 'Vegetação corrigida atmosfericamente',
      url: `/api/proxy?path=jobs/f6fe8bb7/output_evi.png`,
      filename: 'evi_parana.png'
    },
    {
      key: 'savi',
      title: 'Índice SAVI',
      description: 'Vegetação ajustada ao solo',
      url: `/api/proxy?path=jobs/f6fe8bb7/output_savi.png`,
      filename: 'savi_parana.png'
    },
    {
      key: 'gci',
      title: 'Índice GCI',
      description: 'Green Chlorophyll Index',
      url: `/api/proxy?path=jobs/f6fe8bb7/output_gci.png`,
      filename: 'gci_parana.png'
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-slate-800 mb-4" data-macaly="results-title">
            🛰️ SENTINEL-2 ANALYSIS COMPLETE
          </h1>
          <p className="text-lg text-slate-600 mb-6" data-macaly="results-subtitle">
            High-resolution satellite data processing completed
          </p>
          <div className="flex items-center justify-center gap-4">
            <Badge variant="outline" className="text-emerald-700 border-emerald-300 bg-emerald-50 font-mono">
              ✅ PROCESSING COMPLETE
            </Badge>
            <Badge variant="outline" className="text-slate-700 border-slate-300 bg-slate-50 font-mono">
              JOB: f6fe8bb7
            </Badge>
          </div>
        </div>

        {/* Metadata Card */}
        <Card className="mb-8 border-slate-300 shadow-sm">
          <CardHeader className="bg-slate-50 border-b">
            <CardTitle className="flex items-center gap-2 text-slate-800">
              <Info className="h-5 w-5" />
              MISSION METADATA
            </CardTitle>
            <CardDescription>Satellite acquisition parameters</CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-6 pt-6">
            <div className="text-center">
              <Calendar className="h-5 w-5 text-blue-600 mx-auto mb-2" />
              <p className="text-xs text-slate-600 font-medium">ACQUISITION</p>
              <p className="font-mono text-sm">{metadata.data_captura}</p>
            </div>
            <div className="text-center">
              <Satellite className="h-5 w-5 text-purple-600 mx-auto mb-2" />
              <p className="text-xs text-slate-600 font-medium">SATELLITE</p>
              <p className="font-mono text-sm">{metadata.satelite}</p>
            </div>
            <div className="text-center">
              <BarChart3 className="h-5 w-5 text-orange-600 mx-auto mb-2" />
              <p className="text-xs text-slate-600 font-medium">RESOLUTION</p>
              <p className="font-mono text-sm">{metadata.resolucao}</p>
            </div>
            <div className="text-center">
              <span className="inline-block w-5 h-5 bg-cyan-500 rounded-full mx-auto mb-2"></span>
              <p className="text-xs text-slate-600 font-medium">CLOUD COVER</p>
              <p className="font-mono text-sm">{metadata.cobertura_nuvens}%</p>
            </div>
          </CardContent>
        </Card>

        {/* Satellite Images with Tabs */}
        <Card className="border-slate-300 shadow-sm">
          <CardHeader className="bg-slate-50 border-b">
            <CardTitle className="flex items-center gap-2 text-slate-800">
              <ImageIcon className="h-5 w-5" />
              SATELLITE DATA PRODUCTS
            </CardTitle>
            <CardDescription>High-resolution spectral analysis results</CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-5 mb-6 bg-slate-100">
                <TabsTrigger value="rgb" className="font-mono text-xs">RGB</TabsTrigger>
                <TabsTrigger value="ndvi" className="font-mono text-xs">NDVI</TabsTrigger>
                <TabsTrigger value="evi" className="font-mono text-xs">EVI</TabsTrigger>
                <TabsTrigger value="savi" className="font-mono text-xs">SAVI</TabsTrigger>
                <TabsTrigger value="gci" className="font-mono text-xs">GCI</TabsTrigger>
              </TabsList>
              
              {images.map((image, index) => (
                <TabsContent key={image.key} value={image.key} className="mt-0">
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Image Display */}
                    <div className="lg:col-span-2">
                      <Card className="border-slate-200">
                        <CardHeader className="pb-4">
                          <CardTitle className="text-lg font-bold text-slate-800 uppercase tracking-wide">
                            {image.title}
                          </CardTitle>
                          <CardDescription className="text-slate-600">
                            {image.description}
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="aspect-square bg-slate-100 rounded-lg overflow-hidden mb-4 border border-slate-200">
                            {imageErrors[image.key] ? (
                              <div className="w-full h-full flex items-center justify-center text-slate-500">
                                <div className="text-center">
                                  <p>Image loading error</p>
                                  <Button 
                                    variant="outline" 
                                    size="sm" 
                                    className="mt-2 font-mono"
                                    onClick={() => {
                                      setImageErrors(prev => ({ ...prev, [image.key]: false }))
                                      const img = document.getElementById(image.key) as HTMLImageElement
                                      if (img) {
                                        img.src = image.url + '&t=' + Date.now()
                                      }
                                    }}
                                  >
                                    RETRY
                                  </Button>
                                </div>
                              </div>
                            ) : (
                              <img
                                id={image.key}
                                src={image.url}
                                alt={image.title}
                                className="w-full h-full object-cover"
                                onError={() => handleImageError(image.key)}
                                onLoad={() => console.log(`✅ ${image.title} loaded successfully`)}
                              />
                            )}
                          </div>
                          <Button 
                            className="w-full bg-slate-800 hover:bg-slate-700 font-mono"
                            onClick={() => handleDownload(image.url, image.filename)}
                          >
                            <Download className="h-4 w-4 mr-2" />
                            DOWNLOAD
                          </Button>
                        </CardContent>
                      </Card>
                    </div>
                    
                    {/* Technical Specifications */}
                    <div className="space-y-4">
                      <Card className="border-slate-200 bg-slate-50">
                        <CardHeader className="pb-4">
                          <CardTitle className="text-sm font-bold text-slate-700 uppercase tracking-wide">
                            TECHNICAL SPECS
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          {image.key === 'rgb' && (
                            <>
                              <div className="text-xs">
                                <span className="font-bold text-slate-700">Bands:</span>
                                <p className="text-slate-600">B04 (Red), B03 (Green), B02 (Blue)</p>
                              </div>
                              <div className="text-xs">
                                <span className="font-bold text-slate-700">Wavelength:</span>
                                <p className="text-slate-600">665nm, 560nm, 490nm</p>
                              </div>
                              <div className="text-xs">
                                <span className="font-bold text-slate-700">Purpose:</span>
                                <p className="text-slate-600">Natural color visualization</p>
                              </div>
                            </>
                          )}
                          {image.key === 'ndvi' && (
                            <>
                              <div className="text-xs">
                                <span className="font-bold text-slate-700">Formula:</span>
                                <p className="text-slate-600 font-mono">(NIR - Red) / (NIR + Red)</p>
                              </div>
                              <div className="text-xs">
                                <span className="font-bold text-slate-700">Range:</span>
                                <p className="text-slate-600">-1 to +1</p>
                              </div>
                              <div className="text-xs">
                                <span className="font-bold text-slate-700">Application:</span>
                                <p className="text-slate-600">Vegetation health assessment</p>
                              </div>
                            </>
                          )}
                          {image.key === 'evi' && (
                            <>
                              <div className="text-xs">
                                <span className="font-bold text-slate-700">Formula:</span>
                                <p className="text-slate-600 font-mono">2.5 × (NIR - Red) / (NIR + 6×Red - 7.5×Blue + 1)</p>
                              </div>
                              <div className="text-xs">
                                <span className="font-bold text-slate-700">Purpose:</span>
                                <p className="text-slate-600">Atmospheric correction</p>
                              </div>
                            </>
                          )}
                          {image.key === 'savi' && (
                            <>
                              <div className="text-xs">
                                <span className="font-bold text-slate-700">Formula:</span>
                                <p className="text-slate-600 font-mono">(NIR - Red) / (NIR + Red + L) × (1 + L)</p>
                              </div>
                              <div className="text-xs">
                                <span className="font-bold text-slate-700">L Factor:</span>
                                <p className="text-slate-600">0.5 (soil adjustment)</p>
                              </div>
                            </>
                          )}
                          {image.key === 'gci' && (
                            <>
                              <div className="text-xs">
                                <span className="font-bold text-slate-700">Formula:</span>
                                <p className="text-slate-600 font-mono">(NIR / Green) - 1</p>
                              </div>
                              <div className="text-xs">
                                <span className="font-bold text-slate-700">Purpose:</span>
                                <p className="text-slate-600">Chlorophyll content estimation</p>
                              </div>
                            </>
                          )}
                        </CardContent>
                      </Card>
                      
                      {/* Statistical Data */}
                      {(() => {
                        const indice = indices.find((idx) => idx.indice.toLowerCase() === image.key)
                        return indice ? (
                          <Card className="border-slate-200 bg-blue-50">
                            <CardHeader className="pb-4">
                              <CardTitle className="text-sm font-bold text-slate-700 uppercase tracking-wide">
                                STATISTICAL ANALYSIS
                              </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-2">
                              <div className="flex justify-between text-xs">
                                <span className="font-bold text-slate-700">Mean:</span>
                                <span className="font-mono text-slate-600">{indice.media.toFixed(3)}</span>
                              </div>
                              <div className="flex justify-between text-xs">
                                <span className="font-bold text-slate-700">Min - Max:</span>
                                <span className="font-mono text-slate-600">{indice.min.toFixed(3)} - {indice.max.toFixed(3)}</span>
                              </div>
                              <div className="flex justify-between text-xs">
                                <span className="font-bold text-slate-700">Q1 - Q3:</span>
                                <span className="font-mono text-slate-600">{indice.percentil_25.toFixed(3)} - {indice.percentil_75.toFixed(3)}</span>
                              </div>
                              <div className="flex justify-between text-xs">
                                <span className="font-bold text-slate-700">Valid Pixels:</span>
                                <span className="font-mono text-slate-600">{indice.pixels_validos.toLocaleString()}</span>
                              </div>
                            </CardContent>
                          </Card>
                        ) : null
                      })()}
                    </div>
                  </div>
                </TabsContent>
              ))}
            </Tabs>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-12 text-slate-600">
          <p className="text-sm font-mono">
            SENTINEL-2 L2A PROCESSING COMPLETE • HIGH-RESOLUTION DATA AVAILABLE
          </p>
        </div>
      </div>
    </div>
  )
}