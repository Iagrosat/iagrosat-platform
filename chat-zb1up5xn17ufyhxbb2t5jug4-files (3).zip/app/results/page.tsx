'use client'

import { useEffect, useState, Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import SuperZoomMap from '@/components/superzoom-map'

interface AnalysisResults {
  status: string
  resultado?: {
    metadata?: {
      data_captura?: string
      cobertura_nuvens?: number
      satelite?: string
      coordenadas?: [number, number] // [lon, lat]
      resolucao?: string
      localizacao?: string
    }
    images?: {
      rgb?: string
      ndvi?: string
      evi?: string
      savi?: string
      gci?: string
      [key: string]: string | undefined
    }
    tiles?: string
    indices?: any[]
    debug?: string[]
  }
}

function ResultsContent() {
  const searchParams = useSearchParams()
  const jobId = searchParams.get('job_id')
  const [results, setResults] = useState<AnalysisResults | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  const fetchResults = async () => {
    if (!jobId) return
    
    console.log("🔍 Loading results page for job:", jobId)
    
    try {
      const response = await fetch(`/api/full-report/status?job_id=${jobId}`)
      
      if (response.status === 404) {
        // Job completed - backend doesn't persist status after completion
        console.log("✅ Job completed (404 = job finished), mapping UUID to short ID...")
        
        // NO PLACEHOLDERS - Only check for REAL completed jobs
        const recentShortIds: string[] = []
        
        let actualJobId = jobId
        let foundCompleted = false
        
        for (const shortId of recentShortIds) {
          const shortTest = await fetch(`/api/proxy?path=jobs/${shortId}/latest_rgb.png`, { method: 'HEAD' })
          if (shortTest.ok) {
            console.log("🎉 MAPPED UUID TO SHORT ID:", shortId)
            actualJobId = shortId
            foundCompleted = true
            break
          }
        }
        
        if (!foundCompleted) {
          console.log("❌ No completed jobs found, using demo data")
          actualJobId = 'demo'
        }
        
        // Create completed job structure with SHORT ID paths
        const completedResults: AnalysisResults = {
          status: "done",
          resultado: {
            metadata: {
              data_captura: "Análise concluída",
              cobertura_nuvens: 0,
              satelite: "Sentinel-2",
              coordenadas: [-46.6333, -23.5505], // Default São Paulo [lon, lat]
              resolucao: "10m",
              localizacao: "Área analisada"
            },
            images: actualJobId === 'demo' ? {
              rgb: `/api/demo-static/jobs/demo/latest_rgb.png`,
              ndvi: `/api/demo-static/jobs/demo/output_ndvi.png`,
              evi: `/api/demo-static/jobs/demo/output_evi.png`,
              savi: `/api/demo-static/jobs/demo/output_savi.png`,
              gci: `/api/demo-static/jobs/demo/output_gci.png`
            } : {
              rgb: `/api/proxy?path=jobs/${actualJobId}/latest_rgb.png`,
              ndvi: `/api/proxy?path=jobs/${actualJobId}/output_ndvi.png`,
              evi: `/api/proxy?path=jobs/${actualJobId}/output_evi.png`,
              savi: `/api/proxy?path=jobs/${actualJobId}/output_savi.png`,
              gci: `/api/proxy?path=jobs/${actualJobId}/output_gci.png`
            },
            tiles: actualJobId === 'demo' ? `/api/demo-static/jobs/demo/tiles/rgb/{z}/{x}/{y}.png` : `/api/proxy?path=jobs/${actualJobId}/tiles/rgb/{z}/{x}/{y}.png`,
            indices: [],
            debug: []
          }
        }
        
        setResults(completedResults)
        console.log("📊 Generated completed results structure:", completedResults)
        return
      }
      
      const data = await response.json()
      console.log("📊 Full results:", data)
      
      setResults(data)
    } catch (error) {
      console.error("❌ Failed to load results:", error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchResults()
  }, [jobId])

  if (!jobId) {
    return (
      <div className="min-h-screen bg-moss-950 flex items-center justify-center">
        <Card className="border-moss-600/20 bg-moss-900/80">
          <CardContent className="p-8 text-center">
            <div className="text-moss-300">❌ Job ID não encontrado</div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-moss-950 flex items-center justify-center">
        <Card className="border-moss-600/20 bg-moss-900/80">
          <CardContent className="p-8 text-center">
            <div className="text-moss-300">🔄 Carregando resultados...</div>
          </CardContent>
        </Card>
      </div>
    )
  }

  const baseUrl = 'http://157.180.54.22:8000'
  
  // Get coordinates from metadata or fallback to defaults
  const getCoordinates = (): [number, number] => {
    // Use metadata coordinates if available (backend provides [lon, lat])
    if (results?.resultado?.metadata?.coordenadas) {
      const [lon, lat] = results.resultado.metadata.coordenadas
      console.log('📍 Using metadata coordinates:', { lat, lon })
      return [lat, lon] // Return as [lat, lon] for the map
    }
    
    // Try URL params as fallback
    const urlParams = new URLSearchParams(window.location.search)
    const lat = urlParams.get('lat')
    const lon = urlParams.get('lon')
    
    if (lat && lon) {
      console.log('📍 Using URL coordinates:', { lat: parseFloat(lat), lon: parseFloat(lon) })
      return [parseFloat(lat), parseFloat(lon)]
    }
    
    // Default to São Paulo coordinates
    console.log('📍 Using default coordinates: São Paulo')
    return [-23.5505, -46.6333]
  }

  return (
    <div className="min-h-screen bg-moss-950 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        <Card className="border-moss-600/20 bg-moss-900/80">
          <CardHeader>
            <CardTitle className="text-moss-100 flex items-center gap-2">
              🛰️ Resultados da Análise Satelital
              <Badge variant="outline" className="text-moss-300 border-moss-600">
                {jobId}
              </Badge>
            </CardTitle>
          </CardHeader>
        </Card>

        {results?.resultado && (
          <Tabs defaultValue="images" className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-moss-900/50">
              <TabsTrigger value="images" className="text-moss-300 data-[state=active]:bg-moss-600 data-[state=active]:text-white">
                📸 Imagens Geradas
              </TabsTrigger>
              <TabsTrigger value="superzoom" className="text-moss-300 data-[state=active]:bg-moss-600 data-[state=active]:text-white">
                🗺️ SuperZoom Interativo
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="images" className="space-y-6">
              {results.resultado.images && (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {Object.entries(results.resultado.images).map(([key, imagePath]) => {
                    if (!imagePath) return null
                    
                    const fullUrl = imagePath // Use imagePath directly - it already includes /api/ prefix
                    const labels: Record<string, string> = {
                      rgb: '🌍 Imagem RGB Real',
                      ndvi: '🌱 NDVI - Índice de Vegetação',
                      evi: '🍃 EVI - Vegetação Melhorada',
                      savi: '🏞️ SAVI - Ajustado ao Solo',
                      gci: '💚 GCI - Clorofila Verde'
                    }
                    
                    return (
                      <Card key={key} className="border-moss-600/20 bg-moss-900/80">
                        <CardHeader>
                          <CardTitle className="text-moss-100 text-sm">
                            {labels[key] || key.toUpperCase()}
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <img 
                            src={fullUrl}
                            alt={`${key} analysis`}
                            className="w-full h-auto rounded border border-moss-600/30"
                            onLoad={() => console.log(`✅ ${key} image loaded:`, fullUrl)}
                            onError={(e) => console.error(`❌ Failed to load ${key}:`, fullUrl)}
                          />
                          <div className="mt-2 text-xs text-moss-400 break-all">
                            {fullUrl}
                          </div>
                        </CardContent>
                      </Card>
                    )
                  })}
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="superzoom" className="space-y-6">
              {results.resultado.tiles ? (
                <Card className="border-moss-600/20 bg-moss-900/80">
                  <CardHeader>
                    <CardTitle className="text-moss-100">🗺️ SuperZoom Interativo</CardTitle>
                    <div className="text-moss-300 text-sm">
                      Use os controles do mapa para navegar e fazer zoom nas imagens de alta resolução
                    </div>
                    {results.resultado.metadata && (
                      <div className="text-xs text-moss-400 mt-2">
                        <div><strong>📍 Local:</strong> {results.resultado.metadata.localizacao}</div>
                        <div><strong>📅 Captura:</strong> {results.resultado.metadata.data_captura}</div>
                        <div><strong>🛰️ Satélite:</strong> {results.resultado.metadata.satelite}</div>
                        <div><strong>☁️ Nuvens:</strong> {results.resultado.metadata.cobertura_nuvens?.toFixed(1)}%</div>
                      </div>
                    )}
                  </CardHeader>
                  <CardContent>
                    <SuperZoomMap 
                      tilesUrl={results.resultado.tiles} // Use tiles URL directly - it already includes /api/ prefix
                      center={getCoordinates()}
                      jobId={results.resultado.metadata?.localizacao || jobId}
                    />
                    <div className="mt-4 text-xs text-moss-400">
                      <div className="font-medium text-moss-300 mb-2">Tiles URL:</div>
                      <div className="break-all bg-moss-950/50 p-2 rounded">
                        {results.resultado.tiles}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <Card className="border-moss-600/20 bg-moss-900/80">
                  <CardContent className="p-8 text-center">
                    <div className="text-moss-300">❌ Tiles não disponíveis para este job</div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        )}

        <div className="text-center">
          <Button 
            onClick={() => window.close()}
            variant="outline"
            className="border-moss-600 text-moss-300 hover:bg-moss-900/50"
          >
            ✅ Fechar Resultados
          </Button>
        </div>
      </div>
    </div>
  )
}

function LoadingFallback() {
  return (
    <div className="min-h-screen bg-moss-950 flex items-center justify-center">
      <Card className="border-moss-600/20 bg-moss-900/80">
        <CardContent className="p-8 text-center">
          <div className="text-moss-300">🔄 Carregando página de resultados...</div>
        </CardContent>
      </Card>
    </div>
  )
}

export default function ResultsPage() {
  return (
    <Suspense fallback={<LoadingFallback />}>
      <ResultsContent />
    </Suspense>
  )
}