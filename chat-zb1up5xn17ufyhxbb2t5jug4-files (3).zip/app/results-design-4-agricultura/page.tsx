'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { ArrowLeft, Download, Leaf, Sun, Droplets, Sprout } from 'lucide-react'
import { useRouter } from 'next/navigation'

export default function ResultsDesign4() {
  const router = useRouter()
  const [activeIndex, setActiveIndex] = useState('ndvi')

  // Demo data with agricultural focus
  const results = {
    metadata: {
      job_id: 'demo-agricultura',
      satelite: 'Sentinel-2 L2A',
      data_captura: '2024-07-06',
      cobertura_nuvens: 12,
      coordenadas: [-46.6333, -23.5505],
      resolucao: '10m',
      localizacao: 'São Paulo, SP',
      area_hectares: 250.5,
      season: 'Verão',
      crop_type: 'Não identificado',
      soil_moisture: 'Adequada'
    },
    images: {
      rgb: '/api/demo-static/rgb.png',
      ndvi: '/api/demo-static/ndvi.png',
      evi: '/api/demo-static/evi.png',
      savi: '/api/demo-static/savi.png',
      gci: '/api/demo-static/gci.png'
    },
    indices: [
      { 
        indice: 'NDVI', 
        nome: 'Índice de Vegetação por Diferença Normalizada',
        min: 0.15, 
        media: 0.68, 
        max: 0.92,
        status: 'Vegetação Saudável',
        recommendation: 'Excelente desenvolvimento vegetativo. Manter práticas atuais.',
        color_scheme: 'Verde intenso indica alta atividade fotossintética'
      },
      { 
        indice: 'EVI', 
        nome: 'Índice de Vegetação Melhorado',
        min: 0.08, 
        media: 0.52, 
        max: 0.89,
        status: 'Vegetação Equilibrada',
        recommendation: 'Condições atmosféricas favoráveis. Boa resposta espectral.',
        color_scheme: 'Tons de verde ajustados para densidade foliar'
      },
      { 
        indice: 'SAVI', 
        nome: 'Índice de Vegetação Ajustado ao Solo',
        min: 0.12, 
        media: 0.58, 
        max: 0.87,
        status: 'Solo Bem Coberto',
        recommendation: 'Cobertura vegetal adequada. Baixa exposição do solo.',
        color_scheme: 'Corrigido para interferência do solo exposto'
      },
      { 
        indice: 'GCI', 
        nome: 'Índice de Clorofila Verde',
        min: 1.8, 
        media: 3.2, 
        max: 5.1,
        status: 'Clorofila Abundante',
        recommendation: 'Alto conteúdo de clorofila. Plantas bem nutridas.',
        color_scheme: 'Mede diretamente o conteúdo de clorofila nas folhas'
      }
    ]
  }

  const indexButtons = [
    { 
      key: 'ndvi', 
      label: 'NDVI', 
      icon: Leaf,
      gradient: 'from-green-500 to-emerald-600',
      description: 'Saúde Geral'
    },
    { 
      key: 'evi', 
      label: 'EVI', 
      icon: Sun,
      gradient: 'from-blue-500 to-sky-600',
      description: 'Densidade Foliar'
    },
    { 
      key: 'savi', 
      label: 'SAVI', 
      icon: Sprout,
      gradient: 'from-amber-500 to-orange-600',
      description: 'Cobertura Solo'
    },
    { 
      key: 'gci', 
      label: 'GCI', 
      icon: Droplets,
      gradient: 'from-emerald-500 to-green-600',
      description: 'Clorofila'
    },
  ]

  const getCurrentIndexData = () => {
    return results.indices.find(idx => idx.indice.toLowerCase() === activeIndex) || results.indices[0]
  }

  const getHealthColor = (value: number, index: string) => {
    if (index === 'gci') {
      if (value >= 3.0) return 'text-green-600'
      if (value >= 2.0) return 'text-yellow-600'
      return 'text-red-600'
    } else {
      if (value >= 0.6) return 'text-green-600'
      if (value >= 0.3) return 'text-yellow-600'
      return 'text-red-600'
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-lime-50">
      {/* Header Agrícola */}
      <header className="bg-gradient-to-r from-green-800 via-emerald-800 to-green-700 text-white px-6 py-6 shadow-lg">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-4">
              <Button
                variant="outline"
                size="sm"
                onClick={() => router.push('/')}
                className="flex items-center gap-2 border-green-300 text-green-100 hover:bg-green-700/50"
              >
                <ArrowLeft className="h-4 w-4" />
                <Leaf className="h-4 w-4" />
                Plantio
              </Button>
              <div className="h-6 w-px bg-green-300/50"></div>
              <div>
                <h1 className="text-3xl font-bold text-white">
                  🌱 Relatório Agronômico
                </h1>
                <p className="text-green-200 mt-1">Análise Espectral para Agricultura de Precisão</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <div className="text-sm text-green-200">Condições</div>
                <div className="text-lg font-bold text-green-100">FAVORÁVEIS</div>
              </div>
              <Button className="bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700">
                <Download className="h-4 w-4 mr-2" />
                Relatório PDF
              </Button>
            </div>
          </div>
          
          {/* Condições Ambientais */}
          <div className="grid grid-cols-5 gap-4">
            <div className="bg-green-700/30 border border-green-500/30 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs text-green-200 font-medium">ESTAÇÃO</div>
                  <div className="text-lg font-bold text-white">{results.metadata.season}</div>
                </div>
                <Sun className="h-6 w-6 text-yellow-300" />
              </div>
            </div>
            <div className="bg-green-700/30 border border-green-500/30 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs text-green-200 font-medium">ÁREA</div>
                  <div className="text-lg font-bold text-white">{results.metadata.area_hectares}ha</div>
                </div>
                <div className="text-green-200">🏞️</div>
              </div>
            </div>
            <div className="bg-green-700/30 border border-green-500/30 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs text-green-200 font-medium">UMIDADE</div>
                  <div className="text-lg font-bold text-white">{results.metadata.soil_moisture}</div>
                </div>
                <Droplets className="h-6 w-6 text-blue-300" />
              </div>
            </div>
            <div className="bg-green-700/30 border border-green-500/30 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs text-green-200 font-medium">NUVENS</div>
                  <div className="text-lg font-bold text-white">{results.metadata.cobertura_nuvens}%</div>
                </div>
                <div className="text-green-200">☁️</div>
              </div>
            </div>
            <div className="bg-green-700/30 border border-green-500/30 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs text-green-200 font-medium">CULTURA</div>
                  <div className="text-sm font-bold text-white">{results.metadata.crop_type}</div>
                </div>
                <Sprout className="h-6 w-6 text-green-300" />
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-6 space-y-8">
        {/* Vista Aérea da Propriedade */}
        <div className="bg-white rounded-2xl shadow-xl border border-green-200 overflow-hidden">
          <div className="bg-gradient-to-r from-green-100 to-emerald-100 px-6 py-4 border-b border-green-200">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
                <Leaf className="h-4 w-4 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-green-800">Vista Aérea da Propriedade</h2>
                <p className="text-sm text-green-600">Imagem natural captada pelo satélite • {results.metadata.localizacao}</p>
              </div>
            </div>
          </div>
          <div className="p-8">
            <div className="text-center">
              <img 
                src={results.images.rgb}
                alt="Vista aérea da propriedade" 
                className="max-w-3xl mx-auto rounded-xl shadow-lg border border-green-200"
              />
              <div className="mt-4 text-sm text-green-600">
                📅 Capturada em {results.metadata.data_captura} • 🛰️ {results.metadata.satelite} • 📏 Resolução {results.metadata.resolucao}
              </div>
            </div>
          </div>
        </div>

        {/* Análise da Vegetação */}
        <div className="bg-white rounded-2xl shadow-xl border border-green-200 overflow-hidden">
          <div className="bg-gradient-to-r from-green-100 to-emerald-100 px-6 py-4 border-b border-green-200">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center">
                <Sprout className="h-4 w-4 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-green-800">Análise da Vegetação</h2>
                <p className="text-sm text-green-600">Índices espectrais para monitoramento agrícola</p>
              </div>
            </div>
          </div>
          
          <div className="p-6">
            {/* Seleção de Índices - Style Agrícola */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              {indexButtons.map((btn) => {
                const IconComponent = btn.icon
                return (
                  <button
                    key={btn.key}
                    onClick={() => setActiveIndex(btn.key)}
                    className={`p-4 rounded-xl transition-all transform hover:scale-105 ${
                      activeIndex === btn.key 
                        ? `bg-gradient-to-br ${btn.gradient} text-white shadow-lg` 
                        : 'bg-green-50 hover:bg-green-100 border border-green-200'
                    }`}
                  >
                    <div className="text-center">
                      <IconComponent className={`h-8 w-8 mx-auto mb-2 ${
                        activeIndex === btn.key ? 'text-white' : 'text-green-600'
                      }`} />
                      <div className={`font-bold ${
                        activeIndex === btn.key ? 'text-white' : 'text-green-800'
                      }`}>
                        {btn.label}
                      </div>
                      <div className={`text-xs ${
                        activeIndex === btn.key ? 'text-green-100' : 'text-green-600'
                      }`}>
                        {btn.description}
                      </div>
                    </div>
                  </button>
                )
              })}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Mapa de Índice */}
              <div className="lg:col-span-2">
                <div className="bg-green-50 rounded-xl p-6 border border-green-200">
                  <h3 className="text-lg font-bold text-green-800 mb-4 flex items-center">
                    <Leaf className="h-5 w-5 mr-2 text-green-600" />
                    {getCurrentIndexData().nome}
                  </h3>
                  <img
                    src={results.images[activeIndex]}
                    alt={`Análise ${getCurrentIndexData().indice}`}
                    className="w-full rounded-lg shadow-md border border-green-200"
                  />
                  <div className="mt-4 bg-white rounded-lg p-3 border border-green-200">
                    <div className="text-sm text-green-700">
                      <strong>Interpretação:</strong> {getCurrentIndexData().color_scheme}
                    </div>
                  </div>
                </div>
              </div>

              {/* Status e Recomendações */}
              <div className="space-y-6">
                {/* Status da Vegetação */}
                <div className="bg-green-50 rounded-xl p-4 border border-green-200">
                  <h4 className="font-bold text-green-800 mb-3 flex items-center">
                    <Sun className="h-4 w-4 mr-2" />
                    Status da Vegetação
                  </h4>
                  <div className="text-center mb-4">
                    <div className="text-2xl font-bold text-green-700">{getCurrentIndexData().status}</div>
                    <div className={`text-lg font-semibold ${getHealthColor(getCurrentIndexData().media, activeIndex)}`}>
                      Valor Médio: {getCurrentIndexData().media}
                    </div>
                  </div>
                </div>

                {/* Recomendação Agronômica */}
                <div className="bg-amber-50 rounded-xl p-4 border border-amber-200">
                  <h4 className="font-bold text-amber-800 mb-3 flex items-center">
                    <Sprout className="h-4 w-4 mr-2" />
                    Recomendação
                  </h4>
                  <div className="text-sm text-amber-700">
                    {getCurrentIndexData().recommendation}
                  </div>
                </div>

                {/* Valores Estatísticos */}
                <div className="bg-blue-50 rounded-xl p-4 border border-blue-200">
                  <h4 className="font-bold text-blue-800 mb-3">Valores Observados</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-blue-600 text-sm">Mínimo:</span>
                      <span className="font-bold text-blue-800">{getCurrentIndexData().min}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-blue-600 text-sm">Médio:</span>
                      <span className="font-bold text-blue-800">{getCurrentIndexData().media}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-blue-600 text-sm">Máximo:</span>
                      <span className="font-bold text-blue-800">{getCurrentIndexData().max}</span>
                    </div>
                  </div>
                </div>

                {/* Download */}
                <Button className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700">
                  <Download className="h-4 w-4 mr-2" />
                  Baixar {getCurrentIndexData().indice}
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Informações da Propriedade */}
        <div className="bg-gradient-to-r from-green-600 to-emerald-600 rounded-2xl shadow-xl p-6 text-white">
          <h3 className="text-lg font-bold mb-4 flex items-center">
            <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center mr-3">
              <Leaf className="h-3 w-3" />
            </div>
            Informações da Propriedade
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-sm">
            <div>
              <div className="text-green-200 mb-1">📍 Localização</div>
              <div className="font-semibold">{results.metadata.localizacao}</div>
            </div>
            <div>
              <div className="text-green-200 mb-1">🗺️ Coordenadas</div>
              <div className="font-semibold font-mono text-xs">
                {results.metadata.coordenadas[1]}, {results.metadata.coordenadas[0]}
              </div>
            </div>
            <div>
              <div className="text-green-200 mb-1">🛰️ Satélite</div>
              <div className="font-semibold">{results.metadata.satelite}</div>
            </div>
            <div>
              <div className="text-green-200 mb-1">🆔 Análise</div>
              <div className="font-semibold font-mono text-xs">{results.metadata.job_id}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}