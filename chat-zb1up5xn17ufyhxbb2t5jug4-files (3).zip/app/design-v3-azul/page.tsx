'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { MapContainer } from '@/components/map-container'

export default function DesignV3Azul() {
  const [searchQuery, setSearchQuery] = useState('')
  const [currentCoordinates, setCurrentCoordinates] = useState({ lat: -23.5505, lng: -46.6333 })
  const [selectedTool, setSelectedTool] = useState<string | null>(null)
  const [selectedArea, setSelectedArea] = useState({ points: 1, area: 0.25 })
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleSearch = async () => {
    const query = searchQuery.trim()
    if (!query) return

    console.log("🔍 Buscando por:", query)
    
    try {
      // Detecta coordenadas (lat,lng)
      const coordMatch = query.match(/(-?\d+\.?\d*),?\s*(-?\d+\.?\d*)/)
      if (coordMatch) {
        const lat = parseFloat(coordMatch[1])
        const lng = parseFloat(coordMatch[2])
        console.log("📍 Coordenadas detectadas:", lat, lng)
        setCurrentCoordinates({ lat, lng })
        return
      }
      
      // Busca cidade via ESRI
      const geocodeUrl = `https://geocode-api.arcgis.com/arcgis/rest/services/World/GeocodeServer/findAddressCandidates?singleLine=${encodeURIComponent(query)}&maxLocations=1&outFields=*&f=json`
      
      const response = await fetch(geocodeUrl)
      const data = await response.json()
      
      if (data.candidates && data.candidates.length > 0) {
        const result = data.candidates[0]
        const lat = result.location.y
        const lng = result.location.x
        
        console.log("🌍 Local encontrado:", result.address, "em", lat, lng)
        setCurrentCoordinates({ lat, lng })
      } else {
        alert('Local não encontrado. Tente outro nome.')
      }
    } catch (error) {
      console.error('Erro na busca:', error)
      alert('Erro na busca. Tente novamente.')
    }
  }

  const processAnalysis = () => {
    console.log("🚀 Iniciando análise")
    setIsLoading(true)
    const jobId = `job-${Date.now()}`
    router.push(`/results/${jobId}`)
  }

  const clearSelection = () => {
    setSelectedArea({ points: 1, area: 0.25 })
    setSelectedTool(null)
  }

  return (
    <div className="h-screen bg-gradient-to-br from-blue-900 via-slate-900 to-indigo-900 flex flex-col">
      {/* Header Azul */}
      <header className="bg-slate-900/95 backdrop-blur-md border-b border-blue-500/30 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="relative w-14 h-14">
            <div className="absolute inset-0 w-14 h-14 bg-gradient-to-br from-blue-400 via-cyan-500 to-indigo-400 rounded-full opacity-30"></div>
            <div className="absolute inset-2 w-10 h-10 bg-gradient-to-br from-blue-400 via-cyan-500 to-indigo-400 rounded-full flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                <path d="M13 7 9 3 5 7l4 4"></path>
                <path d="m17 11 4 4-4 4-4-4"></path>
                <path d="m8 12 4 4 6-6-4-4Z"></path>
              </svg>
            </div>
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">iAgroSat</h1>
            <p className="text-cyan-300 text-sm">ANÁLISE SATELITAL INTELIGENTE</p>
          </div>
        </div>
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-cyan-400 rounded-full animate-pulse"></div>
            <span className="text-sm text-slate-300">BACKEND ATIVO</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-indigo-400 rounded-full animate-pulse"></div>
            <span className="text-sm text-slate-300">SENTINEL ATIVO</span>
          </div>
        </div>
      </header>

      {/* Conteúdo Principal */}
      <div className="flex flex-1 overflow-hidden">
        {/* Painel Lateral Azul */}
        <div className="w-80 bg-slate-900/95 backdrop-blur-md border-r border-blue-500/30 flex flex-col">
          <div className="p-6 flex-1 space-y-6">
            
            {/* Busca por Local */}
            <div>
              <h3 className="text-cyan-400 mb-3 flex items-center text-sm font-bold">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                  <circle cx="11" cy="11" r="8"/>
                  <path d="m21 21-4.35-4.35"/>
                </svg>
                BUSCAR LOCAL
              </h3>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="São Paulo, Rio de Janeiro, Brasília..."
                className="w-full px-4 py-3 bg-slate-800/80 text-white border border-blue-500/30 focus:border-cyan-400 focus:outline-none rounded-lg text-sm placeholder-slate-400"
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              />
              <button 
                onClick={handleSearch}
                className="w-full mt-3 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white py-3 font-bold text-sm rounded-lg transition-all"
              >
                BUSCAR & LOCALIZAR
              </button>
            </div>

            {/* Coordenadas Manuais */}
            <div>
              <h3 className="text-cyan-400 mb-3 flex items-center text-sm font-bold">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                  <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                  <circle cx="12" cy="10" r="3"/>
                </svg>
                COORDENADAS
              </h3>
              <div className="space-y-2">
                <input
                  type="number"
                  step="any"
                  placeholder="Latitude (ex: -23.5505)"
                  value={currentCoordinates.lat}
                  onChange={(e) => setCurrentCoordinates(prev => ({ ...prev, lat: parseFloat(e.target.value) || 0 }))}
                  className="w-full px-4 py-2 bg-slate-800/80 text-white border border-blue-500/30 focus:border-cyan-400 focus:outline-none rounded-lg text-sm placeholder-slate-400"
                />
                <input
                  type="number"
                  step="any"
                  placeholder="Longitude (ex: -46.6333)"
                  value={currentCoordinates.lng}
                  onChange={(e) => setCurrentCoordinates(prev => ({ ...prev, lng: parseFloat(e.target.value) || 0 }))}
                  className="w-full px-4 py-2 bg-slate-800/80 text-white border border-blue-500/30 focus:border-cyan-400 focus:outline-none rounded-lg text-sm placeholder-slate-400"
                />
              </div>
              <button 
                onClick={() => console.log("Indo para coordenadas:", currentCoordinates)}
                className="w-full mt-3 bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-700 hover:to-cyan-700 text-white py-3 font-bold text-sm rounded-lg transition-all"
              >
                IR PARA COORDENADAS
              </button>
            </div>

            {/* Seleção Ativa */}
            <div>
              <h3 className="text-cyan-400 mb-3 flex items-center text-sm font-bold">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                  <circle cx="12" cy="12" r="3"/>
                  <path d="M12 1v6m0 12v6"/>
                </svg>
                SELEÇÃO ATIVA
              </h3>
              <div className="bg-slate-800/60 border border-blue-500/30 rounded-lg p-4 space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-slate-300 text-sm">Pontos:</span>
                  <span className="text-cyan-400 text-sm font-bold">{selectedArea.points}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-300 text-sm">Área:</span>
                  <span className="text-cyan-400 text-sm font-bold">{selectedArea.area.toFixed(2)} km²</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-300 text-sm">Status:</span>
                  <span className="text-cyan-400 text-sm font-bold">SELECIONADO</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-300 text-sm">Ferramenta:</span>
                  <span className="text-cyan-400 text-sm font-bold">{selectedTool?.toUpperCase() || 'NENHUMA'}</span>
                </div>
              </div>
            </div>

            {/* Botões de Ação */}
            <div className="space-y-3">
              <button 
                onClick={processAnalysis}
                className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white py-4 font-bold text-sm rounded-lg transition-all shadow-lg shadow-cyan-500/30"
              >
                PROCESSAR ANÁLISE
              </button>
              <button 
                onClick={clearSelection}
                className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white py-3 font-bold text-sm rounded-lg transition-all"
              >
                LIMPAR SELEÇÃO
              </button>
            </div>
          </div>
        </div>

        {/* Mapa */}
        <div className="flex-1 relative">
          <MapContainer
            onCoordinateSelect={(coords) => {
              setCurrentCoordinates({ lat: coords.lat, lng: coords.lon })
            }}
            onAreaSelect={(area) => {
              setSelectedArea({ points: 1, area: area.area ? area.area / 1000000 : 0.25 })
            }}
            onAnalysisStart={processAnalysis}
            onToolActivated={setSelectedTool}
          />
          
          {/* Ferramentas do Mapa */}
          <div className="absolute top-4 right-4 flex flex-col space-y-2 z-50">
            <button 
              onClick={() => setSelectedTool('area')}
              className={`w-12 h-12 flex items-center justify-center transition-all rounded-lg ${
                selectedTool === 'area' 
                  ? 'bg-gradient-to-br from-cyan-500 to-blue-500 shadow-lg' 
                  : 'bg-slate-900/90 hover:bg-slate-800/90 border border-blue-500/30'
              }`}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                <rect width="18" height="18" x="3" y="3" rx="2"/>
              </svg>
            </button>
            
            <button 
              onClick={() => setSelectedTool('point')}
              className={`w-12 h-12 flex items-center justify-center transition-all rounded-lg ${
                selectedTool === 'point' 
                  ? 'bg-gradient-to-br from-cyan-500 to-blue-500 shadow-lg' 
                  : 'bg-slate-900/90 hover:bg-slate-800/90 border border-blue-500/30'
              }`}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                <circle cx="12" cy="10" r="3"/>
              </svg>
            </button>
            
            <button 
              onClick={clearSelection}
              className="w-12 h-12 bg-red-600/90 hover:bg-red-600 flex items-center justify-center transition-all rounded-lg"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                <path d="M3 6h18"/>
                <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/>
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-slate-900/95 backdrop-blur-md border-t border-blue-500/30 px-6 py-4 flex items-center justify-center">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-cyan-400 to-blue-400 rounded-full flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                <path d="M13 7 9 3 5 7l4 4"></path>
                <path d="m17 11 4 4-4 4-4-4"></path>
                <path d="m8 12 4 4 6-6-4-4Z"></path>
              </svg>
            </div>
            <span className="text-slate-300 text-sm font-bold">iAgroSat</span>
          </div>
          <div className="text-slate-400 text-xs">CNPJ: 61.579.333/0001-00</div>
          <div className="text-slate-400 text-xs">Powered by SENTINEL-2</div>
          <div className="text-slate-400 text-xs">© 2024 Todos os Direitos Reservados</div>
        </div>
      </footer>
    </div>
  )
}