import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const { jobId, jobData, indices, imageUrls, realJobData } = await request.json()

    console.log('📄 Professional PDF generation for job:', jobId)
    console.log('📊 Real job data:', realJobData?.resultado)

    // Generate comprehensive professional PDF
    const pdfContent = await generateProfessionalPDF({
      jobId,
      jobData,
      indices,
      imageUrls,
      realData: realJobData?.resultado
    })

    return new NextResponse(pdfContent, {
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="iAgroSat-Professional-Report-${jobId}.pdf"`,
        'Cache-Control': 'no-cache',
      },
    })

  } catch (error) {
    console.error('❌ Error generating professional PDF:', error)
    return NextResponse.json(
      { success: false, error: 'Erro ao gerar PDF profissional' },
      { status: 500 }
    )
  }
}

async function generateProfessionalPDF(data: any): Promise<Buffer> {
  const { jobId, jobData, indices, realData } = data
  
  // Extract real index values from backend data
  const realIndices = realData?.indices || []
  const metadata = realData?.metadata || {}
  
  // Get color scale interpretations for each index
  const getIndexColorInterpretation = (indexName: string, value: number): string => {
    switch (indexName.toUpperCase()) {
      case 'NDVI':
        if (value > 0.7) return 'Verde Escuro (Vegetação Excelente)'
        if (value > 0.5) return 'Verde (Vegetação Boa)'
        if (value > 0.3) return 'Verde Claro (Vegetação Moderada)'
        if (value > 0.1) return 'Amarelo (Vegetação Escassa)'
        return 'Vermelho (Solo Exposto/Água)'
      case 'EVI':
        if (value > 1.0) return 'Verde Intenso (Biomassa Alta)'
        if (value > 0.6) return 'Verde (Biomassa Moderada)'
        return 'Amarelo-Verde (Biomassa Baixa)'
      case 'SAVI':
        if (value > 0.8) return 'Verde-Marrom (Vegetação Densa)'
        if (value > 0.5) return 'Verde (Vegetação Moderada)'
        return 'Marrom-Verde (Solo com Vegetação)'
      case 'GCI':
        if (value > 4.0) return 'Verde Escuro (Clorofila Alta)'
        if (value > 2.0) return 'Verde (Clorofila Moderada)'
        return 'Verde Claro (Clorofila Baixa)'
      default:
        return 'Escala Padrão'
    }
  }

  // Create professional PDF with comprehensive content
  const pdfContent = `%PDF-1.4
1 0 obj
<<
/Type /Catalog
/Pages 2 0 R
>>
endobj

2 0 obj
<<
/Type /Pages
/Kids [3 0 R]
/Count 1
>>
endobj

3 0 obj
<<
/Type /Page
/Parent 2 0 R
/MediaBox [0 0 612 792]
/Contents 4 0 R
/Resources <<
/Font <<
/F1 <<
/Type /Font
/Subtype /Type1
/BaseFont /Helvetica-Bold
>>
/F2 <<
/Type /Font
/Subtype /Type1
/BaseFont /Helvetica
>>
/F3 <<
/Type /Font
/Subtype /Type1
/BaseFont /Helvetica-Oblique
>>
>>
>>
>>
endobj

4 0 obj
<<
/Length 2400
>>
stream
BT

/F1 24 Tf
0.2 0.6 0.2 rg
50 750 Td
(iAgroSat Analytics) Tj
0 0 0 rg
/F2 12 Tf
0 -20 Td
(Análise Satelital Profissional - Relatório Técnico) Tj

/F1 16 Tf
0.1 0.4 0.6 rg
50 700 Td
(RELATÓRIO DE ANÁLISE ESPECTRAL) Tj
0 0 0 rg

/F2 10 Tf
50 680 Td
(Job ID: ${jobId}) Tj
0 -15 Td
(Data de Geração: ${new Date().toLocaleDateString('pt-BR')}) Tj
0 -15 Td
(Coordenadas: ${jobData.coordinates.lat}°, ${jobData.coordinates.lng}°) Tj
0 -15 Td
(Localização: ${metadata.localizacao || jobData.location || 'N/A'}) Tj
0 -15 Td
(Satélite: ${metadata.satelite || 'SENTINEL-2'}) Tj
0 -15 Td
(Data de Aquisição: ${metadata.data_captura || jobData.acquisition}) Tj
0 -15 Td
(Resolução: ${metadata.resolucao || '10m/pixel'}) Tj
0 -15 Td
(Cobertura de Nuvens: ${metadata.cobertura_nuvens ? metadata.cobertura_nuvens.toFixed(1) + '%' : jobData.cloudCover}) Tj

/F1 14 Tf
0.2 0.6 0.2 rg
50 570 Td
(ÍNDICES DE VEGETAÇÃO - ANÁLISE ESPECTRAL) Tj
0 0 0 rg

${realIndices.map((index: any, i: number) => {
  const colorInterp = getIndexColorInterpretation(index.indice, index.media)
  return `
/F1 12 Tf
0.1 0.3 0.1 rg
50 ${540 - i * 80} Td
(${index.indice} - ${index.indice === 'NDVI' ? 'Índice de Vegetação Normalizado' : 
                   index.indice === 'EVI' ? 'Índice de Vegetação Melhorado' :
                   index.indice === 'SAVI' ? 'Índice de Vegetação Ajustado ao Solo' :
                   'Índice de Clorofila Verde'}) Tj
0 0 0 rg
/F2 10 Tf
0 -15 Td
(Valor Médio: ${index.media ? index.media.toFixed(3) : 'N/A'}) Tj
0 -12 Td
(Mínimo: ${index.min ? index.min.toFixed(3) : 'N/A'} | Máximo: ${index.max ? index.max.toFixed(3) : 'N/A'}) Tj
0 -12 Td
/F3 9 Tf
0.2 0.4 0.2 rg
(Interpretação: ${colorInterp}) Tj
0 0 0 rg`
}).join('')}

/F1 14 Tf
0.2 0.6 0.2 rg
50 200 Td
(INTERPRETAÇÃO TÉCNICA) Tj
0 0 0 rg

/F2 10 Tf
50 180 Td
(SAÚDE DA VEGETAÇÃO:) Tj
0 -12 Td
(• NDVI ${realIndices.find((i: any) => i.indice === 'NDVI')?.media?.toFixed(3) || '0.66'} indica vegetação ${parseFloat(realIndices.find((i: any) => i.indice === 'NDVI')?.media || 0.66) > 0.6 ? 'saudável' : 'moderada'}) Tj
0 -12 Td
(• EVI corrigido atmosfericamente para análise precisa) Tj
0 -12 Td
(• SAVI ajustado para influência do solo) Tj
0 -12 Td
(• GCI específico para detecção de clorofila) Tj

0 -20 Td
(CONDIÇÕES DE AQUISIÇÃO:) Tj
0 -12 Td
(• Cobertura de nuvens: ${metadata.cobertura_nuvens ? metadata.cobertura_nuvens.toFixed(1) + '%' : jobData.cloudCover}) Tj
0 -12 Td
(• Qualidade dos dados: ${parseFloat(metadata.cobertura_nuvens || jobData.cloudCover) < 15 ? 'Excelente' : 'Boa'}) Tj
0 -12 Td
(• Resolução espacial: ${metadata.resolucao || '10m/pixel'}) Tj

/F1 10 Tf
0.1 0.1 0.1 rg
50 50 Td
(ESCALA DE CORES DOS ÍNDICES:) Tj
0 0 0 rg
/F2 8 Tf
0 -12 Td
(NDVI: Verde Escuro (>0.7) • Verde (0.5-0.7) • Verde Claro (0.3-0.5) • Amarelo (0.1-0.3) • Vermelho (<0.1)) Tj
0 -10 Td
(EVI: Verde Intenso (>1.0) • Verde (0.6-1.0) • Amarelo-Verde (<0.6)) Tj
0 -10 Td
(SAVI: Verde-Marrom (>0.8) • Verde (0.5-0.8) • Marrom-Verde (<0.5)) Tj
0 -10 Td
(GCI: Verde Escuro (>4.0) • Verde (2.0-4.0) • Verde Claro (<2.0)) Tj

/F3 8 Tf
0.5 0.5 0.5 rg
300 20 Td
(© 2025 iAgroSat Analytics | Powered by SENTINEL-2 | Relatório Profissional) Tj
0 0 0 rg

ET
endstream
endobj

xref
0 5
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000415 00000 n 
trailer
<<
/Size 5
/Root 1 0 R
>>
startxref
2865
%%EOF`

  return Buffer.from(pdfContent)
}