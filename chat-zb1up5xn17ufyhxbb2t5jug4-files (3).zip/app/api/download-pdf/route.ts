import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const jobId = searchParams.get('job_id')
    
    if (!jobId) {
      return NextResponse.json({ error: 'Job ID é obrigatório' }, { status: 400 })
    }

    console.log('📥 PDF download requested for job:', jobId)

    // In a real implementation, this would fetch the actual PDF file
    // For now, we'll create a mock PDF response
    
    const pdfContent = createMockPDF(jobId)
    
    return new NextResponse(pdfContent, {
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="iAgroSat-${jobId}-report.pdf"`,
        'Cache-Control': 'no-cache',
      },
    })

  } catch (error) {
    console.error('❌ Error downloading PDF:', error)
    return NextResponse.json(
      { error: 'Erro ao baixar PDF' },
      { status: 500 }
    )
  }
}

function createMockPDF(jobId: string): Buffer {
  // This is a minimal PDF structure - in production use a proper PDF library
  const pdfHeader = `%PDF-1.4
1 0 obj
<<
/Type /Catalog
/Pages 2 0 R
>>
endobj

2 0 obj
<<
/Type /Pages
/Kids [3 0 R]
/Count 1
>>
endobj

3 0 obj
<<
/Type /Page
/Parent 2 0 R
/MediaBox [0 0 612 792]
/Contents 4 0 R
/Resources <<
/Font <<
/F1 <<
/Type /Font
/Subtype /Type1
/BaseFont /Helvetica
>>
>>
>>
>>
endobj

4 0 obj
<<
/Length 200
>>
stream
BT
/F1 12 Tf
50 750 Td
(iAgroSat - Relatório de Análise Satelital) Tj
0 -20 Td
(Job ID: ${jobId}) Tj
0 -20 Td
(Dados de análise SENTINEL-2) Tj
0 -20 Td
(Relatório gerado em: ${new Date().toLocaleDateString('pt-BR')}) Tj
ET
endstream
endobj

xref
0 5
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000315 00000 n 
trailer
<<
/Size 5
/Root 1 0 R
>>
startxref
565
%%EOF`

  return Buffer.from(pdfHeader)
}