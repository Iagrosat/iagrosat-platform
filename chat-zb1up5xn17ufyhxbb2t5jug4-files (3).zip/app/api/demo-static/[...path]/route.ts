import { NextRequest, NextResponse } from 'next/server'
import { readFileSync } from 'fs'
import { join } from 'path'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  try {
    const { path: pathArray } = await params
    const path = pathArray.join('/')
    console.log("Demo static file request", { path })

    // Serve demo images
    if (path.includes('demo')) {
      // Generate a simple colored rectangle as demo image
      const color = path.includes('ndvi') ? '#4CAF50' : 
                   path.includes('evi') ? '#8BC34A' : 
                   path.includes('savi') ? '#CDDC39' : 
                   path.includes('gci') ? '#FFEB3B' : '#2196F3'
      
      // Simple SVG as demo image
      const svg = `<svg width="400" height="300" xmlns="http://www.w3.org/2000/svg">
        <rect width="100%" height="100%" fill="${color}"/>
        <text x="50%" y="50%" text-anchor="middle" dy=".3em" font-family="Arial" font-size="24" fill="white">
          ${path.includes('ndvi') ? 'NDVI' : 
            path.includes('evi') ? 'EVI' : 
            path.includes('savi') ? 'SAVI' : 
            path.includes('gci') ? 'GCI' : 'RGB'} Demo
        </text>
      </svg>`
      
      return new NextResponse(svg, {
        headers: {
          'Content-Type': 'image/svg+xml',
          'Cache-Control': 'public, max-age=3600',
        },
      })
    }

    return new NextResponse('Demo file not found', { status: 404 })
  } catch (error) {
    console.error("Demo static error", error)
    return new NextResponse('Demo static error', { status: 500 })
  }
}