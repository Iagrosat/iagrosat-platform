import { NextRequest, NextResponse } from 'next/server'
import { AuthChecker } from '@/lib/auth-checker'
import { AuditLogger } from '@/lib/audit-logger'
import { Permission, UserRole } from '@/types/auth'

export async function GET(request: NextRequest) {
  try {
    // Check authentication and authorization
    const authResult = await AuthChecker.validateRequest(request)
    if (!authResult.isValid) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }

    // Only admins can view audit logs
    if (!authResult.permissions?.includes(Permission.VIEW_AUDIT_LOGS)) {
      console.warn(`🚨 Unauthorized audit log access - User: ${authResult.userId}`)
      return NextResponse.json(
        { error: 'Insufficient permissions to view audit logs' },
        { status: 403 }
      )
    }

    const { searchParams } = new URL(request.url)
    const limit = parseInt(searchParams.get('limit') || '100')
    const userId = searchParams.get('userId')
    const resource = searchParams.get('resource')

    let logs
    if (userId) {
      logs = AuditLogger.getUserLogs(userId, limit)
    } else if (resource) {
      logs = AuditLogger.getResourceLogs(resource, limit)
    } else {
      logs = AuditLogger.getRecentLogs(limit)
    }

    // Log the audit log access
    AuditLogger.log({
      userId: authResult.userId!,
      userName: 'Admin User',
      action: 'AUDIT_LOGS_VIEWED',
      resource: 'AUDIT',
      details: { limit, userId, resource },
      ip: authResult.ip
    })

    return NextResponse.json({
      logs,
      total: logs.length,
      timestamp: new Date().toISOString()
    })

  } catch (error) {
    console.error('❌ Audit logs fetch failed:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}