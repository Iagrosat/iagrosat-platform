'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { MapContainer } from '@/components/map-container'

export default function Platform() {
  const [searchQuery, setSearchQuery] = useState('')
  const [latInput, setLatInput] = useState('')
  const [lonInput, setLonInput] = useState('')
  const [geoJsonInput, setGeoJsonInput] = useState('')
  const [currentCoordinates, setCurrentCoordinates] = useState({ lat: 0, lng: 0 })
  const [selectedTool, setSelectedTool] = useState<string | null>(null)
  const [selectedArea, setSelectedArea] = useState({ area: 0.25, points: 0 })
  const [activeDrawingTool, setActiveDrawingTool] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleSearch = async () => {
    const query = searchQuery.trim()
    if (!query) return

    console.log("🔍 Buscando por:", query)
    
    try {
      // Detecta coordenadas (lat,lng)
      const coordMatch = query.match(/(-?\d+\.?\d*),?\s*(-?\d+\.?\d*)/)
      if (coordMatch) {
        const lat = parseFloat(coordMatch[1])
        const lng = parseFloat(coordMatch[2])
        console.log("📍 Coordenadas detectadas:", lat, lng)
        setCurrentCoordinates({ lat, lng })
        
        // Chama função do mapa
        if (typeof window !== 'undefined' && (window as any).mapFunctions) {
          (window as any).mapFunctions.updateCoordinates(lat, lng)
        }
        return
      }
      
      // Usa função de busca do mapa
      if (typeof window !== 'undefined' && (window as any).mapFunctions) {
        const found = await (window as any).mapFunctions.search(query)
        if (found) {
          console.log("🌍 Local encontrado via mapa")
        }
      } else {
        // Fallback para busca direta
        const geocodeUrl = `https://geocode-api.arcgis.com/arcgis/rest/services/World/GeocodeServer/findAddressCandidates?singleLine=${encodeURIComponent(query)}&maxLocations=1&outFields=*&f=json`
        
        const response = await fetch(geocodeUrl)
        const data = await response.json()
        
        if (data.candidates && data.candidates.length > 0) {
          const result = data.candidates[0]
          const lat = result.location.y
          const lng = result.location.x
          
          console.log("🌍 Local encontrado:", result.address, "em", lat, lng)
          setCurrentCoordinates({ lat, lng })
        } else {
          alert('Local não encontrado. Tente outro nome.')
        }
      }
    } catch (error) {
      console.error('Erro na busca:', error)
      alert('Erro na busca. Tente novamente.')
    }
  }

  const handleUnifiedSearch = async () => {
    if (!searchQuery.trim()) return

    console.log("🔍 Busca unificada:", searchQuery)
    
    // Detectar se é coordenadas (formato: -23.5505,-46.6333 ou -23.5505 -46.6333)
    const coordPattern = /^-?\d+\.?\d*[,\s]-?\d+\.?\d*$/
    const isCoordinates = coordPattern.test(searchQuery.trim())
    
    if (isCoordinates) {
      // Processar como coordenadas
      const coords = searchQuery.trim().replace(/[,\s]+/g, ',').split(',')
      const lat = parseFloat(coords[0])
      const lon = parseFloat(coords[1])
      
      if (!isNaN(lat) && !isNaN(lon) && lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180) {
        console.log("📍 Coordenadas detectadas:", lat, lon)
        
        try {
          if (typeof window !== 'undefined' && (window as any).mapFunctions) {
            (window as any).mapFunctions.updateCoordinates(lat, lon)
            setCurrentCoordinates({ lat, lng: lon })
            setSearchQuery('') // Clear after success
            console.log("✅ Coordenadas aplicadas com pin no mapa")
          }
        } catch (error) {
          console.error('❌ Erro ao navegar para coordenadas:', error)
          alert('Erro ao navegar para as coordenadas.')
        }
      } else {
        alert('Coordenadas inválidas. Use formato: -23.5505,-46.6333')
      }
    } else {
      // Processar como busca de local
      console.log("🏙️ Busca de local detectada:", searchQuery)
      
      try {
        if (typeof window !== 'undefined' && (window as any).mapFunctions) {
          const success = await (window as any).mapFunctions.search(searchQuery)
          
          if (success) {
            console.log("✅ Local encontrado e pin adicionado")
            setSearchQuery('') // Clear after success
          } else {
            console.log("❌ Local não encontrado")
          }
        } else {
          console.log("⚠️ Mapa não está carregado ainda")
          alert('Aguarde o mapa carregar antes de buscar.')
        }
      } catch (error) {
        console.error('❌ Erro na busca:', error)
        alert('Erro na busca. Tente novamente.')
      }
    }
  }

  const searchLocation = async () => {
    if (!searchQuery.trim()) return

    console.log("🔍 Iniciando busca por:", searchQuery)
    
    try {
      if (typeof window !== 'undefined' && (window as any).mapFunctions) {
        const success = await (window as any).mapFunctions.search(searchQuery)
        
        if (success) {
          console.log("✅ Busca realizada com sucesso")
          setSearchQuery('') // Clear search after success
          // Map function already handles pin placement and coordinate updates
        } else {
          console.log("❌ Busca não encontrou resultados")
        }
      } else {
        console.log("⚠️ Mapa não está carregado ainda")
        alert('Aguarde o mapa carregar antes de buscar.')
      }
    } catch (error) {
      console.error('❌ Erro na busca:', error)
      alert('Erro na busca. Tente novamente.')
    }
  }

  const processAnalysis = async () => {
    console.log('🔍 Verificando coordenadas disponíveis...')
    console.log('currentCoordinates:', currentCoordinates)
    console.log('latInput:', latInput, 'lonInput:', lonInput)
    
    // Use coordinates from inputs if currentCoordinates is not set
    let finalLat = currentCoordinates.lat
    let finalLng = currentCoordinates.lng
    
    // Se não há coordenadas no state, tenta usar os inputs
    if ((!finalLat || !finalLng) && latInput && lonInput) {
      finalLat = parseFloat(latInput)
      finalLng = parseFloat(lonInput)
      
      console.log('📝 Usando coordenadas dos inputs:', finalLat, finalLng)
      
      // Validate coordinates
      if (isNaN(finalLat) || isNaN(finalLng)) {
        alert('❌ Coordenadas inválidas nos campos de input. Verifique os valores.')
        return
      }
      
      if (finalLat < -90 || finalLat > 90 || finalLng < -180 || finalLng > 180) {
        alert('❌ Coordenadas fora do alcance válido (-90 a 90 para latitude, -180 a 180 para longitude).')
        return
      }
      
      // Update current coordinates
      setCurrentCoordinates({ lat: finalLat, lng: finalLng })
    }
    
    // Final validation
    if (!finalLat || !finalLng || isNaN(finalLat) || isNaN(finalLng)) {
      alert('❌ Por favor, selecione uma localização no mapa OU digite coordenadas válidas nos campos Latitude/Longitude.')
      return
    }

    console.log('🚀 Iniciando análise real com backend:', { lat: finalLat, lng: finalLng })
    
    try {
      // Create real job with backend
      const response = await fetch(`/api/full-report?lat=${finalLat}&lon=${finalLng}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          area_hectares: selectedArea.area > 0 ? selectedArea.area * 100 : 25, // Default 25 hectares if no area selected
          timestamp: new Date().toISOString()
        })
      })

      if (response.ok) {
        const data = await response.json()
        console.log('✅ Análise criada com sucesso:', data)
        
        // Redirect to live processing with real job ID
        window.location.href = `/results/live-processing?job_id=${data.job_id}`
      } else {
        const error = await response.json()
        console.error('❌ Erro na criação da análise:', error)
        alert(`Erro: ${error.error || 'Falha na comunicação com o servidor'}`)
      }
    } catch (error) {
      console.error('❌ Erro na requisição:', error)
      alert('Erro na conexão com o servidor. Tente novamente.')
    }
  }

  const clearSelection = () => {
    setSelectedArea({ points: 0, area: 0 })
    setCurrentCoordinates({ lat: null, lng: null })
    setSelectedTool(null)
    console.log("🗑️ Seleção limpa")
  }

  // Helper function to get point count based on tool
  const getPointCount = () => {
    if (!selectedTool) return 0
    
    switch (selectedTool) {
      case 'point':
        return currentCoordinates.lat ? 1 : 0
      case 'rectangle':
        return currentCoordinates.lat ? 4 : 0
      case 'polygon':
        return selectedArea.points || 0
      default:
        return 0
    }
  }

  // Helper function to get tool name
  const getToolName = () => {
    if (!selectedTool) return 'NENHUMA'
    
    switch (selectedTool) {
      case 'point':
        return 'PIN'
      case 'rectangle':
        return 'RETÂNGULO'
      case 'polygon':
        return 'POLÍGONO'
      default:
        return 'NENHUMA'
    }
  }

  const goToCoordinates = () => {
    const lat = parseFloat(latInput)
    const lon = parseFloat(lonInput)

    if (isNaN(lat) || isNaN(lon)) {
      alert('Por favor, insira coordenadas válidas.')
      return
    }

    if (lat < -90 || lat > 90 || lon < -180 || lon > 180) {
      alert('Coordenadas fora do alcance válido.')
      return
    }

    console.log("🎯 Indo para coordenadas:", lat, lon)
    
    try {
      if (typeof window !== 'undefined' && (window as any).mapFunctions) {
        (window as any).mapFunctions.updateCoordinates(lat, lon)
        
        // Update current coordinates state
        setCurrentCoordinates({ lat, lng: lon })
        
        console.log("✅ Coordenadas atualizadas com pin no mapa")
      } else {
        console.log("⚠️ Mapa não está carregado ainda")
        alert('Aguarde o mapa carregar antes de navegar.')
      }
    } catch (error) {
      console.error('❌ Erro ao navegar para coordenadas:', error)
      alert('Erro ao navegar. Tente novamente.')
    }
  }

  const processGeoJson = () => {
    if (!geoJsonInput.trim()) return
    
    try {
      const geojson = JSON.parse(geoJsonInput)
      console.log("🗺️ Processing GeoJSON:", geojson)
      
      // Validate GeoJSON structure
      if (!geojson.type || (!geojson.coordinates && !geojson.geometry)) {
        alert('❌ GeoJSON inválido. Verifique a estrutura.')
        return
      }
      
      // Extract coordinates based on GeoJSON type
      let lat, lon
      if (geojson.type === 'Point') {
        lon = geojson.coordinates[0]
        lat = geojson.coordinates[1]
      } else if (geojson.type === 'Polygon') {
        // Use first coordinate of first ring as center
        const firstRing = geojson.coordinates[0]
        lon = firstRing[0][0]
        lat = firstRing[0][1]
      } else if (geojson.geometry) {
        // Handle Feature format
        if (geojson.geometry.type === 'Point') {
          lon = geojson.geometry.coordinates[0]
          lat = geojson.geometry.coordinates[1]
        } else if (geojson.geometry.type === 'Polygon') {
          const firstRing = geojson.geometry.coordinates[0]
          lon = firstRing[0][0]
          lat = firstRing[0][1]
        }
      }
      
      if (lat && lon) {
        setCurrentCoordinates({ lat, lng: lon })
        setLatInput(lat.toString())
        setLonInput(lon.toString())
        
        // Update map
        if (typeof window !== 'undefined' && (window as any).mapFunctions) {
          (window as any).mapFunctions.updateCoordinates(lat, lon)
        }
        
        console.log("✅ GeoJSON processado com sucesso:", lat, lon)
        alert('✅ GeoJSON processado com sucesso!')
      } else {
        alert('❌ Não foi possível extrair coordenadas do GeoJSON.')
      }
    } catch (error) {
      console.error('❌ GeoJSON parse error:', error)
      alert('❌ GeoJSON inválido. Verifique a sintaxe JSON.')
    }
  }

  return (
    <div className="h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white relative overflow-hidden">
      {/* Header */}
      <header className="relative z-10 bg-slate-900/95 backdrop-blur-md border-b border-emerald-500/30 px-6 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="relative">
              <div className="w-12 h-12 bg-gradient-to-br from-emerald-400 to-amber-400 rounded-full flex items-center justify-center animate-spin" style={{ animationDuration: '20s' }}>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                  <path d="M13 7 9 3 5 7l4 4"></path>
                  <path d="m17 11 4 4-4 4-4-4"></path>
                  <path d="m8 12 4 4 6-6-4-4Z"></path>
                  <path d="m16 8 3-3"></path>
                  <path d="M9 21a6 6 0 0 0-6-6"></path>
                </svg>
              </div>
            </div>
            <div className="flex flex-col">
              <h1 className="text-xl font-bold text-white">iAgroSat</h1>
              <p className="text-emerald-400 text-xs font-semibold">ANÁLISE SATELITAL AVANÇADA</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-400">
                <path d="M20 6 9 17l-5-5"/>
              </svg>
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-green-400 font-bold text-xs">BACKEND LIVE</span>
            </div>
            <div className="flex items-center space-x-2">
              <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-amber-400">
                <path d="M13 7 9 3 5 7l4 4"></path>
                <path d="m17 11 4 4-4 4-4-4"></path>
                <path d="m8 12 4 4 6-6-4-4Z"></path>
                <path d="m16 8 3-3"></path>
                <path d="M9 21a6 6 0 0 0-6-6"></path>
              </svg>
              <div className="w-2 h-2 bg-amber-500 rounded-full animate-pulse"></div>
              <span className="text-amber-400 font-bold text-xs">SENTINEL ATIVO</span>
            </div>
          </div>
        </div>
      </header>

      {/* Conteúdo Principal */}
      <div className="flex flex-1 h-[calc(100vh-120px)]">
        {/* Painel Lateral - EVENLY SPACED */}
        <div className="w-64 bg-slate-900/95 backdrop-blur-md border-r border-emerald-500/30 flex flex-col">
          {/* Conteúdo - EVENLY DISTRIBUTED */}
          <div className="p-3 flex-1 flex flex-col justify-between">
            <div className="space-y-4">
              {/* Busca Local */}
              <div>
                <h3 className="text-emerald-400 mb-2 flex items-center text-xs font-bold">
                  <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                    <circle cx="11" cy="11" r="8"/>
                    <path d="M21 21l-4.35-4.35"/>
                  </svg>
                  BUSCA LOCAL
                </h3>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Cidade ou CEP"
                  className="w-full bg-slate-800/60 border border-emerald-500/30 rounded px-2 py-1.5 text-white placeholder-slate-400 text-xs focus:outline-none focus:border-emerald-400"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      searchLocation()
                    }
                  }}
                />
              </div>

              {/* Coordenadas */}
              <div>
                <h3 className="text-emerald-400 mb-2 flex items-center text-xs font-bold">
                  <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                    <circle cx="12" cy="12" r="3"/>
                    <path d="M12 1v6m0 12v6"/>
                  </svg>
                  COORDENADAS
                </h3>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-xs text-slate-400 block mb-1">Lat</label>
                    <input
                      type="number"
                      value={latInput}
                      onChange={(e) => {
                        setLatInput(e.target.value)
                        const lat = parseFloat(e.target.value)
                        const lon = parseFloat(lonInput)
                        if (!isNaN(lat) && !isNaN(lon) && lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180) {
                          setCurrentCoordinates({ lat, lng: lon })
                          if (typeof window !== 'undefined' && (window as any).mapFunctions) {
                            (window as any).mapFunctions.updateCoordinates(lat, lon)
                          }
                        }
                      }}
                      placeholder="-23.5505"
                      step="any"
                      className="w-full bg-slate-800/60 border border-emerald-500/30 rounded px-2 py-1.5 text-white text-xs focus:outline-none focus:border-emerald-400"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-slate-400 block mb-1">Lon</label>
                    <input
                      type="number"
                      value={lonInput}
                      onChange={(e) => {
                        setLonInput(e.target.value)
                        const lat = parseFloat(latInput)
                        const lon = parseFloat(e.target.value)
                        if (!isNaN(lat) && !isNaN(lon) && lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180) {
                          setCurrentCoordinates({ lat, lng: lon })
                          if (typeof window !== 'undefined' && (window as any).mapFunctions) {
                            (window as any).mapFunctions.updateCoordinates(lat, lon)
                          }
                        }
                      }}
                      placeholder="-46.6333"
                      step="any"
                      className="w-full bg-slate-800/60 border border-emerald-500/30 rounded px-2 py-1.5 text-white text-xs focus:outline-none focus:border-emerald-400"
                    />
                  </div>
                </div>
              </div>

              {/* Botão Buscar */}
              <button 
                onClick={() => {
                  if (searchQuery.trim()) {
                    searchLocation()
                  } else if (latInput && lonInput) {
                    goToCoordinates()
                  } else {
                    alert('Digite um local OU coordenadas para localizar.')
                  }
                }}
                disabled={!searchQuery.trim() && (!latInput || !lonInput)}
                className="w-full bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-600 hover:via-teal-600 hover:to-cyan-600 disabled:from-slate-600 disabled:to-slate-700 text-white py-2 font-bold text-xs rounded transition-all transform hover:scale-105 shadow-lg shadow-emerald-500/40"
              >
                BUSCAR & LOCALIZAR
              </button>

              {/* GeoJSON */}
              <div>
                <h3 className="text-amber-400 mb-2 flex items-center text-xs font-bold">
                  <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                    <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/>
                    <polyline points="14,2 14,8 20,8"/>
                  </svg>
                  GEOJSON
                </h3>
                <textarea
                  placeholder='{"type": "Polygon", "coordinates": [...]}' 
                  className="w-full h-16 bg-slate-800/60 border border-amber-500/30 rounded px-2 py-1.5 text-white placeholder-slate-400 text-xs font-mono focus:outline-none focus:border-amber-400 resize-none"
                  value={geoJsonInput}
                  onChange={(e) => setGeoJsonInput(e.target.value)}
                />
                <div className="flex space-x-2 mt-2">
                  <button
                    onClick={processGeoJson}
                    disabled={!geoJsonInput.trim()}
                    className="flex-1 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 disabled:from-slate-600 disabled:to-slate-700 text-white py-1.5 px-3 font-bold text-xs rounded transition-all"
                  >
                    PROCESSAR
                  </button>
                  <button
                    onClick={() => setGeoJsonInput('')}
                    className="bg-slate-700 hover:bg-slate-600 text-white py-1.5 px-3 font-bold text-xs rounded transition-all"
                  >
                    LIMPAR
                  </button>
                </div>
              </div>

              {/* Seleção Ativa */}
              <div>
                <h3 className="text-emerald-400 mb-2 flex items-center text-xs font-bold">
                  <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                    <circle cx="12" cy="12" r="3"/>
                    <path d="M12 1v6m0 12v6"/>
                  </svg>
                  SELEÇÃO ATIVA
                </h3>
                <div className="bg-slate-800/60 border border-emerald-500/30 rounded p-3">
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div className="text-center">
                      <div className="text-slate-300 text-xs">Pontos:</div>
                      <div className="text-emerald-400 font-bold">{getPointCount()}</div>
                    </div>
                    <div className="text-center">
                      <div className="text-slate-300 text-xs">Área:</div>
                      <div className="text-emerald-400 font-bold">{selectedArea.area.toFixed(2)} km²</div>
                    </div>
                    <div className="text-center">
                      <div className="text-slate-300 text-xs">Ferramenta:</div>
                      <div className="text-emerald-400 font-bold text-xs">{getToolName()}</div>
                    </div>
                  </div>
                  <div className="text-center mt-2">
                    <div className="text-slate-300 text-xs">Localização:</div>
                    <div className="text-amber-400 font-bold text-xs">
                      {currentCoordinates.lat ? `${currentCoordinates.lat.toFixed(4)}, ${currentCoordinates.lng.toFixed(4)}` : 'Não definida'}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Botões - BOTTOM SECTION */}
            <div className="space-y-2 mt-6">
              <button 
                onClick={processAnalysis}
                disabled={false}
                className="w-full bg-gradient-to-r from-emerald-600 via-green-600 to-teal-600 hover:from-emerald-700 hover:via-green-700 hover:to-teal-700 disabled:from-slate-600 disabled:to-slate-700 text-white py-2.5 px-3 font-bold text-xs rounded transition-all shadow-lg shadow-emerald-500/30"
              >
                INICIAR ANÁLISE ESPECTRAL
              </button>
              <button 
                onClick={() => {
                  if (typeof window !== 'undefined' && (window as any).mapFunctions) {
                    (window as any).mapFunctions.clearSelection()
                  }
                  clearSelection()
                  setSearchQuery('')
                  setLatInput('')
                  setLonInput('')
                }}
                className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white py-2.5 px-3 font-bold text-xs rounded transition-all"
              >
                LIMPAR
              </button>
            </div>
          </div>
        </div>

        {/* Mapa */}
        <div className="flex-1 relative overflow-hidden">
          <MapContainer
            onCoordinateSelect={(coords) => {
              console.log("📍 Coordenadas selecionadas:", coords)
              setCurrentCoordinates({ lat: coords.lat, lng: coords.lon })
            }}
            onAreaSelect={(area) => {
              console.log("📐 Área selecionada:", area)
              if (area && area.area) {
                const areaKm2 = area.area / 1000000 // Convert from m² to km²
                setSelectedArea({ 
                  points: area.points || 1, 
                  area: areaKm2 
                })
              }
            }}
            onAnalysisStart={processAnalysis}
            onToolActivated={(tool) => {
              console.log("🛠️ Ferramenta ativada:", tool)
              setSelectedTool(tool)
            }}
          />
          
          {/* Ferramentas de Desenho - STUCK TO TOP RIGHT EDGE */}
          <div className="absolute top-0 right-0 z-40 flex flex-col">
            <button
              onClick={() => {
                console.log("🤚 Pan tool activated")
                setActiveDrawingTool('pan')
                if (typeof window !== 'undefined' && (window as any).mapFunctions) {
                  (window as any).mapFunctions.activatePanTool()
                }
              }}
              className={`w-10 h-10 bg-slate-900/90 hover:bg-slate-800/90 border-b border-r border-emerald-500/30 flex items-center justify-center text-white transition-all ${
                activeDrawingTool === 'pan' ? 'bg-emerald-600/80 border-emerald-400' : ''
              }`}
              title="Ferramenta de Navegação"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M9 9h6l-3-3z"/>
                <path d="m9 15 3-3 3 3"/>
                <path d="M12 3v18"/>
              </svg>
            </button>
            <button
              onClick={() => {
                console.log("📍 Point tool activated")
                setActiveDrawingTool('point')
                if (typeof window !== 'undefined' && (window as any).mapFunctions) {
                  (window as any).mapFunctions.activatePointTool()
                }
              }}
              className={`w-10 h-10 bg-slate-900/90 hover:bg-slate-800/90 border-b border-r border-emerald-500/30 flex items-center justify-center text-white transition-all ${
                activeDrawingTool === 'point' ? 'bg-emerald-600/80 border-emerald-400' : ''
              }`}
              title="Ferramenta de Pin"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/>
                <circle cx="12" cy="10" r="3"/>
              </svg>
            </button>
            <button
              onClick={() => {
                console.log("⬛ Rectangle tool activated")
                setActiveDrawingTool('rectangle')
                if (typeof window !== 'undefined' && (window as any).mapFunctions) {
                  (window as any).mapFunctions.activateAreaTool()
                }
              }}
              className={`w-10 h-10 bg-slate-900/90 hover:bg-slate-800/90 border-b border-r border-emerald-500/30 flex items-center justify-center text-white transition-all ${
                activeDrawingTool === 'rectangle' ? 'bg-emerald-600/80 border-emerald-400' : ''
              }`}
              title="Ferramenta de Retângulo"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect width="18" height="18" x="3" y="3" rx="2"/>
              </svg>
            </button>
            <button
              onClick={() => {
                console.log("🔺 Polygon tool activated")
                setActiveDrawingTool('polygon')
                if (typeof window !== 'undefined' && (window as any).mapFunctions) {
                  (window as any).mapFunctions.activatePolygonTool()
                }
              }}
              className={`w-10 h-10 bg-slate-900/90 hover:bg-slate-800/90 border-b border-r border-emerald-500/30 flex items-center justify-center text-white transition-all ${
                activeDrawingTool === 'polygon' ? 'bg-emerald-600/80 border-emerald-400' : ''
              }`}
              title="Ferramenta de Polígono"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
              </svg>
            </button>
            <button 
              onClick={() => {
                console.log("🗑️ Limpando seleção")
                setSelectedTool(null)
                if (typeof window !== 'undefined' && (window as any).mapFunctions) {
                  (window as any).mapFunctions.clearSelection()
                }
                clearSelection()
              }}
              className="w-10 h-10 bg-red-600/90 hover:bg-red-600 border-r border-emerald-500/30 flex items-center justify-center transition-all"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M3 6h18"/>
                <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/>
              </svg>
            </button>
          </div>

          {/* Controles de Zoom - STUCK TO RIGHT EDGE BELOW TOOLS */}
          <div className="absolute top-60 right-0 z-40 flex flex-col">
            <button 
              onClick={() => {
                console.log("🔍 Zoom in")
                if (typeof window !== 'undefined' && (window as any).mapFunctions) {
                  (window as any).mapFunctions.zoomIn()
                }
              }}
              className="w-10 h-10 bg-slate-900/90 hover:bg-slate-800/90 border-b border-r border-emerald-500/30 flex items-center justify-center text-white"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8"/>
                <line x1="11" y1="8" x2="11" y2="14"/>
                <line x1="8" y1="11" x2="14" y2="11"/>
              </svg>
            </button>
            <button 
              onClick={() => {
                console.log("🔍 Zoom out")
                if (typeof window !== 'undefined' && (window as any).mapFunctions) {
                  (window as any).mapFunctions.zoomOut()
                }
              }}
              className="w-10 h-10 bg-slate-900/90 hover:bg-slate-800/90 border-r border-emerald-500/30 flex items-center justify-center text-white"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8"/>
                <line x1="8" y1="11" x2="14" y2="11"/>
              </svg>
            </button>
          </div>

          {/* iAgroSat Credit - BOTTOM RIGHT CORNER */}
          <div className="absolute bottom-0 right-0 z-40">
            <div className="bg-slate-900/80 backdrop-blur-sm border-t border-l border-emerald-500/20 px-2 py-1">
              <span className="text-emerald-400 text-xs font-bold">© iAgroSat Ltda</span>
            </div>
          </div>
        </div>
      </div>

      {/* Footer - NO LOGO, SIMPLE */}
      <footer className="bg-slate-900/95 backdrop-blur-md border-t border-emerald-500/30 px-6 py-2 flex items-center justify-center">
        <div className="flex items-center space-x-4">
          <span className="text-slate-300 text-sm font-bold">iAgroSat</span>
          <div className="text-slate-400 text-xs">CNPJ: 61.579.333/0001-01</div>
          <div className="text-slate-400 text-xs">Powered by SENTINEL-2</div>
          <div className="text-slate-400 text-xs">© 2024 Todos os Direitos Reservados</div>
        </div>
      </footer>
    </div>
  )
}