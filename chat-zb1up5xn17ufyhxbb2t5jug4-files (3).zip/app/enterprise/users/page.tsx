"use client";

import { useAuth } from '@/contexts/auth-context';
import { LoginForm } from '@/components/enterprise/login-form';
import { EnterpriseLayout } from '@/components/enterprise/layout';
import { UserManagement } from '@/components/enterprise/user-management';
import { Permission } from '@/types/auth';

export default function EnterpriseUsersPage() {
  const { isAuthenticated, hasPermission, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-blue-500 rounded-xl flex items-center justify-center mx-auto mb-4">
            <div className="text-white font-bold text-2xl">iA</div>
          </div>
          <p className="text-slate-400">Carregando gerenciamento de usuários...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginForm />;
  }

  if (!hasPermission(Permission.VIEW_USERS)) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-red-500 rounded-xl flex items-center justify-center mx-auto mb-4">
            <div className="text-white font-bold text-2xl">⚠️</div>
          </div>
          <h1 className="text-2xl font-bold text-white mb-2">Acesso Negado</h1>
          <p className="text-slate-400">Você não tem permissão para gerenciar usuários.</p>
        </div>
      </div>
    );
  }

  return (
    <EnterpriseLayout>
      <UserManagement />
    </EnterpriseLayout>
  );
}