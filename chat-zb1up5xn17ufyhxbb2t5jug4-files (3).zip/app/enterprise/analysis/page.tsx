"use client";

import { AnalysisWorkspace } from '@/components/enterprise/analysis-workspace';
import { RouteGuard } from '@/components/enterprise/route-guard';
import { Permission } from '@/types/auth';

export default function EnterpriseAnalysisPage() {
  return (
    <RouteGuard requiredPermission={Permission.CREATE_ANALYSIS}>
      <AnalysisWorkspace />
    </RouteGuard>
  );
}