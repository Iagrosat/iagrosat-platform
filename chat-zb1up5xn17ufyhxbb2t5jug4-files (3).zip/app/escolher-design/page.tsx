'use client'

import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'

export default function EscolherDesign() {
  const router = useRouter()

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-white mb-4 font-fira tracking-wide">
            Escolha o Design do iAgroSat
          </h1>
          <p className="text-emerald-300 text-xl font-fira">
            Selecione a versão que mais te agrada para implementarmos
          </p>
        </div>

        {/* 4 VERSÕES ULTRA-DINÂMICAS */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {/* Versão Neon Cyber */}
          <div className="bg-gradient-to-br from-purple-900/30 to-pink-900/30 border border-pink-500/30 rounded-2xl p-8 backdrop-blur-sm">
            <div className="flex items-center mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-cyan-500 rounded-full flex items-center justify-center text-white font-bold text-xl mr-4">
                1
              </div>
              <h3 className="text-2xl font-bold text-pink-400 font-fira">Versão Neon Cyber</h3>
            </div>
            
            <div className="space-y-3 mb-6">
              <div className="flex items-center text-pink-300">
                <span className="mr-2">✅</span>
                <span className="font-fira">Design cyberpunk ultra-vibrante</span>
              </div>
              <div className="flex items-center text-pink-300">
                <span className="mr-2">✅</span>
                <span className="font-fira">Cores neon rosa/cyan/roxo</span>
              </div>
              <div className="flex items-center text-pink-300">
                <span className="mr-2">✅</span>
                <span className="font-fira">Efeitos de luz e blur avançados</span>
              </div>
              <div className="flex items-center text-pink-300">
                <span className="mr-2">✅</span>
                <span className="font-fira">Gradientes futuristas</span>
              </div>
              <div className="flex items-center text-pink-300">
                <span className="mr-2">✅</span>
                <span className="font-fira">Interface ultra-moderna</span>
              </div>
              <div className="flex items-center text-pink-300">
                <span className="mr-2">✅</span>
                <span className="font-fira">Ícone satelite mantido</span>
              </div>
            </div>
            
            <Button 
              onClick={() => router.push('/design-neon-cyber')}
              className="w-full bg-gradient-to-r from-pink-500 to-cyan-500 hover:from-pink-600 hover:to-cyan-600 text-white py-4 font-black tracking-widest transition-all duration-300 text-base font-fira transform hover:scale-105 rounded-xl shadow-2xl shadow-pink-500/30"
            >
              VER VERSÃO NEON CYBER
            </Button>
          </div>

          {/* Versão Holográfica */}
          <div className="bg-gradient-to-br from-indigo-900/30 to-violet-900/30 border border-violet-500/30 rounded-2xl p-8 backdrop-blur-sm">
            <div className="flex items-center mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-violet-500 to-blue-500 rounded-full flex items-center justify-center text-white font-bold text-xl mr-4">
                2
              </div>
              <h3 className="text-2xl font-bold text-violet-400 font-fira">Versão Holográfica</h3>
            </div>
            
            <div className="space-y-3 mb-6">
              <div className="flex items-center text-violet-300">
                <span className="mr-2">✅</span>
                <span className="font-fira">Design holográfico sci-fi</span>
              </div>
              <div className="flex items-center text-violet-300">
                <span className="mr-2">✅</span>
                <span className="font-fira">Cores azul/violeta/índigo</span>
              </div>
              <div className="flex items-center text-violet-300">
                <span className="mr-2">✅</span>
                <span className="font-fira">Efeitos de grade holográfica</span>
              </div>
              <div className="flex items-center text-violet-300">
                <span className="mr-2">✅</span>
                <span className="font-fira">Bordas luminosas</span>
              </div>
              <div className="flex items-center text-violet-300">
                <span className="mr-2">✅</span>
                <span className="font-fira">Interface espacial</span>
              </div>
              <div className="flex items-center text-violet-300">
                <span className="mr-2">✅</span>
                <span className="font-fira">Ícone satelite mantido</span>
              </div>
            </div>
            
            <Button 
              onClick={() => router.push('/design-holografico')}
              className="w-full bg-gradient-to-r from-violet-500 to-blue-500 hover:from-violet-600 hover:to-blue-600 text-white py-4 font-black tracking-widest transition-all duration-300 text-base font-fira transform hover:scale-105 rounded-xl shadow-2xl shadow-violet-500/30"
            >
              VER VERSÃO HOLOGRÁFICA
            </Button>
          </div>

          {/* Versão Matrix Hacker */}
          <div className="bg-gradient-to-br from-green-900/30 to-lime-900/30 border border-green-500/30 rounded-2xl p-8 backdrop-blur-sm">
            <div className="flex items-center mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-lime-500 rounded-full flex items-center justify-center text-black font-bold text-xl mr-4">
                3
              </div>
              <h3 className="text-2xl font-bold text-green-400 font-mono">Versão Matrix Hacker</h3>
            </div>
            
            <div className="space-y-3 mb-6">
              <div className="flex items-center text-green-300">
                <span className="mr-2">✅</span>
                <span className="font-mono">Design matrix/hacker terminal</span>
              </div>
              <div className="flex items-center text-green-300">
                <span className="mr-2">✅</span>
                <span className="font-mono">Cores verde/lima matrix</span>
              </div>
              <div className="flex items-center text-green-300">
                <span className="mr-2">✅</span>
                <span className="font-mono">Efeito de código matrix</span>
              </div>
              <div className="flex items-center text-green-300">
                <span className="mr-2">✅</span>
                <span className="font-mono">Typography monospace</span>
              </div>
              <div className="flex items-center text-green-300">
                <span className="mr-2">✅</span>
                <span className="font-mono">Interface de terminal</span>
              </div>
              <div className="flex items-center text-green-300">
                <span className="mr-2">✅</span>
                <span className="font-mono">Ícone satelite mantido</span>
              </div>
            </div>
            
            <Button 
              onClick={() => router.push('/design-matrix-hacker')}
              className="w-full bg-green-500 hover:bg-green-400 text-black py-4 font-black tracking-widest transition-all duration-300 text-base font-mono transform hover:scale-105 rounded-xl shadow-2xl shadow-green-500/30"
            >
              VER VERSÃO MATRIX HACKER
            </Button>
          </div>

          {/* Versão Militar Tactical */}
          <div className="bg-gradient-to-br from-amber-900/30 to-orange-900/30 border border-amber-500/30 rounded-2xl p-8 backdrop-blur-sm">
            <div className="flex items-center mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-orange-500 rounded-full flex items-center justify-center text-black font-bold text-xl mr-4">
                4
              </div>
              <h3 className="text-2xl font-bold text-amber-400 font-mono">Versão Militar Tactical</h3>
            </div>
            
            <div className="space-y-3 mb-6">
              <div className="flex items-center text-amber-300">
                <span className="mr-2">✅</span>
                <span className="font-mono">Design militar/HUD style</span>
              </div>
              <div className="flex items-center text-amber-300">
                <span className="mr-2">✅</span>
                <span className="font-mono">Cores âmbar/laranja/militar</span>
              </div>
              <div className="flex items-center text-amber-300">
                <span className="mr-2">✅</span>
                <span className="font-mono">Interface HUD tática</span>
              </div>
              <div className="flex items-center text-amber-300">
                <span className="mr-2">✅</span>
                <span className="font-mono">Grid militar de fundo</span>
              </div>
              <div className="flex items-center text-amber-300">
                <span className="mr-2">✅</span>
                <span className="font-mono">Relógio tempo real</span>
              </div>
              <div className="flex items-center text-amber-300">
                <span className="mr-2">✅</span>
                <span className="font-mono">Ícone satelite mantido</span>
              </div>
            </div>
            
            <Button 
              onClick={() => router.push('/design-militar-tactical')}
              className="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-black py-4 font-black tracking-widest transition-all duration-300 text-base font-mono transform hover:scale-105 rounded-xl shadow-2xl shadow-amber-500/30"
            >
              VER VERSÃO MILITAR TACTICAL
            </Button>
          </div>
        </div>

        {/* Instruções */}
        <div className="bg-slate-800/60 border border-emerald-500/30 rounded-2xl p-8 backdrop-blur-sm mb-8">
          <div className="flex items-center mb-6">
            <div className="w-8 h-8 bg-emerald-500 rounded-full flex items-center justify-center mr-4">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-emerald-400 font-fira">📋 Instruções</h2>
          </div>
          
          <div className="space-y-4 text-emerald-300 font-fira">
            <div>1. Clique em cada versão para visualizar o design completo</div>
            <div>2. Teste a busca digitando uma cidade (ex: São Paulo)</div>
            <div>3. Teste as coordenadas (ex: -23.5505, -46.6333)</div>
            <div>4. Experimente as ferramentas do mapa</div>
            <div>5. Escolha sua favorita e me avise qual implementar!</div>
          </div>
        </div>

        {/* Botão Voltar */}
        <div className="text-center">
          <Button 
            onClick={() => router.push('/')}
            className="bg-red-600 hover:bg-red-700 text-white px-8 py-4 font-bold rounded-xl transition-all duration-300 font-fira tracking-wider"
          >
            ← VOLTAR PARA SISTEMA ATUAL
          </Button>
        </div>
      </div>
    </div>
  )
}