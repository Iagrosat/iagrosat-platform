'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { ArrowLeft, Download, Terminal, Zap, Database, Cpu } from 'lucide-react'
import { useRouter } from 'next/navigation'

export default function ResultsDesign3() {
  const router = useRouter()
  const [activeIndex, setActiveIndex] = useState('ndvi')

  // Demo data with tech metrics
  const results = {
    metadata: {
      job_id: 'demo-tech-dashboard',
      satelite: 'Sentinel-2 L2A',
      data_captura: '2024-07-06T14:32:18Z',
      cobertura_nuvens: 12,
      coordenadas: [-46.6333, -23.5505],
      resolucao: '10m',
      localizacao: 'São Paulo, SP',
      area_hectares: 250.5,
      processing_time: 192, // seconds
      algorithm_version: 'v2.1.4',
      compute_units: 847
    },
    images: {
      rgb: '/api/demo-static/rgb.png',
      ndvi: '/api/demo-static/ndvi.png',
      evi: '/api/demo-static/evi.png',
      savi: '/api/demo-static/savi.png',
      gci: '/api/demo-static/gci.png'
    },
    indices: [
      { 
        indice: 'NDVI', 
        nome: 'Normalized Difference Vegetation Index',
        formula: '(NIR - Red) / (NIR + Red)',
        min: 0.15, 
        media: 0.68, 
        max: 0.92,
        std_dev: 0.18,
        pixel_count: 125643,
        processing_time: 45
      },
      { 
        indice: 'EVI', 
        nome: 'Enhanced Vegetation Index',
        formula: '2.5 * ((NIR - Red) / (NIR + 6*Red - 7.5*Blue + 1))',
        min: 0.08, 
        media: 0.52, 
        max: 0.89,
        std_dev: 0.21,
        pixel_count: 125643,
        processing_time: 52
      },
      { 
        indice: 'SAVI', 
        nome: 'Soil Adjusted Vegetation Index',
        formula: '((NIR - Red) / (NIR + Red + L)) * (1 + L)',
        min: 0.12, 
        media: 0.58, 
        max: 0.87,
        std_dev: 0.19,
        pixel_count: 125643,
        processing_time: 48
      },
      { 
        indice: 'GCI', 
        nome: 'Green Chlorophyll Index',
        formula: '(NIR / Green) - 1',
        min: 1.8, 
        media: 3.2, 
        max: 5.1,
        std_dev: 0.84,
        pixel_count: 125643,
        processing_time: 47
      }
    ]
  }

  const indexButtons = [
    { key: 'ndvi', label: 'NDVI', color: '#10b981', accent: '#22c55e' },
    { key: 'evi', label: 'EVI', color: '#3b82f6', accent: '#60a5fa' },
    { key: 'savi', label: 'SAVI', color: '#f59e0b', accent: '#fbbf24' },
    { key: 'gci', label: 'GCI', color: '#8b5cf6', accent: '#a78bfa' },
  ]

  const getCurrentIndexData = () => {
    return results.indices.find(idx => idx.indice.toLowerCase() === activeIndex) || results.indices[0]
  }

  const formatTime = (seconds: number) => {
    return `${Math.floor(seconds / 60)}:${(seconds % 60).toString().padStart(2, '0')}`
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-slate-900 to-gray-800 text-white">
      {/* Header Tech Style */}
      <header className="bg-black/40 backdrop-blur-md border-b border-cyan-500/30 px-6 py-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-4">
              <Button
                variant="outline"
                size="sm"
                onClick={() => router.push('/')}
                className="flex items-center gap-2 border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10"
              >
                <ArrowLeft className="h-4 w-4" />
                <Terminal className="h-4 w-4" />
                ./dashboard
              </Button>
              <div className="h-6 w-px bg-cyan-500/50"></div>
              <div>
                <h1 className="text-2xl font-bold text-transparent bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text">
                  SATELLITE.ANALYSIS_REPORT()
                </h1>
                <p className="text-cyan-400/80 font-mono text-sm">
                  Job: {results.metadata.job_id} | Version: {results.metadata.algorithm_version}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <div className="text-xs text-cyan-400/60 font-mono">STATUS</div>
                <div className="text-lg font-bold text-green-400">COMPLETED</div>
              </div>
              <Button className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700">
                <Download className="h-4 w-4 mr-2" />
                EXPORT
              </Button>
            </div>
          </div>
          
          {/* System Metrics */}
          <div className="grid grid-cols-6 gap-4">
            <div className="bg-gray-800/50 border border-green-500/30 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs text-green-400 font-mono">COMPUTE_TIME</div>
                  <div className="text-xl font-bold text-green-300">{formatTime(results.metadata.processing_time)}</div>
                </div>
                <Zap className="h-6 w-6 text-green-400" />
              </div>
            </div>
            <div className="bg-gray-800/50 border border-blue-500/30 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs text-blue-400 font-mono">PIXELS_PROC</div>
                  <div className="text-xl font-bold text-blue-300">{(125643/1000).toFixed(0)}K</div>
                </div>
                <Database className="h-6 w-6 text-blue-400" />
              </div>
            </div>
            <div className="bg-gray-800/50 border border-purple-500/30 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs text-purple-400 font-mono">RESOLUTION</div>
                  <div className="text-xl font-bold text-purple-300">{results.metadata.resolucao}</div>
                </div>
                <Cpu className="h-6 w-6 text-purple-400" />
              </div>
            </div>
            <div className="bg-gray-800/50 border border-yellow-500/30 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs text-yellow-400 font-mono">CLOUD_COVER</div>
                  <div className="text-xl font-bold text-yellow-300">{results.metadata.cobertura_nuvens}%</div>
                </div>
                <div className="text-yellow-400">☁</div>
              </div>
            </div>
            <div className="bg-gray-800/50 border border-cyan-500/30 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs text-cyan-400 font-mono">AREA_HA</div>
                  <div className="text-xl font-bold text-cyan-300">{results.metadata.area_hectares}</div>
                </div>
                <div className="text-cyan-400">📏</div>
              </div>
            </div>
            <div className="bg-gray-800/50 border border-red-500/30 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs text-red-400 font-mono">UNITS_USED</div>
                  <div className="text-xl font-bold text-red-300">{results.metadata.compute_units}</div>
                </div>
                <div className="text-red-400">⚡</div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-6 space-y-6">
        {/* RGB Image Terminal Style */}
        <div className="bg-gray-800/40 border border-gray-600/50 rounded-lg overflow-hidden">
          <div className="bg-gray-900/60 px-4 py-3 border-b border-gray-600/50 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="flex space-x-1">
                <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              </div>
              <span className="text-gray-300 font-mono text-sm">rgb_composite.sentinel2</span>
            </div>
            <div className="text-xs text-gray-400 font-mono">{results.metadata.data_captura}</div>
          </div>
          <div className="p-6">
            <div className="text-center">
              <img 
                src={results.images.rgb}
                alt="RGB Satellite Composite" 
                className="max-w-2xl mx-auto rounded-lg border border-gray-600/50"
              />
              <div className="mt-4 text-sm text-gray-400 font-mono">
                Sentinel-2 L2A RGB Composite | {results.metadata.localizacao}
              </div>
            </div>
          </div>
        </div>

        {/* Vegetation Indices Analysis */}
        <div className="bg-gray-800/40 border border-gray-600/50 rounded-lg overflow-hidden">
          <div className="bg-gray-900/60 px-4 py-3 border-b border-gray-600/50">
            <h2 className="text-lg font-bold text-cyan-400 font-mono">VEGETATION_INDICES.analyze()</h2>
            <p className="text-gray-400 text-sm font-mono">Advanced spectral analysis algorithms</p>
          </div>
          
          <div className="p-6">
            {/* Index Selection - Terminal Style */}
            <div className="flex flex-wrap gap-2 mb-6">
              {indexButtons.map((btn) => (
                <button
                  key={btn.key}
                  onClick={() => setActiveIndex(btn.key)}
                  className={`px-4 py-2 rounded font-mono text-sm transition-all border ${
                    activeIndex === btn.key 
                      ? `bg-gray-700 border-[${btn.color}] text-[${btn.accent}] shadow-lg`
                      : 'bg-gray-800/50 border-gray-600 text-gray-300 hover:border-gray-500'
                  }`}
                  style={activeIndex === btn.key ? {
                    borderColor: btn.color,
                    color: btn.accent,
                    boxShadow: `0 0 10px ${btn.color}40`
                  } : {}}
                >
                  {btn.label}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Algorithm Output */}
              <div className="lg:col-span-2">
                <div className="bg-black/40 border border-gray-600/50 rounded-lg overflow-hidden">
                  <div className="bg-gray-900/80 px-4 py-2 border-b border-gray-600/50 flex items-center justify-between">
                    <span className="text-gray-300 font-mono text-sm">
                      {getCurrentIndexData().indice.toLowerCase()}_output.tiff
                    </span>
                    <span className="text-xs text-gray-500 font-mono">
                      {getCurrentIndexData().processing_time}s
                    </span>
                  </div>
                  <div className="p-4">
                    <img
                      src={results.images[activeIndex]}
                      alt={`${getCurrentIndexData().indice} Analysis`}
                      className="w-full rounded border border-gray-600/50"
                    />
                    <div className="mt-3 text-xs text-gray-400 font-mono">
                      Formula: {getCurrentIndexData().formula}
                    </div>
                  </div>
                </div>
              </div>

              {/* Technical Metrics */}
              <div className="space-y-4">
                {/* Statistics Panel */}
                <div className="bg-black/40 border border-gray-600/50 rounded-lg">
                  <div className="bg-gray-900/80 px-4 py-2 border-b border-gray-600/50">
                    <h4 className="font-mono text-sm text-cyan-400">STATS.compute()</h4>
                  </div>
                  <div className="p-4 space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400 font-mono text-xs">min_val:</span>
                      <span className="text-green-400 font-mono">{getCurrentIndexData().min}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400 font-mono text-xs">mean_val:</span>
                      <span className="text-blue-400 font-mono">{getCurrentIndexData().media}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400 font-mono text-xs">max_val:</span>
                      <span className="text-red-400 font-mono">{getCurrentIndexData().max}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400 font-mono text-xs">std_dev:</span>
                      <span className="text-purple-400 font-mono">{getCurrentIndexData().std_dev}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400 font-mono text-xs">px_count:</span>
                      <span className="text-yellow-400 font-mono">{getCurrentIndexData().pixel_count.toLocaleString()}</span>
                    </div>
                  </div>
                </div>

                {/* Processing Info */}
                <div className="bg-black/40 border border-gray-600/50 rounded-lg">
                  <div className="bg-gray-900/80 px-4 py-2 border-b border-gray-600/50">
                    <h4 className="font-mono text-sm text-cyan-400">PROC.info()</h4>
                  </div>
                  <div className="p-4 space-y-2">
                    <div className="text-xs text-gray-400 font-mono">
                      Processing Time: <span className="text-green-400">{getCurrentIndexData().processing_time}s</span>
                    </div>
                    <div className="text-xs text-gray-400 font-mono">
                      Algorithm: <span className="text-blue-400">spectral_v2.1.4</span>
                    </div>
                    <div className="text-xs text-gray-400 font-mono">
                      Memory Usage: <span className="text-purple-400">847MB</span>
                    </div>
                  </div>
                </div>

                {/* Download */}
                <Button className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 font-mono">
                  <Download className="h-4 w-4 mr-2" />
                  download_{getCurrentIndexData().indice.toLowerCase()}.tiff
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* System Info */}
        <div className="bg-gray-800/40 border border-gray-600/50 rounded-lg p-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono">
            <div>
              <span className="text-gray-400">coordinates:</span>
              <div className="text-cyan-400">[{results.metadata.coordenadas[1]}, {results.metadata.coordenadas[0]}]</div>
            </div>
            <div>
              <span className="text-gray-400">satellite:</span>
              <div className="text-green-400">{results.metadata.satelite}</div>
            </div>
            <div>
              <span className="text-gray-400">timestamp:</span>
              <div className="text-yellow-400">{results.metadata.data_captura}</div>
            </div>
            <div>
              <span className="text-gray-400">job_id:</span>
              <div className="text-purple-400">{results.metadata.job_id}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}