'use client';

import { useState } from 'react';

export default function DesignOption2() {
  const [selectedTool, setSelectedTool] = useState<string | null>(null);
  const [mapClicks, setMapClicks] = useState<{x: number, y: number}[]>([]);
  const [currentCoordinates, setCurrentCoordinates] = useState({ lat: -23.550500, lng: -46.633300 });
  const [selectedArea, setSelectedArea] = useState({ points: 0, area: 0 });
  const [showInfoPopup, setShowInfoPopup] = useState(true);

  const activateAreaTool = () => {
    console.log("Ferramenta ÁREA ativada");
    setSelectedTool('area');
  };

  const activatePolygonTool = () => {
    console.log("Ferramenta POLÍGONO ativada");
    setSelectedTool('polygon');
  };

  const activatePointTool = () => {
    console.log("Ferramenta PONTO ativada");
    setSelectedTool('point');
  };

  const clearSelection = () => {
    console.log("Limpando seleção");
    setMapClicks([]);
    setSelectedArea({ points: 0, area: 0 });
    setSelectedTool(null);
  };

  const handleMapClick = (event: React.MouseEvent) => {
    if (!selectedTool) return;
    
    const rect = event.currentTarget.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    
    console.log(`Clique no mapa: ${x}, ${y} com ferramenta: ${selectedTool}`);
    
    setMapClicks(prev => [...prev, { x, y }]);
    setSelectedArea(prev => ({ 
      points: prev.points + 1, 
      area: prev.area + 0.25 
    }));
  };

  // Popup Informativo
  if (showInfoPopup) {
    return (
      <div className="fixed inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-green-900 flex items-center justify-center p-6 z-50">
        <div className="max-w-2xl w-full max-h-[85vh] bg-slate-900/95 backdrop-blur-md border border-emerald-500/30 rounded-lg overflow-hidden">
          <div className="p-8">
            <div className="text-center mb-6">
              <div className="relative w-24 h-24 mx-auto mb-4">
                <div className="absolute inset-0 w-24 h-24 bg-gradient-to-br from-emerald-400 via-green-500 to-amber-400 rounded-full opacity-30"></div>
                <div className="absolute inset-3 w-18 h-18 bg-gradient-to-br from-emerald-400 via-green-500 to-amber-400 rounded-full flex items-center justify-center">
                  <div className="animate-spin" style={{ animationDuration: '8s' }}>
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                      <path d="M13 7 9 3 5 7l4 4"></path>
                      <path d="m17 11 4 4-4 4-4-4"></path>
                      <path d="m8 12 4 4 6-6-4-4Z"></path>
                      <path d="m16 8 3-3"></path>
                      <path d="M9 21a6 6 0 0 0-6-6"></path>
                    </svg>
                  </div>
                </div>
              </div>
              <h1 className="text-3xl font-bold text-white mb-2 bg-gradient-to-r from-emerald-400 to-amber-400 bg-clip-text text-transparent font-fira">iAgroSat</h1>
              <p className="text-emerald-300 text-lg font-fira font-medium">SISTEMA DE ANÁLISE SATELITAL</p>
            </div>

            <div className="max-h-60 overflow-y-auto iagrosat-popup-scroll space-y-6 text-white mb-8">
              <div className="border border-emerald-500/30 p-4 rounded">
                <h3 className="text-emerald-400 font-bold mb-3 font-fira">TECNOLOGIA SENTINEL-2</h3>
                <p className="text-sm text-slate-300 font-fira font-light">
                  Processamento em tempo real de imagens de satélite com resolução de 10 metros por pixel.
                </p>
              </div>

              <div className="border border-emerald-500/30 p-4 rounded">
                <h3 className="text-amber-400 font-bold mb-3 font-fira">ANÁLISE ESPECTRAL</h3>
                <p className="text-sm text-slate-300 font-fira font-light">
                  Cálculo automático de índices RGB, NDVI, EVI, SAVI e GCI para análise de vegetação.
                </p>
              </div>

              <div className="border border-emerald-500/30 p-4 rounded">
                <h3 className="text-emerald-400 font-bold mb-3 font-fira">FERRAMENTAS PRECISAS</h3>
                <p className="text-sm text-slate-300 font-fira font-light">
                  Seleção por área, polígono ou pontos específicos com cálculo automático de superfície.
                </p>
              </div>

              <div className="border border-emerald-500/30 p-4 rounded">
                <h3 className="text-amber-400 font-bold mb-3 font-fira">PROCESSAMENTO RÁPIDO</h3>
                <p className="text-sm text-slate-300 font-fira font-light">
                  Resultados em segundos com download direto das imagens processadas.
                </p>
              </div>
            </div>

            <div className="mt-8 text-center">
              <button
                onClick={() => setShowInfoPopup(false)}
                className="bg-gradient-to-r from-emerald-600 to-amber-600 hover:from-emerald-700 hover:to-amber-700 px-8 py-4 text-white font-bold tracking-wider transition-all text-lg font-fira transform hover:scale-105 rounded"
              >
                INICIAR ANÁLISE
              </button>
            </div>

            <div className="mt-6 text-center text-xs text-slate-400 font-fira">
              iAgroSat LTDA • CNPJ: 61.579.333/0001-00 • Powered by SENTINEL-2
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-green-900 overflow-hidden">
      {/* Header */}
      <header className="bg-slate-900/95 backdrop-blur-md border-b border-emerald-500/30 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="relative w-16 h-16">
            <div className="absolute inset-0 w-16 h-16 bg-gradient-to-br from-emerald-400 via-green-500 to-amber-400 rounded-full opacity-30"></div>
            <div className="absolute inset-2 w-12 h-12 bg-gradient-to-br from-emerald-400 via-green-500 to-amber-400 rounded-full flex items-center justify-center">
              <div className="animate-spin" style={{ animationDuration: '8s' }}>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                  <path d="M13 7 9 3 5 7l4 4"></path>
                  <path d="m17 11 4 4-4 4-4-4"></path>
                  <path d="m8 12 4 4 6-6-4-4Z"></path>
                  <path d="m16 8 3-3"></path>
                  <path d="M9 21a6 6 0 0 0-6-6"></path>
                </svg>
              </div>
            </div>
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white font-fira">iAgroSat</h1>
            <p className="text-emerald-300 text-sm font-fira font-medium">ANÁLISE SATELITAL</p>
          </div>
        </div>
        <div className="flex items-center space-x-6">
          <button
            onClick={() => setShowInfoPopup(true)}
            className="p-2 bg-slate-800/80 hover:bg-slate-700/80 border border-emerald-500/30 rounded transition-colors"
            title="Informações do Sistema"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-emerald-400">
              <circle cx="12" cy="12" r="10"/>
              <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/>
              <path d="M12 17h.01"/>
            </svg>
          </button>
          <div className="flex items-center space-x-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-400">
              <path d="M20 6 9 17l-5-5"/>
            </svg>
            <span className="text-sm text-slate-300 font-fira font-medium">BACKEND CONECTADO</span>
          </div>
          <div className="flex items-center space-x-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-amber-400">
              <path d="M13 7 9 3 5 7l4 4"></path>
              <path d="m17 11 4 4-4 4-4-4"></path>
              <path d="m8 12 4 4 6-6-4-4Z"></path>
              <path d="m16 8 3-3"></path>
              <path d="M9 21a6 6 0 0 0-6-6"></path>
            </svg>
            <span className="text-sm text-slate-300 font-fira font-medium">SENTINEL ATIVO</span>
          </div>
        </div>
      </header>

      {/* Conteúdo Principal */}
      <div className="flex h-[calc(100vh-10rem)] p-6 gap-6">
        {/* Console Esquerdo */}
        <div className="w-80 bg-slate-900/95 backdrop-blur-md border border-emerald-500/30 rounded-sm">
          <div className="p-4 h-full flex flex-col">
            <div className="flex-1 space-y-4">
              
              {/* BUSCAR & COORDENADAS */}
              <div>
                <h3 className="text-emerald-400 mb-3 flex items-center text-sm font-bold tracking-wider font-fira">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                    <circle cx="11" cy="11" r="8"/>
                    <path d="m21 21-4.35-4.35"/>
                  </svg>
                  LOCALIZAÇÃO
                </h3>
                <div className="space-y-3">
                  <input
                    type="text"
                    placeholder="São Paulo, CEP, coordenadas..."
                    className="w-full px-4 py-2 bg-slate-800/80 text-white border border-emerald-500/30 focus:border-emerald-400 focus:outline-none text-sm placeholder-slate-400 transition-colors font-fira rounded"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      placeholder="Lat"
                      value={currentCoordinates.lat.toFixed(6)}
                      className="px-3 py-2 bg-slate-800/80 text-white border border-emerald-500/30 focus:border-emerald-400 focus:outline-none text-xs font-fira rounded"
                      readOnly
                    />
                    <input
                      type="text"
                      placeholder="Lng"
                      value={currentCoordinates.lng.toFixed(6)}
                      className="px-3 py-2 bg-slate-800/80 text-white border border-emerald-500/30 focus:border-emerald-400 focus:outline-none text-xs font-fira rounded"
                      readOnly
                    />
                  </div>
                  <button className="w-full bg-gradient-to-r from-emerald-600 to-amber-600 hover:from-emerald-700 hover:to-amber-700 text-white py-2 font-bold tracking-wider transition-all text-sm font-fira transform hover:scale-105 rounded">
                    BUSCAR & IR
                  </button>
                </div>
              </div>

              {/* SELEÇÃO ATIVA */}
              <div>
                <h4 className="text-white font-bold mb-3 flex items-center text-sm tracking-wider font-fira">
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 text-emerald-400">
                    <circle cx="12" cy="12" r="10"/>
                    <polyline points="12,6 12,12 16,14"/>
                  </svg>
                  SELEÇÃO ATIVA
                </h4>
                <div className="bg-slate-800/60 border border-emerald-500/30 p-3 rounded">
                  <div className="text-xs text-slate-300 space-y-1 font-fira font-medium">
                    <div className="flex justify-between">
                      <span>PONTOS:</span>
                      <span className="text-emerald-400">{selectedArea.points}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>ÁREA:</span>
                      <span className="text-emerald-400">{selectedArea.area.toFixed(2)} km²</span>
                    </div>
                    <div className="flex justify-between">
                      <span>STATUS:</span>
                      <span className={selectedArea.points > 0 ? 'text-emerald-400' : 'text-amber-400'}>
                        {selectedArea.points > 0 ? 'SELECIONADO' : 'AGUARDANDO'}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>FERRAMENTA:</span>
                      <span className="text-emerald-400">{selectedTool?.toUpperCase() || 'NENHUMA'}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* BOTÕES */}
              <div className="space-y-2">
                <button className="w-full bg-gradient-to-r from-emerald-600 to-amber-600 hover:from-emerald-700 hover:to-amber-700 text-white py-3 font-bold tracking-wider transition-all text-sm font-fira transform hover:scale-105 rounded">
                  PROCESSAR ANÁLISE
                </button>
                <button 
                  onClick={clearSelection}
                  className="w-full bg-red-600/80 hover:bg-red-600 text-white py-2 font-bold tracking-wider transition-colors text-sm border border-red-500/50 font-fira rounded"
                >
                  LIMPAR SELEÇÃO
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Área do Mapa Direita */}
        <div className="flex-1 bg-slate-600 rounded-sm relative overflow-hidden cursor-crosshair border border-emerald-500/20">
          <img 
            src="https://images.pexels.com/photos/87009/earth-soil-creep-moon-surface-87009.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
            alt="Mapa Satelital" 
            className="w-full h-full object-cover"
            onClick={handleMapClick}
          />
          
          {/* Pontos Selecionados */}
          {mapClicks.map((click, index) => (
            <div 
              key={index}
              className="absolute w-3 h-3 bg-emerald-400 rounded-full border-2 border-white shadow-lg animate-pulse"
              style={{ left: click.x - 6, top: click.y - 6 }}
            />
          ))}

          {/* FERRAMENTAS VERTICAIS NA DIREITA DO MAPA */}
          <div className="absolute top-4 right-4 flex flex-col space-y-1">
            <button 
              onClick={activateAreaTool}
              className={`w-12 h-12 flex items-center justify-center transition-all duration-300 ${
                selectedTool === 'area' 
                  ? 'bg-gradient-to-br from-emerald-500 to-amber-500 shadow-lg shadow-emerald-500/30' 
                  : 'bg-slate-900/90 hover:bg-slate-800/90 border border-emerald-500/30 backdrop-blur-sm'
              }`}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                <rect width="18" height="18" x="3" y="3" rx="2"/>
              </svg>
            </button>
            
            <button 
              onClick={activatePolygonTool}
              className={`w-12 h-12 flex items-center justify-center transition-all duration-300 ${
                selectedTool === 'polygon' 
                  ? 'bg-gradient-to-br from-emerald-500 to-amber-500 shadow-lg shadow-emerald-500/30' 
                  : 'bg-slate-900/90 hover:bg-slate-800/90 border border-emerald-500/30 backdrop-blur-sm'
              }`}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                <polygon points="13,2 3,14 12,14 11,22 21,10 12,10"/>
              </svg>
            </button>
            
            <button 
              onClick={activatePointTool}
              className={`w-12 h-12 flex items-center justify-center transition-all duration-300 ${
                selectedTool === 'point' 
                  ? 'bg-gradient-to-br from-emerald-500 to-amber-500 shadow-lg shadow-emerald-500/30' 
                  : 'bg-slate-900/90 hover:bg-slate-800/90 border border-emerald-500/30 backdrop-blur-sm'
              }`}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                <circle cx="12" cy="10" r="3"/>
              </svg>
            </button>
            
            <button 
              onClick={clearSelection}
              className="w-12 h-12 bg-red-600/90 hover:bg-red-600 flex items-center justify-center transition-all duration-300 hover:shadow-lg hover:shadow-red-500/30 backdrop-blur-sm border border-red-500/30"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                <path d="M3 6h18"/>
                <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/>
                <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Footer Fixo */}
      <footer className="h-16 bg-slate-900/95 backdrop-blur-md border-t border-emerald-500/30 px-6 py-4 flex items-center justify-center">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <div className="relative w-8 h-8">
              <div className="absolute inset-0 w-8 h-8 bg-gradient-to-br from-emerald-400 via-green-500 to-amber-400 rounded-full opacity-30"></div>
              <div className="absolute inset-1 w-6 h-6 bg-gradient-to-br from-emerald-400 via-green-500 to-amber-400 rounded-full flex items-center justify-center">
                <div className="animate-spin" style={{ animationDuration: '8s' }}>
                  <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                    <path d="M13 7 9 3 5 7l4 4"></path>
                    <path d="m17 11 4 4-4 4-4-4"></path>
                    <path d="m8 12 4 4 6-6-4-4Z"></path>
                    <path d="m16 8 3-3"></path>
                    <path d="M9 21a6 6 0 0 0-6-6"></path>
                  </svg>
                </div>
              </div>
            </div>
            <span className="text-slate-300 text-sm font-bold font-fira">iAgroSat LTDA</span>
          </div>
          <div className="text-slate-400 text-xs font-fira">
            CNPJ: 61.579.333/0001-00
          </div>
          <div className="text-slate-400 text-xs font-fira">
            Powered by SENTINEL-2
          </div>
          <div className="text-slate-400 text-xs font-fira">
            © 2024 Todos os Direitos Reservados
          </div>
        </div>
      </footer>
    </div>
  );
}