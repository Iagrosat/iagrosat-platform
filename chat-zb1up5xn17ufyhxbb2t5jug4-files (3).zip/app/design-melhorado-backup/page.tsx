'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { MapContainer } from '@/components/map-container'

export default function DesignMelhoradoBackup() {
  const router = useRouter()
  const [selectedTool, setSelectedTool] = useState<string | null>(null)
  const [mapClicks, setMapClicks] = useState<{x: number, y: number}[]>([])
  const [currentCoordinates, setCurrentCoordinates] = useState({ lat: -23.5505, lng: -46.6333 })
  const [selectedArea, setSelectedArea] = useState({ points: 1, area: 0.25 })
  const [showInfoPopup, setShowInfoPopup] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [selectedLocation, setSelectedLocation] = useState<{lat: number, lon: number} | null>({ lat: -23.5505, lon: -46.6333 })
  const [selectedAreaData, setSelectedAreaData] = useState<{area: number, coordinates: number[][]} | null>(null)
  const [searchQuery, setSearchQuery] = useState('')

  const processAnalysis = () => {
    console.log("🚀 Starting analysis process")
    setIsLoading(true)
    
    // Simulate redirect to processing page
    const jobId = `job-${Date.now()}`
    console.log("📊 Generated job ID:", jobId)
    
    // Redirect to results page with job ID
    router.push(`/results/${jobId}`)
  };

  const handleSearch = async () => {
    const query = searchQuery.trim()
    if (!query) return

    console.log("🔍 Searching for:", query)
    
    try {
      // Detect if it's coordinates (lat,lng format)
      const coordMatch = query.match(/(-?\d+\.?\d*),?\s*(-?\d+\.?\d*)/)
      if (coordMatch) {
        const lat = parseFloat(coordMatch[1])
        const lng = parseFloat(coordMatch[2])
        console.log("📍 Detected coordinates:", lat, lng)
        handleCoordinateUpdate(lat, lng)
        return
      }
      
      // Search for city using ESRI Geocoding API
      const geocodeUrl = `https://geocode-api.arcgis.com/arcgis/rest/services/World/GeocodeServer/findAddressCandidates?singleLine=${encodeURIComponent(query)}&maxLocations=1&outFields=*&f=json`
      
      const response = await fetch(geocodeUrl)
      const data = await response.json()
      
      if (data.candidates && data.candidates.length > 0) {
        const result = data.candidates[0]
        const lat = result.location.y
        const lng = result.location.x
        
        console.log("🌍 Found location:", result.address, "at", lat, lng)
        handleCoordinateUpdate(lat, lng)
      } else {
        alert('Local não encontrado. Tente outro nome.')
        console.log("❌ No results found for:", query)
      }
    } catch (error) {
      console.error('Search error:', error)
      alert('Erro na busca. Tente novamente.')
    }
  };

  const handleCoordinateUpdate = (lat: number, lng: number) => {
    console.log("📍 Updating coordinates:", lat, lng)
    setCurrentCoordinates({ lat, lng })
    setSelectedLocation({ lat, lon: lng })
    
    // Update map position and add marker
    if ((window as any).mapFunctions) {
      (window as any).mapFunctions.updateCoordinates(lat, lng)
    }
  };

  const activateAreaTool = () => {
    console.log("🎨 Activating area tool")
    if ((window as any).mapFunctions) {
      (window as any).mapFunctions.activateAreaTool()
    }
    setSelectedTool('area')
  };

  const activatePolygonTool = () => {
    console.log("📐 Activating polygon tool")
    if ((window as any).mapFunctions) {
      (window as any).mapFunctions.activatePolygonTool()
    }
    setSelectedTool('polygon')
  };

  const activatePointTool = () => {
    console.log("📍 Activating point tool")
    if ((window as any).mapFunctions) {
      (window as any).mapFunctions.activatePointTool()
    }
    setSelectedTool('point')
  };

  const clearSelection = () => {
    console.log("🗑️ Clearing selection")
    if ((window as any).mapFunctions) {
      (window as any).mapFunctions.clearSelection()
    }
    setSelectedTool(null)
    setSelectedArea({ points: 1, area: 0.25 })
  };

  return (
    <div className="h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950 flex flex-col overflow-hidden">
      {/* Header - Design Melhorado Original */}
      <header className="bg-black/80 backdrop-blur-xl border-b border-emerald-500/20 px-8 py-6 flex items-center justify-between flex-shrink-0">
        <div className="flex items-center space-x-6">
          <div className="relative w-20 h-20">
            <div className="absolute inset-0 w-20 h-20 bg-gradient-to-br from-emerald-400 via-green-500 to-amber-400 rounded-full opacity-20 blur-sm"></div>
            <div className="absolute inset-2 w-16 h-16 bg-gradient-to-br from-emerald-400 via-green-500 to-amber-400 rounded-full flex items-center justify-center">
              <div className="animate-spin" style={{ animationDuration: '12s' }}>
                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                  <path d="M13 7 9 3 5 7l4 4"></path>
                  <path d="m17 11 4 4-4 4-4-4"></path>
                  <path d="m8 12 4 4 6-6-4-4Z"></path>
                  <path d="m16 8 3-3"></path>
                  <path d="M9 21a6 6 0 0 0-6-6"></path>
                </svg>
              </div>
            </div>
          </div>
          <div className="space-y-1">
            <h1 className="text-3xl font-bold text-white font-fira tracking-wide">iAgroSat</h1>
            <p className="text-emerald-300 text-sm font-fira font-medium tracking-widest">ANÁLISE SATELITAL AVANÇADA</p>
          </div>
        </div>
        <div className="flex items-center space-x-8">
          <div className="flex items-center space-x-3">
            <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
            <span className="text-sm text-slate-300 font-fira font-medium tracking-wider">BACKEND ATIVO</span>
          </div>
          <div className="flex items-center space-x-3">
            <div className="w-3 h-3 bg-amber-400 rounded-full animate-pulse"></div>
            <span className="text-sm text-slate-300 font-fira font-medium tracking-wider">SENTINEL ATIVO</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Side Panel */}
        <div className="w-80 bg-slate-900/90 backdrop-blur-xl border-r border-emerald-500/20 flex flex-col">
          <div className="p-6 flex-1">
            
            {/* Search Section */}
            <div className="mb-8">
              <h3 className="text-emerald-300 text-lg font-bold mb-4 font-fira tracking-wide">🔍 BUSCAR LOCAL</h3>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="São Paulo, Rio de Janeiro, Brasília..."
                className="w-full px-4 py-3 bg-slate-800/80 text-white border border-emerald-500/30 focus:border-emerald-400 focus:outline-none rounded-lg text-sm placeholder-slate-400 font-fira"
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    handleSearch()
                  }
                }}
              />
              <button 
                onClick={handleSearch}
                className="w-full mt-3 bg-gradient-to-r from-emerald-500 to-amber-500 hover:from-emerald-600 hover:to-amber-600 text-white py-3 font-bold rounded-lg transition-all duration-300 text-sm font-fira tracking-wide"
              >
                BUSCAR & LOCALIZAR
              </button>
            </div>

            {/* Coordinates Section */}
            <div className="mb-8">
              <h3 className="text-emerald-300 text-lg font-bold mb-4 font-fira tracking-wide">📍 COORDENADAS</h3>
              <div className="grid grid-cols-2 gap-3">
                <input
                  type="number"
                  placeholder="Latitude"
                  className="px-3 py-2 bg-slate-800/80 text-white border border-emerald-500/30 focus:border-emerald-400 focus:outline-none rounded-lg text-sm font-fira"
                  step="any"
                />
                <input
                  type="number"
                  placeholder="Longitude"
                  className="px-3 py-2 bg-slate-800/80 text-white border border-emerald-500/30 focus:border-emerald-400 focus:outline-none rounded-lg text-sm font-fira"
                  step="any"
                />
              </div>
              <button 
                className="w-full mt-3 bg-gradient-to-r from-amber-500 to-emerald-500 hover:from-amber-600 hover:to-emerald-600 text-white py-3 font-bold rounded-lg transition-all duration-300 text-sm font-fira tracking-wide"
              >
                IR PARA COORDENADAS
              </button>
            </div>

            {/* Selection Info */}
            <div className="mb-8">
              <h3 className="text-emerald-300 text-lg font-bold mb-4 font-fira tracking-wide">🎯 SELEÇÃO ATIVA</h3>
              <div className="bg-slate-800/60 rounded-lg p-4 space-y-3">
                <div className="flex justify-between">
                  <span className="text-slate-300 text-sm font-fira">Pontos:</span>
                  <span className="text-emerald-400 font-bold text-sm font-fira">{selectedArea.points}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-300 text-sm font-fira">Área:</span>
                  <span className="text-emerald-400 font-bold text-sm font-fira">{selectedArea.area} km²</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-300 text-sm font-fira">Status:</span>
                  <span className="text-emerald-400 font-bold text-sm font-fira">SELECIONADO</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-300 text-sm font-fira">Ferramenta:</span>
                  <span className="text-emerald-400 font-bold text-sm font-fira">{selectedTool?.toUpperCase() || 'NENHUMA'}</span>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3">
              <button 
                onClick={processAnalysis}
                className="w-full bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600 text-white py-4 font-bold rounded-lg transition-all duration-300 text-base font-fira tracking-wide shadow-lg shadow-emerald-500/30"
              >
                PROCESSAR ANÁLISE
              </button>
              <button 
                onClick={clearSelection}
                className="w-full bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white py-3 font-bold rounded-lg transition-all duration-300 text-sm font-fira tracking-wide"
              >
                LIMPAR SELEÇÃO
              </button>
            </div>
          </div>
        </div>

        {/* Map */}
        <div className="flex-1 relative">
          <MapContainer
            onCoordinateSelect={(coords) => {
              setCurrentCoordinates({ lat: coords.lat, lng: coords.lon })
            }}
            onAreaSelect={(area) => {
              setSelectedAreaData(area)
            }}
            onAnalysisStart={() => {
              processAnalysis()
            }}
            onToolActivated={(tool) => {
              setSelectedTool(tool)
            }}
          />

          {/* Map Tools */}
          <div className="absolute top-4 right-4 flex flex-col space-y-2">
            <button onClick={activateAreaTool} className="w-12 h-12 bg-slate-800/80 hover:bg-slate-700/80 border border-emerald-500/30 rounded-lg flex items-center justify-center transition-all duration-300">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                <rect width="18" height="18" x="3" y="3" rx="2"/>
              </svg>
            </button>
            <button onClick={activatePolygonTool} className="w-12 h-12 bg-slate-800/80 hover:bg-slate-700/80 border border-emerald-500/30 rounded-lg flex items-center justify-center transition-all duration-300">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                <polygon points="13,2 3,14 12,14 11,22 21,10 12,10"/>
              </svg>
            </button>
            <button onClick={activatePointTool} className="w-12 h-12 bg-slate-800/80 hover:bg-slate-700/80 border border-emerald-500/30 rounded-lg flex items-center justify-center transition-all duration-300">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                <circle cx="12" cy="10" r="3"/>
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-slate-900/90 backdrop-blur-xl border-t border-emerald-500/20 px-8 py-4 flex items-center justify-center flex-shrink-0">
        <div className="flex items-center space-x-8">
          <div className="flex items-center space-x-3">
            <div className="relative w-10 h-10">
              <div className="absolute inset-0 w-10 h-10 bg-gradient-to-br from-emerald-400 via-green-500 to-amber-400 rounded-full opacity-20 blur-sm"></div>
              <div className="absolute inset-1 w-8 h-8 bg-gradient-to-br from-emerald-400 via-green-500 to-amber-400 rounded-full flex items-center justify-center">
                <div className="animate-spin" style={{ animationDuration: '12s' }}>
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                    <path d="M13 7 9 3 5 7l4 4"></path>
                    <path d="m17 11 4 4-4 4-4-4"></path>
                    <path d="m8 12 4 4 6-6-4-4Z"></path>
                    <path d="m16 8 3-3"></path>
                    <path d="M9 21a6 6 0 0 0-6-6"></path>
                  </svg>
                </div>
              </div>
            </div>
            <span className="text-slate-300 text-sm font-bold font-fira tracking-wider">iAgroSat</span>
          </div>
          <div className="text-slate-400 text-xs font-fira">
            CNPJ: 61.579.333/0001-00
          </div>
          <div className="text-slate-400 text-xs font-fira">
            Powered by SENTINEL-2
          </div>
          <div className="text-slate-400 text-xs font-fira">
            © 2024 Todos os Direitos Reservados
          </div>
        </div>
      </footer>
    </div>
  )
}