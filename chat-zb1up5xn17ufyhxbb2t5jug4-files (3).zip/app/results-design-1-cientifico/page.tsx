'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { ArrowLeft, Download, FileText, BarChart3 } from 'lucide-react'
import { useRouter } from 'next/navigation'

export default function ResultsDesign1() {
  const router = useRouter()
  const [activeIndex, setActiveIndex] = useState('ndvi')

  // Demo data baseado na pesquisa científica
  const results = {
    metadata: {
      job_id: 'demo-cientifico',
      satelite: 'Sentinel-2 L2A',
      data_captura: '2024-07-06',
      cobertura_nuvens: 12,
      coordenadas: [-46.6333, -23.5505],
      resolucao: '10m',
      localizacao: 'São Paulo, SP',
      area_hectares: 250.5,
      pixel_count: 125643
    },
    images: {
      rgb: '/api/demo-static/rgb.png',
      ndvi: '/api/demo-static/ndvi.png',
      evi: '/api/demo-static/evi.png',
      savi: '/api/demo-static/savi.png',
      gci: '/api/demo-static/gci.png'
    },
    indices: [
      { 
        indice: 'NDVI', 
        nome: 'Normalized Difference Vegetation Index',
        min: 0.15, 
        media: 0.68, 
        max: 0.92,
        percentil_25: 0.42,
        percentil_75: 0.84,
        pixels_validos: 125643,
        aplicacao: 'Medição geral de saúde e densidade da vegetação'
      },
      { 
        indice: 'EVI', 
        nome: 'Enhanced Vegetation Index',
        min: 0.08, 
        media: 0.52, 
        max: 0.89,
        percentil_25: 0.31,
        percentil_75: 0.73,
        pixels_validos: 125643,
        aplicacao: 'Minimiza ruído atmosférico, ideal para vegetação densa'
      },
      { 
        indice: 'SAVI', 
        nome: 'Soil Adjusted Vegetation Index',
        min: 0.12, 
        media: 0.58, 
        max: 0.87,
        percentil_25: 0.36,
        percentil_75: 0.76,
        pixels_validos: 125643,
        aplicacao: 'Corrige interferência do solo, ideal para vegetação esparsa'
      },
      { 
        indice: 'GCI', 
        nome: 'Green Chlorophyll Index',
        min: 1.8, 
        media: 3.2, 
        max: 5.1,
        percentil_25: 2.4,
        percentil_75: 4.1,
        pixels_validos: 125643,
        aplicacao: 'Estimativa do conteúdo de clorofila nas folhas'
      }
    ]
  }

  const indexButtons = [
    { key: 'ndvi', label: 'NDVI', color: 'bg-green-600' },
    { key: 'evi', label: 'EVI', color: 'bg-blue-600' },
    { key: 'savi', label: 'SAVI', color: 'bg-orange-600' },
    { key: 'gci', label: 'GCI', color: 'bg-purple-600' },
  ]

  const getCurrentIndexData = () => {
    return results.indices.find(idx => idx.indice.toLowerCase() === activeIndex) || results.indices[0]
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header Científico */}
      <header className="bg-gray-50 border-b border-gray-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => router.push('/')}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Voltar
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Relatório de Análise Espectral</h1>
              <p className="text-sm text-gray-600">Job ID: {results.metadata.job_id} • Processamento concluído</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <Button variant="outline" size="sm" className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              Exportar PDF
            </Button>
            <Button variant="outline" size="sm" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Relatório Completo
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-6">
        {/* Informações da Missão */}
        <div className="bg-blue-50 border-l-4 border-blue-400 p-4 mb-8">
          <div className="grid grid-cols-2 md:grid-cols-6 gap-4 text-sm">
            <div>
              <span className="font-medium text-blue-800">Satélite:</span>
              <div className="text-blue-900">{results.metadata.satelite}</div>
            </div>
            <div>
              <span className="font-medium text-blue-800">Data:</span>
              <div className="text-blue-900">{results.metadata.data_captura}</div>
            </div>
            <div>
              <span className="font-medium text-blue-800">Resolução:</span>
              <div className="text-blue-900">{results.metadata.resolucao}</div>
            </div>
            <div>
              <span className="font-medium text-blue-800">Nuvens:</span>
              <div className="text-blue-900">{results.metadata.cobertura_nuvens}%</div>
            </div>
            <div>
              <span className="font-medium text-blue-800">Área:</span>
              <div className="text-blue-900">{results.metadata.area_hectares} ha</div>
            </div>
            <div>
              <span className="font-medium text-blue-800">Pixels:</span>
              <div className="text-blue-900">{results.metadata.pixel_count.toLocaleString()}</div>
            </div>
          </div>
        </div>

        {/* Imagem RGB */}
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4">1. Imagem de Referência RGB</h2>
          <div className="bg-gray-50 p-6 rounded-lg">
            <div className="text-center">
              <img 
                src={results.images.rgb}
                alt="Imagem RGB Sentinel-2" 
                className="max-w-lg mx-auto rounded-lg shadow-md border border-gray-200"
              />
              <p className="text-sm text-gray-600 mt-3">
                Composição RGB natural do satélite Sentinel-2 • Localização: {results.metadata.localizacao}
              </p>
            </div>
          </div>
        </div>

        {/* Análise de Índices */}
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4">2. Análise de Índices de Vegetação</h2>
          
          {/* Seleção de Índices */}
          <div className="flex flex-wrap gap-2 mb-6">
            {indexButtons.map((btn) => (
              <button
                key={btn.key}
                onClick={() => setActiveIndex(btn.key)}
                className={`px-4 py-2 rounded-lg font-medium text-sm transition-all ${
                  activeIndex === btn.key 
                    ? `${btn.color} text-white shadow-lg` 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {btn.label}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Imagem do Índice */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">
                {getCurrentIndexData().nome} ({getCurrentIndexData().indice})
              </h3>
              <div className="bg-gray-50 p-4 rounded-lg">
                <img
                  src={results.images[activeIndex]}
                  alt={`Índice ${getCurrentIndexData().indice}`}
                  className="w-full rounded-lg shadow-md border border-gray-200"
                />
                <div className="mt-3 text-xs text-gray-600">
                  {getCurrentIndexData().aplicacao}
                </div>
              </div>
            </div>

            {/* Estatísticas Detalhadas */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Estatísticas Descritivas</h3>
              
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-center">
                  <div className="text-xs font-medium text-green-600 mb-1">Valor Mínimo</div>
                  <div className="text-2xl font-bold text-green-800">{getCurrentIndexData().min}</div>
                </div>
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-center">
                  <div className="text-xs font-medium text-blue-600 mb-1">Valor Médio</div>
                  <div className="text-2xl font-bold text-blue-800">{getCurrentIndexData().media}</div>
                </div>
                <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 text-center">
                  <div className="text-xs font-medium text-orange-600 mb-1">Valor Máximo</div>
                  <div className="text-2xl font-bold text-orange-800">{getCurrentIndexData().max}</div>
                </div>
                <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 text-center">
                  <div className="text-xs font-medium text-purple-600 mb-1">Pixels Válidos</div>
                  <div className="text-lg font-bold text-purple-800">{getCurrentIndexData().pixels_validos.toLocaleString()}</div>
                </div>
              </div>

              {/* Percentis */}
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                <h4 className="font-medium text-gray-900 mb-3">Distribuição dos Valores</h4>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">25º Percentil:</span>
                    <span className="text-sm font-medium text-gray-900">{getCurrentIndexData().percentil_25}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">50º Percentil (Mediana):</span>
                    <span className="text-sm font-medium text-gray-900">{getCurrentIndexData().media}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">75º Percentil:</span>
                    <span className="text-sm font-medium text-gray-900">{getCurrentIndexData().percentil_75}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Coordenadas e Localização */}
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">3. Localização e Metadados</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div>
              <span className="font-medium text-gray-600">Latitude:</span>
              <div className="text-gray-900 font-mono">{results.metadata.coordenadas[1]}°</div>
            </div>
            <div>
              <span className="font-medium text-gray-600">Longitude:</span>
              <div className="text-gray-900 font-mono">{results.metadata.coordenadas[0]}°</div>
            </div>
            <div>
              <span className="font-medium text-gray-600">Área Total:</span>
              <div className="text-gray-900">{results.metadata.area_hectares} hectares</div>
            </div>
            <div>
              <span className="font-medium text-gray-600">Data de Aquisição:</span>
              <div className="text-gray-900">{results.metadata.data_captura}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}