'use client';

import { useState } from 'react';
import { MapContainer } from '@/components/map-container';

export default function DesignOption1() {
  const [selectedLocation, setSelectedLocation] = useState<{lat: number, lon: number} | null>(null);
  const [selectedAreaData, setSelectedAreaData] = useState<{area: number, coordinates: number[][]} | null>(null);

  return (
    <div className="min-h-screen bg-slate-900">
      {/* Corporate Elite Header */}
      <header className="bg-gradient-to-r from-slate-800 to-slate-700 border-b border-amber-500/20">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-amber-600 rounded-lg flex items-center justify-center">
                <div className="w-6 h-6 border-2 border-white rounded-full relative">
                  <div className="absolute inset-1 bg-white rounded-full animate-pulse"></div>
                </div>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">iAgroSat</h1>
                <p className="text-amber-400 text-sm font-medium">Enterprise Satellite Analytics</p>
              </div>
            </div>
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-white text-sm">System Operational</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-amber-500 rounded-full"></div>
                <span className="text-white text-sm">Sentinel-2 Active</span>
              </div>
              <button className="px-4 py-2 bg-amber-600 text-white rounded-md hover:bg-amber-700 transition-colors">
                Enterprise Portal
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex h-[calc(100vh-88px)]">
        {/* Left Sidebar */}
        <div className="w-80 bg-slate-800 border-r border-slate-700">
          <div className="p-6">
            <h2 className="text-lg font-semibold text-white mb-4">Analysis Tools</h2>
            
            {/* Location Search */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-slate-300 mb-2">Location Search</label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Enter coordinates or location"
                  className="w-full bg-slate-700 border border-slate-600 rounded-md px-4 py-2 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
                <button className="absolute right-2 top-2 text-amber-400 hover:text-amber-300">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </button>
              </div>
            </div>

            {/* Drawing Tools */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-slate-300 mb-2">Area Selection</label>
              <div className="grid grid-cols-2 gap-2">
                <button className="px-3 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-md transition-colors">
                  Polygon
                </button>
                <button className="px-3 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-md transition-colors">
                  Rectangle
                </button>
              </div>
            </div>

            {/* Analysis Options */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-slate-300 mb-2">Analysis Type</label>
              <select className="w-full bg-slate-700 border border-slate-600 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-amber-500">
                <option>Vegetation Analysis</option>
                <option>Land Use Classification</option>
                <option>Change Detection</option>
                <option>Crop Health Assessment</option>
              </select>
            </div>

            {/* Execute Button */}
            <button className="w-full bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-700 hover:to-amber-800 text-white font-medium py-3 rounded-md transition-all duration-200 transform hover:scale-[1.02]">
              Execute Analysis
            </button>
          </div>
        </div>

        {/* Map Area */}
        <div className="flex-1 relative bg-slate-700 rounded-lg m-4">
          <div className="h-full w-full flex items-center justify-center">
            <div className="text-center">
              <div className="text-6xl mb-4 text-amber-400">🗺️</div>
              <h3 className="text-2xl font-bold text-white mb-2">Interactive Map</h3>
              <p className="text-slate-300">ESRI ArcGIS Map will be rendered here</p>
              <div className="mt-6 bg-slate-600/50 rounded-lg p-4 max-w-md mx-auto">
                <h4 className="text-white font-medium mb-2">Features Preview:</h4>
                <ul className="text-slate-300 text-sm space-y-1">
                  <li>• Satellite base layers</li>
                  <li>• Area selection tools</li>
                  <li>• Location search</li>
                  <li>• Coordinate display</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}