'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ArrowLeft, Download, Share2, ChevronRight } from 'lucide-react'
import { useRouter } from 'next/navigation'

export default function AgriTechResults() {
  const router = useRouter()
  const [activeIndex, setActiveIndex] = useState('ndvi')

  const indices = {
    ndvi: {
      name: 'NDVI (Vegetação)',
      value: '0.73',
      status: 'Excelente',
      color: 'text-green-500',
      description: 'Índice de vegetação saudável indicando alta produtividade agrícola'
    },
    savi: {
      name: 'SAVI (Solo-Vegetação)',
      value: '0.65',
      status: 'Bom',
      color: 'text-emerald-500',
      description: 'Relação solo-vegetação otimizada para análise agrícola'
    },
    evi: {
      name: 'EVI (Vegetação Aprimorado)',
      value: '0.58',
      status: 'Moderado',
      color: 'text-yellow-500',
      description: 'Índice de vegetação com correção atmosférica'
    },
    moisture: {
      name: 'Umidade do Solo',
      value: '68%',
      status: 'Adequado',
      color: 'text-blue-500',
      description: 'Níveis de umidade favoráveis para crescimento'
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-emerald-900 to-green-800">
      {/* Header */}
      <header className="bg-slate-900/95 backdrop-blur-md border-b border-emerald-500/30 p-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center space-x-4">
            <Button
              variant="outline"
              onClick={() => router.push('/')}
              className="flex items-center gap-2 bg-slate-800/80 border-emerald-500/30 text-emerald-400 hover:bg-slate-700/80"
            >
              <ArrowLeft className="h-4 w-4" />
              Voltar
            </Button>
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-emerald-400 to-green-600 rounded-lg flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                  <path d="M13 7 9 3 5 7l4 4"></path>
                  <path d="m17 11 4 4-4 4-4-4"></path>
                  <path d="m8 12 4 4 6-6-4-4Z"></path>
                  <path d="m16 8 3-3"></path>
                  <path d="M9 21a6 6 0 0 0-6-6"></path>
                </svg>
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">AgriTech Analytics</h1>
                <p className="text-emerald-400 text-sm">Análise Satelital para Agricultura</p>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" className="bg-slate-800/80 border-emerald-500/30 text-emerald-400">
              <Share2 className="h-4 w-4 mr-2" />
              Compartilhar
            </Button>
            <Button variant="outline" size="sm" className="bg-slate-800/80 border-emerald-500/30 text-emerald-400">
              <Download className="h-4 w-4 mr-2" />
              Exportar
            </Button>
          </div>
        </div>
      </header>

      <div className="p-6 max-w-7xl mx-auto">
        {/* Location Info */}
        <div className="bg-slate-900/80 backdrop-blur-md rounded-xl border border-emerald-500/30 p-6 mb-6">
          <div className="grid md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-emerald-400">São Paulo, SP</div>
              <div className="text-slate-400 text-sm">Região Analisada</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-amber-400">23KMQ</div>
              <div className="text-slate-400 text-sm">Tile Sentinel-2</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-400">1.2 km²</div>
              <div className="text-slate-400 text-sm">Área Total</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-400">94%</div>
              <div className="text-slate-400 text-sm">Precisão</div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Indices Cards */}
          <div className="lg:col-span-2 space-y-4">
            <h2 className="text-2xl font-bold text-white mb-4">Índices Espectrais</h2>
            
            <Tabs value={activeIndex} onValueChange={setActiveIndex} className="w-full">
              <TabsList className="grid w-full grid-cols-4 bg-slate-800/60 border border-emerald-500/30">
                {Object.entries(indices).map(([key, index]) => (
                  <TabsTrigger key={key} value={key} className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                    {index.name.split(' ')[0]}
                  </TabsTrigger>
                ))}
              </TabsList>
              
              {Object.entries(indices).map(([key, index]) => (
                <TabsContent key={key} value={key}>
                  <Card className="bg-slate-900/80 border-emerald-500/30">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-white">{index.name}</CardTitle>
                        <Badge variant="outline" className={`${index.color} border-current`}>
                          {index.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center space-x-4 mb-4">
                        <div className={`text-4xl font-bold ${index.color}`}>
                          {index.value}
                        </div>
                        <div className="flex-1">
                          <div className="w-full bg-slate-700 rounded-full h-2">
                            <div 
                              className="bg-gradient-to-r from-emerald-500 to-green-500 h-2 rounded-full" 
                              style={{ width: `${parseFloat(index.value.replace('%', '')) || 73}%` }}
                            ></div>
                          </div>
                        </div>
                      </div>
                      <p className="text-slate-400 text-sm">{index.description}</p>
                    </CardContent>
                  </Card>
                </TabsContent>
              ))}
            </Tabs>
          </div>

          {/* Sidebar Info */}
          <div className="space-y-4">
            <Card className="bg-slate-900/80 border-emerald-500/30">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse mr-2"></div>
                  Status da Análise
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-400">Processamento:</span>
                  <span className="text-green-400 font-bold">Completo</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-400">Qualidade:</span>
                  <span className="text-emerald-400 font-bold">Alta</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-400">Cobertura:</span>
                  <span className="text-blue-400 font-bold">100%</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-400">Data:</span>
                  <span className="text-amber-400 font-bold">{new Date().toLocaleDateString('pt-BR')}</span>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-900/80 border-emerald-500/30">
              <CardHeader>
                <CardTitle className="text-white">Recomendações</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-start space-x-3 text-sm">
                  <ChevronRight className="h-4 w-4 text-emerald-400 mt-0.5" />
                  <span className="text-slate-300">Vegetação em estado saudável</span>
                </div>
                <div className="flex items-start space-x-3 text-sm">
                  <ChevronRight className="h-4 w-4 text-emerald-400 mt-0.5" />
                  <span className="text-slate-300">Umidade adequada para crescimento</span>
                </div>
                <div className="flex items-start space-x-3 text-sm">
                  <ChevronRight className="h-4 w-4 text-amber-400 mt-0.5" />
                  <span className="text-slate-300">Monitorar EVI nas próximas semanas</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}