'use client';

import { useState } from 'react';

export default function DesignOptionFinal() {
  const [selectedLocation, setSelectedLocation] = useState<{lat: number, lon: number} | null>(null);
  const [selectedAreaData, setSelectedAreaData] = useState<{area: number, coordinates: number[][]} | null>(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-green-900/20 to-slate-900">
      {/* Header Profissional */}
      <header className="bg-gradient-to-r from-green-800/90 to-green-900/90 backdrop-blur-sm border-b border-yellow-500/30">
        <div className="px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              {/* Logo com Satélite Sofisticado */}
              <div className="relative">
                {/* Terra Verde Musgo/Dourada */}
                <div className="w-16 h-16 bg-gradient-to-br from-green-600 via-yellow-600 to-green-700 rounded-full flex items-center justify-center shadow-2xl border-2 border-yellow-400/50 relative overflow-hidden">
                  {/* Continentes */}
                  <div className="absolute inset-0">
                    <div className="absolute top-3 left-3 w-2 h-2 bg-green-800 rounded-full opacity-70"></div>
                    <div className="absolute bottom-4 right-4 w-1.5 h-1.5 bg-green-800 rounded-full opacity-70"></div>
                    <div className="absolute top-5 right-3 w-1 h-1 bg-green-800 rounded-full opacity-70"></div>
                  </div>
                  {/* Botão Verde Piscando no Centro */}
                  <div className="w-4 h-4 bg-green-300 rounded-full animate-pulse shadow-lg z-10 border border-green-200"></div>
                </div>
                
                {/* Satélite Profissional da Imagem */}
                <div className="absolute -top-2 -right-2 w-10 h-10 animate-spin" style={{animation: 'spin 8s linear infinite'}}>
                  <div className="relative w-full h-full">
                    {/* Corpo principal detalhado - baseado na imagem */}
                    <div className="absolute top-2 left-4 w-2 h-4 bg-gradient-to-b from-slate-100 via-slate-200 to-slate-300 rounded-sm border border-slate-400 shadow-sm">
                      {/* Detalhes do corpo */}
                      <div className="absolute top-0.5 left-0.5 w-1 h-1 bg-blue-400 rounded-full"></div>
                      <div className="absolute bottom-0.5 left-0.5 w-1 h-0.5 bg-green-400 rounded-full"></div>
                    </div>
                    
                    {/* Painéis solares - mais realistas */}
                    <div className="absolute top-1 left-1 w-2 h-6 bg-gradient-to-br from-blue-800 via-blue-600 to-blue-800 rounded-sm border border-blue-900 shadow-lg">
                      <div className="absolute top-1 left-0.5 w-1 h-4 bg-blue-500 opacity-30 rounded-sm"></div>
                    </div>
                    <div className="absolute top-1 right-1 w-2 h-6 bg-gradient-to-bl from-blue-800 via-blue-600 to-blue-800 rounded-sm border border-blue-900 shadow-lg">
                      <div className="absolute top-1 right-0.5 w-1 h-4 bg-blue-500 opacity-30 rounded-sm"></div>
                    </div>
                    
                    {/* Antena sofisticada */}
                    <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-0.5 h-3 bg-gradient-to-t from-yellow-600 to-yellow-300 shadow-sm"></div>
                    <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-3 h-0.5 bg-yellow-400 rounded-full shadow-sm"></div>
                    
                    {/* Comunicação - antena parabólica pequena */}
                    <div className="absolute top-0.5 right-0.5 w-1 h-1 bg-yellow-300 rounded-full shadow-sm"></div>
                    
                    {/* Luzes de status */}
                    <div className="absolute top-2.5 left-4.5 w-0.5 h-0.5 bg-green-400 rounded-full animate-pulse"></div>
                    <div className="absolute top-3.5 left-4.5 w-0.5 h-0.5 bg-red-400 rounded-full animate-pulse" style={{animationDelay: '0.5s'}}></div>
                  </div>
                </div>
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white tracking-wide">iAgroSat</h1>
                <p className="text-yellow-300 text-sm font-medium tracking-wide">Análise Satelital</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="bg-green-800/50 px-4 py-2 rounded-xl border border-yellow-500/30 shadow-lg">
                <span className="text-green-300 text-sm font-mono">● SISTEMA ONLINE</span>
              </div>
              <button className="px-6 py-2 bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-green-900 font-bold rounded-xl transition-all shadow-lg hover:shadow-xl">
                Painel Corporativo
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Interface Principal */}
      <div className="flex h-[calc(100vh-84px)]">
        {/* Painel de Coordenadas (Esquerda) */}
        <div className="w-80 bg-gradient-to-b from-green-900/30 to-green-900/50 border-r border-yellow-500/30 backdrop-blur-sm">
          <div className="p-6">
            {/* Busca de Localização */}
            <div className="mb-6">
              <h3 className="text-xl font-bold text-yellow-400 mb-4 tracking-wide">Localização</h3>
              <div className="space-y-4">
                <input
                  type="text"
                  placeholder="Buscar local..."
                  className="w-full bg-green-800/30 border border-yellow-500/30 rounded-xl px-4 py-3 text-white placeholder-green-300 focus:outline-none focus:border-yellow-400 focus:ring-2 focus:ring-yellow-400/50 transition-all"
                />
                <div className="grid grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="Latitude"
                    className="bg-green-800/30 border border-yellow-500/30 rounded-xl px-3 py-2 text-sm text-white placeholder-green-300 focus:outline-none focus:border-yellow-400 transition-all"
                  />
                  <input
                    type="text"
                    placeholder="Longitude"
                    className="bg-green-800/30 border border-yellow-500/30 rounded-xl px-3 py-2 text-sm text-white placeholder-green-300 focus:outline-none focus:border-yellow-400 transition-all"
                  />
                </div>
              </div>
            </div>

            {/* Tipo de Análise */}
            <div className="mb-6">
              <h3 className="text-xl font-bold text-yellow-400 mb-4 tracking-wide">Análise</h3>
              <select className="w-full bg-green-800/30 border border-yellow-500/30 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-yellow-400 focus:ring-2 focus:ring-yellow-400/50 transition-all">
                <option>Análise NDVI</option>
                <option>Análise EVI</option>
                <option>Análise SAVI</option>
                <option>Detecção de Mudanças</option>
                <option>Saúde da Vegetação</option>
              </select>
            </div>

            {/* Botão Principal */}
            <button className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-bold py-4 rounded-xl transition-all duration-200 transform hover:scale-[1.02] shadow-lg hover:shadow-xl border border-green-500/30">
              Iniciar Análise
            </button>

            {/* Status */}
            <div className="mt-6 p-4 bg-green-900/30 rounded-xl border border-yellow-500/30 backdrop-blur-sm">
              <h4 className="text-sm text-yellow-400 font-bold mb-3 tracking-wide">Status</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-green-300">Resolução:</span>
                  <span className="text-green-400 font-medium">10m</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-green-300">Nuvens:</span>
                  <span className="text-green-400 font-medium">&lt; 20%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-green-300">Período:</span>
                  <span className="text-yellow-400 font-medium">30 dias</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Área do Mapa */}
        <div className="flex-1 relative">
          <div className="h-full w-full bg-gradient-to-br from-green-900/20 via-slate-800 to-green-900/20 flex items-center justify-center border border-yellow-500/30 m-6 rounded-2xl shadow-2xl">
            <div className="text-center">
              <div className="w-32 h-32 mx-auto mb-8 relative">
                {/* Satélite Grande Central - Baseado na Imagem */}
                <div className="relative w-full h-full">
                  <div className="absolute inset-0 bg-gradient-to-br from-green-600/20 to-yellow-600/20 rounded-full animate-pulse"></div>
                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                    {/* Corpo principal do satélite */}
                    <div className="w-16 h-24 bg-gradient-to-b from-slate-100 via-slate-200 to-slate-300 rounded-lg border border-slate-400 relative shadow-2xl">
                      
                      {/* Painéis solares grandes */}
                      <div className="absolute top-4 -left-10 w-8 h-16 bg-gradient-to-br from-blue-800 via-blue-600 to-blue-800 rounded border border-blue-900 shadow-xl">
                        <div className="absolute top-2 left-1 w-6 h-12 bg-blue-500 opacity-30 rounded"></div>
                        <div className="absolute top-3 left-2 w-1 h-10 bg-blue-400 opacity-50"></div>
                        <div className="absolute top-3 left-4 w-1 h-10 bg-blue-400 opacity-50"></div>
                      </div>
                      <div className="absolute top-4 -right-10 w-8 h-16 bg-gradient-to-bl from-blue-800 via-blue-600 to-blue-800 rounded border border-blue-900 shadow-xl">
                        <div className="absolute top-2 right-1 w-6 h-12 bg-blue-500 opacity-30 rounded"></div>
                        <div className="absolute top-3 right-2 w-1 h-10 bg-blue-400 opacity-50"></div>
                        <div className="absolute top-3 right-4 w-1 h-10 bg-blue-400 opacity-50"></div>
                      </div>
                      
                      {/* Antena principal */}
                      <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 w-1 h-10 bg-gradient-to-t from-yellow-600 to-yellow-300 shadow-lg"></div>
                      <div className="absolute -top-10 left-1/2 transform -translate-x-1/2 w-6 h-1 bg-yellow-400 rounded-full shadow-lg"></div>
                      
                      {/* Antena parabólica */}
                      <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 w-4 h-4 bg-gradient-to-br from-yellow-300 to-yellow-500 rounded-full border border-yellow-600 shadow-lg"></div>
                      
                      {/* Detalhes do corpo */}
                      <div className="absolute top-2 left-2 w-12 h-2 bg-slate-400 rounded opacity-80"></div>
                      <div className="absolute top-5 left-2 w-12 h-2 bg-slate-400 rounded opacity-80"></div>
                      <div className="absolute top-8 left-2 w-12 h-2 bg-slate-400 rounded opacity-80"></div>
                      
                      {/* Luzes de status */}
                      <div className="absolute top-3 left-6 w-2 h-2 bg-green-400 rounded-full animate-pulse shadow-lg"></div>
                      <div className="absolute top-6 left-6 w-1.5 h-1.5 bg-red-400 rounded-full animate-pulse shadow-lg" style={{animationDelay: '0.5s'}}></div>
                      <div className="absolute top-9 left-6 w-1 h-1 bg-blue-400 rounded-full animate-pulse shadow-lg" style={{animationDelay: '1s'}}></div>
                      
                      {/* Sensores */}
                      <div className="absolute top-3 right-2 w-2 h-2 bg-yellow-400 rounded-full shadow-lg"></div>
                      <div className="absolute top-6 right-2 w-2 h-2 bg-yellow-400 rounded-full shadow-lg"></div>
                      
                      {/* Parte inferior do satélite */}
                      <div className="absolute bottom-2 left-2 w-12 h-3 bg-gradient-to-b from-slate-300 to-slate-400 rounded border border-slate-500"></div>
                    </div>
                  </div>
                </div>
              </div>
              
              <h3 className="text-3xl font-bold text-white mb-3 tracking-wide">Interface Satelital</h3>
              <p className="text-green-300 mb-6 text-lg">Selecione uma área no mapa para análise</p>
              
              <div className="bg-green-900/30 backdrop-blur-sm rounded-2xl border border-yellow-500/30 p-6 max-w-md mx-auto shadow-xl">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="text-center">
                    <div className="w-4 h-4 bg-green-400 rounded-full mx-auto mb-2 animate-pulse shadow-lg"></div>
                    <span className="text-green-300 font-bold">ATIVO</span>
                  </div>
                  <div className="text-center">
                    <div className="w-4 h-4 bg-yellow-400 rounded-full mx-auto mb-2 animate-pulse shadow-lg"></div>
                    <span className="text-yellow-300 font-bold">PRONTO</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Ferramentas (Direita) */}
        <div className="w-72 bg-gradient-to-b from-green-900/30 to-green-900/50 border-l border-yellow-500/30 backdrop-blur-sm">
          <div className="p-6">
            <h3 className="text-xl font-bold text-yellow-400 mb-6 tracking-wide">Ferramentas</h3>
            <div className="space-y-4">
              <button className="w-full bg-green-800/30 hover:bg-green-700/50 text-white py-4 rounded-xl transition-all duration-200 border border-yellow-500/30 hover:border-yellow-400 hover:shadow-lg font-medium">
                Seleção Poligonal
              </button>
              <button className="w-full bg-green-800/30 hover:bg-green-700/50 text-white py-4 rounded-xl transition-all duration-200 border border-yellow-500/30 hover:border-yellow-400 hover:shadow-lg font-medium">
                Seleção Retangular
              </button>
              <button className="w-full bg-red-800/30 hover:bg-red-700/50 text-white py-4 rounded-xl transition-all duration-200 border border-red-500/30 hover:border-red-400 hover:shadow-lg font-medium">
                Limpar Seleção
              </button>
            </div>

            <div className="mt-8 p-4 bg-green-900/30 rounded-xl border border-yellow-500/30 backdrop-blur-sm shadow-lg">
              <h4 className="text-sm text-yellow-400 font-bold mb-4 tracking-wide">Área Selecionada</h4>
              <div className="text-sm text-green-300 space-y-2">
                <div className="flex justify-between">
                  <span>Tamanho:</span>
                  <span className="text-white">--</span>
                </div>
                <div className="flex justify-between">
                  <span>Coordenadas:</span>
                  <span className="text-white">--</span>
                </div>
                <div className="flex justify-between">
                  <span>Tipo:</span>
                  <span className="text-white">--</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}