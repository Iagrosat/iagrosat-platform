'use client';

import { useState } from 'react';
import { MapContainer } from '@/components/map-container';

export default function DesignOption3() {
  const [selectedLocation, setSelectedLocation] = useState<{lat: number, lon: number} | null>(null);
  const [selectedAreaData, setSelectedAreaData] = useState<{area: number, coordinates: number[][]} | null>(null);

  return (
    <div className="min-h-screen bg-white">
      {/* Modern Enterprise Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <div className="w-10 h-10 bg-gradient-to-br from-green-600 to-green-800 rounded-lg flex items-center justify-center shadow-lg">
                  <div className="w-4 h-4 bg-amber-400 rounded-full relative">
                    <div className="absolute inset-0 bg-amber-400 rounded-full animate-ping opacity-75"></div>
                  </div>
                </div>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">iAgroSat</h1>
                <p className="text-green-600 text-sm font-medium">Satellite Intelligence Platform</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-gray-600 text-sm">Connected</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-amber-500 rounded-full animate-pulse"></div>
                <span className="text-gray-600 text-sm">Processing</span>
              </div>
              <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium">
                Analytics Dashboard
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex h-[calc(100vh-88px)]">
        {/* Sidebar */}
        <div className="w-80 bg-gray-50 border-r border-gray-200">
          <div className="p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-6">Analysis Workspace</h2>
            
            {/* Location Input */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search location or enter coordinates..."
                  className="w-full bg-white border border-gray-300 rounded-lg px-4 py-3 text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
                <button className="absolute right-3 top-3 text-gray-400 hover:text-green-600">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </button>
              </div>
            </div>

            {/* Area Selection */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-3">Area Selection</label>
              <div className="grid grid-cols-2 gap-3">
                <button className="px-4 py-3 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 hover:border-green-500 transition-colors text-gray-700 font-medium">
                  Polygon
                </button>
                <button className="px-4 py-3 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 hover:border-green-500 transition-colors text-gray-700 font-medium">
                  Rectangle
                </button>
              </div>
            </div>

            {/* Analysis Configuration */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-3">Analysis Type</label>
              <div className="space-y-2">
                <label className="flex items-center">
                  <input type="radio" name="analysis" value="ndvi" className="text-green-600 focus:ring-green-500" defaultChecked />
                  <span className="ml-2 text-gray-700">NDVI - Vegetation Index</span>
                </label>
                <label className="flex items-center">
                  <input type="radio" name="analysis" value="evi" className="text-green-600 focus:ring-green-500" />
                  <span className="ml-2 text-gray-700">EVI - Enhanced Vegetation</span>
                </label>
                <label className="flex items-center">
                  <input type="radio" name="analysis" value="savi" className="text-green-600 focus:ring-green-500" />
                  <span className="ml-2 text-gray-700">SAVI - Soil Adjusted</span>
                </label>
                <label className="flex items-center">
                  <input type="radio" name="analysis" value="change" className="text-green-600 focus:ring-green-500" />
                  <span className="ml-2 text-gray-700">Change Detection</span>
                </label>
              </div>
            </div>

            {/* Date Range */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">Date Range</label>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="date"
                  className="bg-white border border-gray-300 rounded-lg px-3 py-2 text-gray-900 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
                <input
                  type="date"
                  className="bg-white border border-gray-300 rounded-lg px-3 py-2 text-gray-900 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
            </div>

            {/* Execute Button */}
            <button className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-semibold py-3 rounded-lg transition-all duration-200 transform hover:scale-[1.02] shadow-lg">
              Run Analysis
            </button>
          </div>
        </div>

        {/* Map Area */}
        <div className="flex-1 relative bg-gray-100 rounded-lg m-6">
          <div className="h-full w-full flex items-center justify-center">
            <div className="text-center">
              <div className="text-6xl mb-4 text-green-600">🌍</div>
              <h3 className="text-2xl font-semibold text-gray-900 mb-2">Interactive Map</h3>
              <p className="text-gray-600">Modern satellite imagery interface</p>
              <div className="mt-6 bg-white rounded-xl shadow-lg border border-gray-200 p-6 max-w-md mx-auto">
                <h4 className="text-gray-900 font-semibold mb-3">Map Features:</h4>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-gray-700">Satellite layers</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span className="text-gray-700">Area tools</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-amber-500 rounded-full"></div>
                    <span className="text-gray-700">Search</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                    <span className="text-gray-700">Analytics</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}