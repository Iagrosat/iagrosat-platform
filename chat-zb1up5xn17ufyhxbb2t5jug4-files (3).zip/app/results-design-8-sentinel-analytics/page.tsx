'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ArrowLeft, Satellite, Database, Zap, BarChart3 } from 'lucide-react'
import { useRouter } from 'next/navigation'

export default function SentinelAnalyticsResults() {
  const router = useRouter()
  const [selectedBand, setSelectedBand] = useState('rgb')

  const sentinelBands = {
    rgb: { name: 'RGB Natural', description: 'Cores naturais visíveis', bands: 'B4, B3, B2' },
    nir: { name: 'Infravermelho', description: 'Vegetação em destaque', bands: 'B8, B4, B3' },
    swir: { name: 'SWIR', description: 'Análise de umidade', bands: 'B12, B8A, B4' },
    ndvi: { name: 'NDVI', description: 'Índice de vegetação', bands: '(B8-B4)/(B8+B4)' }
  }

  const analyticsData = [
    { 
      category: 'Cobertura Vegetal',
      value: '73.4%',
      change: '+2.1%',
      status: 'up',
      color: 'text-green-400',
      icon: '🌿'
    },
    { 
      category: 'Solo Exposto',
      value: '18.2%',
      change: '-1.3%',
      status: 'down',
      color: 'text-amber-400',
      icon: '🌍'
    },
    { 
      category: 'Corpos d\'Água',
      value: '5.8%',
      change: '+0.2%',
      status: 'up',
      color: 'text-blue-400',
      icon: '💧'
    },
    { 
      category: 'Área Urbana',
      value: '2.6%',
      change: '+0.1%',
      status: 'stable',
      color: 'text-slate-400',
      icon: '🏢'
    }
  ]

  const processingStats = [
    { label: 'Pixels Processados', value: '2.847.392', unit: 'px' },
    { label: 'Área Analisada', value: '1.234', unit: 'km²' },
    { label: 'Resolução Espacial', value: '10', unit: 'm' },
    { label: 'Precisão', value: '94.7', unit: '%' }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-900">
      {/* Header */}
      <header className="bg-slate-900/98 backdrop-blur-md border-b border-blue-500/20 p-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center space-x-4">
            <Button
              variant="outline"
              onClick={() => router.push('/')}
              className="flex items-center gap-2 bg-slate-800/80 border-blue-500/30 text-blue-400 hover:bg-slate-700/80"
            >
              <ArrowLeft className="h-4 w-4" />
              Voltar
            </Button>
            <div className="flex items-center space-x-3">
              <div className="relative w-12 h-12">
                <div className="absolute inset-0 bg-gradient-to-br from-blue-400 to-cyan-600 rounded-lg opacity-20 animate-pulse"></div>
                <div className="absolute inset-1 bg-gradient-to-br from-blue-400 to-cyan-600 rounded-lg flex items-center justify-center">
                  <Database className="h-6 w-6 text-white" />
                </div>
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">Sentinel Analytics</h1>
                <p className="text-blue-400 text-sm">Advanced Earth Observation Platform</p>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-3">
              <Satellite className="h-5 w-5 text-blue-400" />
              <div className="text-right">
                <div className="text-white text-sm font-mono">SENTINEL-2A</div>
                <div className="text-blue-400 text-xs">ESA Copernicus Program</div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="p-6 max-w-7xl mx-auto">
        {/* Processing Summary */}
        <div className="bg-slate-900/90 backdrop-blur-md rounded-xl border border-blue-500/20 p-6 mb-6">
          <div className="grid md:grid-cols-4 gap-6">
            {processingStats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-2xl font-bold text-blue-400 font-mono">
                  {stat.value}
                  <span className="text-lg text-slate-400 ml-1">{stat.unit}</span>
                </div>
                <div className="text-slate-400 text-sm mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Main Grid */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Band Selection & Analysis */}
          <div className="lg:col-span-2">
            <Card className="bg-slate-900/90 border-blue-500/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <BarChart3 className="h-5 w-5 mr-2 text-blue-400" />
                  Análise Espectral Multi-Band
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs value={selectedBand} onValueChange={setSelectedBand} className="w-full">
                  <TabsList className="grid w-full grid-cols-4 bg-slate-800/60 border border-blue-500/30">
                    {Object.entries(sentinelBands).map(([key, band]) => (
                      <TabsTrigger 
                        key={key} 
                        value={key} 
                        className="data-[state=active]:bg-blue-600 data-[state=active]:text-white text-xs"
                      >
                        {band.name}
                      </TabsTrigger>
                    ))}
                  </TabsList>
                  
                  {Object.entries(sentinelBands).map(([key, band]) => (
                    <TabsContent key={key} value={key} className="mt-4">
                      <div className="bg-slate-800/60 rounded-lg border border-slate-700/50 p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div>
                            <div className="text-white font-semibold">{band.name}</div>
                            <div className="text-slate-400 text-sm">{band.description}</div>
                          </div>
                          <Badge variant="outline" className="text-blue-400 border-blue-400/30 font-mono">
                            {band.bands}
                          </Badge>
                        </div>
                        
                        {/* Simulated spectral chart */}
                        <div className="h-32 bg-slate-950/80 rounded border border-slate-700 p-4 flex items-end justify-center space-x-1">
                          {[...Array(20)].map((_, i) => (
                            <div 
                              key={i} 
                              className="bg-gradient-to-t from-blue-600 to-cyan-400 w-4 rounded-t opacity-70"
                              style={{ height: `${Math.random() * 80 + 20}%` }}
                            ></div>
                          ))}
                        </div>
                        
                        <div className="mt-3 text-center text-slate-400 text-xs">
                          Reflectância Espectral - Assinatura da Área Analisada
                        </div>
                      </div>
                    </TabsContent>
                  ))}
                </Tabs>
              </CardContent>
            </Card>
          </div>

          {/* Land Cover Analysis */}
          <div className="space-y-6">
            <Card className="bg-slate-900/90 border-blue-500/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Zap className="h-5 w-5 mr-2 text-blue-400" />
                  Classificação de Uso do Solo
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {analyticsData.map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-slate-800/60 rounded-lg border border-slate-700/50">
                    <div className="flex items-center space-x-3">
                      <span className="text-lg">{item.icon}</span>
                      <div>
                        <div className="text-white text-sm font-medium">{item.category}</div>
                        <div className={`text-xs ${item.color}`}>{item.value}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className={`text-sm font-mono ${
                        item.status === 'up' ? 'text-green-400' : 
                        item.status === 'down' ? 'text-red-400' : 'text-slate-400'
                      }`}>
                        {item.change}
                      </div>
                      <div className="text-xs text-slate-400">vs. anterior</div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="bg-slate-900/90 border-blue-500/20">
              <CardHeader>
                <CardTitle className="text-white">Métricas de Qualidade</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-400">Cobertura de Nuvens:</span>
                  <span className="text-green-400 font-mono">2.3%</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-400">Qualidade Radiométrica:</span>
                  <span className="text-blue-400 font-mono">Excelente</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-400">Acurácia Geométrica:</span>
                  <span className="text-cyan-400 font-mono">±3.2m</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-400">Data de Aquisição:</span>
                  <span className="text-white font-mono">{new Date().toLocaleDateString('pt-BR')}</span>
                </div>
                
                <div className="mt-4 pt-4 border-t border-slate-700">
                  <div className="text-slate-400 text-xs mb-2">Processamento</div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                    <span className="text-green-400 text-xs">Completo</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Technical Details */}
        <Card className="bg-slate-900/90 border-blue-500/20 mt-6">
          <CardHeader>
            <CardTitle className="text-white">Detalhes Técnicos da Missão</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-6 text-sm">
              <div>
                <div className="text-blue-400 font-semibold mb-2">Plataforma</div>
                <div className="text-slate-300">Sentinel-2A/2B</div>
                <div className="text-slate-400 text-xs">ESA Copernicus</div>
              </div>
              <div>
                <div className="text-blue-400 font-semibold mb-2">Instrumento</div>
                <div className="text-slate-300">MSI (MultiSpectral)</div>
                <div className="text-slate-400 text-xs">13 bandas espectrais</div>
              </div>
              <div>
                <div className="text-blue-400 font-semibold mb-2">Órbita</div>
                <div className="text-slate-300">Heliossíncrona</div>
                <div className="text-slate-400 text-xs">786 km altitude</div>
              </div>
              <div>
                <div className="text-blue-400 font-semibold mb-2">Revisita</div>
                <div className="text-slate-300">5 dias</div>
                <div className="text-slate-400 text-xs">Com ambos satélites</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}