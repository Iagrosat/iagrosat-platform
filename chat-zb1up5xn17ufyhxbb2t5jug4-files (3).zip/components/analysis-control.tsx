"use client"

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Satellite, MapPin, Play, AlertCircle } from 'lucide-react'
import { Alert, AlertDescription } from '@/components/ui/alert'

interface AnalysisControlProps {
  selectedCoordinates: {lat: number, lon: number} | null
  selectedArea?: any
  onJobStart: (jobId: string) => void
  onAnalysisComplete: (results: any) => void
}

export function AnalysisControl({ selectedCoordinates, selectedArea, onJobStart, onAnalysisComplete }: AnalysisControlProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [aoiData, setAoiData] = useState('')
  const [validationError, setValidationError] = useState<string | null>(null)

  console.log("AnalysisControl rendered", { selectedCoordinates, isLoading })

  const handleStartAnalysis = async () => {
    if (!selectedCoordinates) {
      console.log("No coordinates selected")
      return
    }

    // Clear any previous validation errors
    setValidationError(null)
    setIsLoading(true)
    console.log("Starting analysis", selectedCoordinates)

    try {
      // Use the same approach as the working left button
      console.log("🚀 Starting analysis from right panel button")
      
      // Direct API call like the working approach
      const response = await fetch(`/api/full-report?lat=${selectedCoordinates.lat}&lon=${selectedCoordinates.lon}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          lat: selectedCoordinates.lat,
          lon: selectedCoordinates.lon
        }),
      })
      
      if (!response.ok) {
        throw new Error(`Backend error: ${response.status}`)
      }
      
      const data = await response.json()
      console.log('✅ Analysis started:', data)
      
      if (data.job_id) {
        console.log("✅ BACKEND RETURNED JOB ID:", data.job_id)
        onJobStart(data.job_id)
        // Navigate to results page
        window.location.href = `/results/${data.job_id}`
      }
    } catch (error) {
      console.error("❌ Analysis failed:", error)
      alert(`❌ Erro ao iniciar análise: ${error.message}. Tente novamente.`)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Satellite className="h-5 w-5 text-iagrosat-primary" />
            <span>Análise Sentinel-2</span>
          </CardTitle>
          <CardDescription>
            Configure e inicie a análise espectral para a área selecionada
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Coordenadas selecionadas */}
          {selectedCoordinates ? (
            <div className="space-y-2">
              <div className="flex items-center space-x-2 p-3 bg-iagrosat-background rounded-lg">
                <MapPin className="h-4 w-4 text-iagrosat-primary" />
                <div className="font-mono text-sm">
                  <div>Centro - Lat: {selectedCoordinates.lat.toFixed(6)}</div>
                  <div>Centro - Lon: {selectedCoordinates.lon.toFixed(6)}</div>
                </div>
              </div>
              {selectedArea && selectedArea.type !== 'point' && (
                <div className="p-3 bg-iagrosat-surface rounded-lg border border-iagrosat-border">
                  <div className="text-xs text-iagrosat-muted mb-1">Área de Análise:</div>
                  <div className="text-sm text-iagrosat-text">
                    {selectedArea.type === 'rectangle' && `Retângulo com ${(selectedArea.coordinates as any[]).length} pontos`}
                    {selectedArea.type === 'polygon' && `Polígono com ${(selectedArea.coordinates as any[]).length} pontos`}
                    {selectedArea.type === 'line' && `Linha com ${(selectedArea.coordinates as any[]).length} pontos`}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Selecione um ponto no mapa para iniciar a análise
              </AlertDescription>
            </Alert>
          )}

          {/* Validation Error */}
          {validationError && (
            <Alert className="border-red-600 bg-red-50">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800 whitespace-pre-line text-sm">
                {validationError}
              </AlertDescription>
            </Alert>
          )}

          {/* Área de interesse customizada */}
          <div className="space-y-2">
            <Label htmlFor="aoi">Área de Interesse (AOI) - Opcional</Label>
            <Textarea
              id="aoi"
              placeholder="Cole aqui o GeoJSON da área customizada (opcional)"
              value={aoiData}
              onChange={(e) => setAoiData(e.target.value)}
              className="font-mono text-xs"
              rows={4}
            />
          </div>

          {/* Botão de análise */}
          <Button
            onClick={handleStartAnalysis}
            disabled={!selectedCoordinates || isLoading}
            className="w-full"
            size="lg"
          >
            <Play className="h-4 w-4 mr-2" />
            {isLoading ? 'Iniciando Análise...' : 'Iniciar Análise Espectral'}
          </Button>
        </CardContent>
      </Card>

      {/* Informações da análise */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">O que será analisado?</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-iagrosat-ndvi rounded-full"></div>
              <span><strong>NDVI</strong> - Índice de Vegetação por Diferença Normalizada</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-iagrosat-evi rounded-full"></div>
              <span><strong>EVI</strong> - Índice de Vegetação Melhorado</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-iagrosat-savi rounded-full"></div>
              <span><strong>SAVI</strong> - Índice de Vegetação Ajustado ao Solo</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-iagrosat-gci rounded-full"></div>
              <span><strong>GCI</strong> - Índice de Clorofila Verde</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}