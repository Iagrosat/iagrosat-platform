"use client";

import { useState } from 'react';
import { useAuth } from '@/contexts/auth-context';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Loader2, Lock, Mail, Shield, Users, BarChart3, Eye } from 'lucide-react';

export function LoginForm() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [showDemoAccounts, setShowDemoAccounts] = useState(false);
  const { login, loading } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    const success = await login(email, password);
    if (!success) {
      setError('Credenciais inválidas. Verifique email e senha.');
    }
  };

  const demoAccounts = [
    {
      email: 'admin@iagrosat.com',
      role: 'Super Admin',
      icon: Shield,
      color: 'bg-red-500',
      description: 'Acesso total ao sistema'
    },
    {
      email: 'manager@iagrosat.com',
      role: 'Manager',
      icon: Users,
      color: 'bg-blue-500',
      description: 'Gerenciar equipes e análises'
    },
    {
      email: 'analyst@iagrosat.com',
      role: 'Analyst',
      icon: BarChart3,
      color: 'bg-green-500',
      description: 'Criar e exportar análises'
    },
    {
      email: 'viewer@iagrosat.com',
      role: 'Viewer',
      icon: Eye,
      color: 'bg-gray-500',
      description: 'Apenas visualizar dados'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        {/* Logo/Brand */}
        <div className="text-center">
          <div className="mx-auto w-16 h-16 bg-gradient-to-br from-green-400 to-blue-500 rounded-xl flex items-center justify-center mb-4">
            <div className="text-white font-bold text-2xl">iA</div>
          </div>
          <h1 className="text-3xl font-bold text-white">iAgroSat</h1>
          <p className="text-slate-400 mt-2">Enterprise Satellite Analysis Platform</p>
        </div>

        {/* Login Card */}
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white text-center">
              <Lock className="w-5 h-5 mx-auto mb-2" />
              Acesso Empresarial
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-slate-300">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="seu@empresa.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10 bg-slate-900/50 border-slate-600 text-white placeholder-slate-400"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-slate-300">Senha</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                  <Input
                    id="password"
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 bg-slate-900/50 border-slate-600 text-white placeholder-slate-400"
                    required
                  />
                </div>
              </div>

              {error && (
                <Alert className="bg-red-900/20 border-red-500/50">
                  <AlertDescription className="text-red-300">
                    {error}
                  </AlertDescription>
                </Alert>
              )}

              <Button 
                type="submit" 
                className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Entrando...
                  </>
                ) : (
                  'Entrar'
                )}
              </Button>
            </form>

            {/* Demo Accounts Toggle */}
            <div className="text-center">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowDemoAccounts(!showDemoAccounts)}
                className="text-slate-400 hover:text-white"
              >
                {showDemoAccounts ? 'Ocultar' : 'Mostrar'} Contas Demo
              </Button>
            </div>

            {/* Demo Accounts */}
            {showDemoAccounts && (
              <div className="space-y-3 pt-4 border-t border-slate-700">
                <p className="text-sm text-slate-400 text-center">
                  Contas de demonstração (senha: <code className="bg-slate-900 px-1 rounded">admin123</code>)
                </p>
                {demoAccounts.map((account) => (
                  <div
                    key={account.email}
                    className="flex items-center justify-between p-3 bg-slate-900/30 rounded-lg cursor-pointer hover:bg-slate-900/50 transition-colors"
                    onClick={() => {
                      setEmail(account.email);
                      setPassword('admin123');
                    }}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 ${account.color} rounded-lg flex items-center justify-center`}>
                        <account.icon className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-white">{account.role}</div>
                        <div className="text-xs text-slate-400">{account.email}</div>
                      </div>
                    </div>
                    <Badge variant="outline" className="text-xs border-slate-600 text-slate-400">
                      Demo
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Security Notice */}
        <div className="text-center text-xs text-slate-500">
          <p>🔒 Conexão segura e dados criptografados</p>
          <p>© 2024 iAgroSat Enterprise. Todos os direitos reservados.</p>
        </div>
      </div>
    </div>
  );
}