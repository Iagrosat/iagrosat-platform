"use client";

import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Shield, 
  Users, 
  BarChart3, 
  Lock, 
  Zap, 
  Globe,
  ArrowRight
} from 'lucide-react';
import Link from 'next/link';

export function EnterpriseBanner() {
  return (
    <div className="w-full bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border-b border-slate-700">
      <div className="container mx-auto px-4 py-6">
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-6">
                <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-blue-500 rounded-xl flex items-center justify-center">
                  <div className="text-white font-bold text-2xl">iA</div>
                </div>
                
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <h2 className="text-2xl font-bold text-white">iAgroSat Enterprise</h2>
                    <Badge variant="outline" className="border-green-500 text-green-400">
                      <Shield className="w-3 h-3 mr-1" />
                      Segurança Avançada
                    </Badge>
                  </div>
                  <p className="text-slate-400 mb-4">
                    Plataforma empresarial com controle de acesso, auditoria e recursos avançados
                  </p>
                  
                  <div className="flex items-center gap-6 text-sm">
                    <div className="flex items-center gap-2 text-slate-300">
                      <Users className="w-4 h-4" />
                      <span>Gerenciamento de Usuários</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-300">
                      <BarChart3 className="w-4 h-4" />
                      <span>Dashboard Avançado</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-300">
                      <Lock className="w-4 h-4" />
                      <span>Controle de Permissões</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-300">
                      <Zap className="w-4 h-4" />
                      <span>Auditoria Completa</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex flex-col gap-3">
                <Link href="/enterprise">
                  <Button 
                    className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white px-6 py-3"
                    size="lg"
                  >
                    Acessar Enterprise
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
                
                <div className="text-center">
                  <p className="text-xs text-slate-500">
                    Contas demo disponíveis
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}