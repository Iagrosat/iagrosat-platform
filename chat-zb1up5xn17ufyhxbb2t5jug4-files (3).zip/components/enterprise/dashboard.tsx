"use client";

import { useState } from 'react';
import { useAuth } from '@/contexts/auth-context';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  BarChart3, 
  Users, 
  Shield, 
  Settings, 
  TrendingUp, 
  MapPin, 
  Calendar,
  Download,
  Activity,
  AlertTriangle,
  CheckCircle,
  Clock,
  Database,
  Globe,
  Zap
} from 'lucide-react';
import { Permission } from '@/types/auth';

export function Dashboard() {
  const { user, hasPermission } = useAuth();
  const [selectedTimeRange, setSelectedTimeRange] = useState('7d');

  // Mock data for dashboard
  const stats = {
    totalAnalyses: 1247,
    monthlyAnalyses: 89,
    activeUsers: 24,
    storageUsed: '2.4 TB',
    successRate: 98.7,
    avgProcessTime: '3.2 min'
  };

  const recentAnalyses = [
    {
      id: 'a1',
      location: 'São Paulo, SP',
      type: 'NDVI Analysis',
      user: 'Ana Santos',
      status: 'completed',
      timestamp: '2024-07-04T15:30:00Z',
      coordinates: '-23.5505, -46.6333'
    },
    {
      id: 'a2',
      location: 'Rio de Janeiro, RJ',
      type: 'EVI Analysis',
      user: 'Carlos Silva',
      status: 'processing',
      timestamp: '2024-07-04T14:45:00Z',
      coordinates: '-22.9068, -43.1729'
    },
    {
      id: 'a3',
      location: 'Brasília, DF',
      type: 'SAVI Analysis',
      user: 'João Oliveira',
      status: 'completed',
      timestamp: '2024-07-04T13:15:00Z',
      coordinates: '-15.7942, -47.8822'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-500';
      case 'processing': return 'bg-blue-500';
      case 'failed': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return CheckCircle;
      case 'processing': return Clock;
      case 'failed': return AlertTriangle;
      default: return Activity;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white">Dashboard Empresarial</h1>
            <p className="text-slate-400 mt-1">Análise espectral de satélites em tempo real</p>
          </div>
          <div className="flex items-center gap-4">
            <Badge variant="outline" className="border-green-500 text-green-400">
              <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
              Sistema Online
            </Badge>
            <div className="flex items-center gap-2">
              <Avatar className="w-8 h-8">
                <AvatarImage src={user?.avatar} />
                <AvatarFallback>{user?.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
              </Avatar>
              <div className="text-right">
                <p className="text-sm font-medium text-white">{user?.name}</p>
                <p className="text-xs text-slate-400">{user?.role}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-400">Total Análises</p>
                  <p className="text-2xl font-bold text-white">{stats.totalAnalyses}</p>
                </div>
                <BarChart3 className="w-8 h-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-400">Este Mês</p>
                  <p className="text-2xl font-bold text-white">{stats.monthlyAnalyses}</p>
                </div>
                <TrendingUp className="w-8 h-8 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-400">Usuários Ativos</p>
                  <p className="text-2xl font-bold text-white">{stats.activeUsers}</p>
                </div>
                <Users className="w-8 h-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-400">Armazenamento</p>
                  <p className="text-2xl font-bold text-white">{stats.storageUsed}</p>
                </div>
                <Database className="w-8 h-8 text-orange-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-400">Taxa Sucesso</p>
                  <p className="text-2xl font-bold text-white">{stats.successRate}%</p>
                </div>
                <CheckCircle className="w-8 h-8 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-400">Tempo Médio</p>
                  <p className="text-2xl font-bold text-white">{stats.avgProcessTime}</p>
                </div>
                <Zap className="w-8 h-8 text-yellow-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="analytics" className="space-y-4">
          <TabsList className="bg-slate-800/50 border-slate-700">
            <TabsTrigger value="analytics">Análises</TabsTrigger>
            {hasPermission(Permission.VIEW_USERS) && (
              <TabsTrigger value="users">Usuários</TabsTrigger>
            )}
            {hasPermission(Permission.VIEW_AUDIT_LOGS) && (
              <TabsTrigger value="audit">Auditoria</TabsTrigger>
            )}
            {hasPermission(Permission.MANAGE_SETTINGS) && (
              <TabsTrigger value="settings">Configurações</TabsTrigger>
            )}
          </TabsList>

          <TabsContent value="analytics" className="space-y-4">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Activity className="w-5 h-5" />
                  Análises Recentes
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {recentAnalyses.map((analysis) => {
                    const StatusIcon = getStatusIcon(analysis.status);
                    return (
                      <div
                        key={analysis.id}
                        className="flex items-center justify-between p-3 bg-slate-900/30 rounded-lg hover:bg-slate-900/50 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-3 h-3 ${getStatusColor(analysis.status)} rounded-full`}></div>
                          <div>
                            <div className="flex items-center gap-2">
                              <p className="font-medium text-white">{analysis.type}</p>
                              <Badge variant="outline" className="text-xs border-slate-600 text-slate-400">
                                {analysis.location}
                              </Badge>
                            </div>
                            <p className="text-sm text-slate-400">
                              por {analysis.user} • {new Date(analysis.timestamp).toLocaleString('pt-BR')}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <StatusIcon className="w-4 h-4 text-slate-400" />
                          <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                            Ver Resultado
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {hasPermission(Permission.VIEW_USERS) && (
            <TabsContent value="users">
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Gerenciamento de Usuários</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-400">Sistema de gerenciamento de usuários em desenvolvimento...</p>
                </CardContent>
              </Card>
            </TabsContent>
          )}

          {hasPermission(Permission.VIEW_AUDIT_LOGS) && (
            <TabsContent value="audit">
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Logs de Auditoria</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-400">Sistema de auditoria em desenvolvimento...</p>
                </CardContent>
              </Card>
            </TabsContent>
          )}

          {hasPermission(Permission.MANAGE_SETTINGS) && (
            <TabsContent value="settings">
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Configurações do Sistema</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-400">Configurações avançadas em desenvolvimento...</p>
                </CardContent>
              </Card>
            </TabsContent>
          )}
        </Tabs>
      </div>
    </div>
  );
}