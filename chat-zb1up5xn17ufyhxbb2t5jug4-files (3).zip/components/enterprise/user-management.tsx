"use client";

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Users, 
  Search, 
  UserPlus, 
  Edit, 
  Trash2,
  Shield,
  Mail,
  Calendar,
  MoreHorizontal,
  Eye,
  EyeOff
} from 'lucide-react';
import { User, UserRole } from '@/types/auth';

export function UserManagement() {
  const [users, setUsers] = useState<User[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRole, setSelectedRole] = useState<string>('all');
  const [filteredUsers, setFilteredUsers] = useState<User[]>([]);

  // Mock users data
  useEffect(() => {
    const mockUsers: User[] = [
      {
        id: '1',
        email: 'admin@iagrosat.com',
        name: 'Admin Principal',
        role: UserRole.SUPER_ADMIN,
        company: 'iAgroSat Corp',
        department: 'TI',
        permissions: [],
        createdAt: '2024-01-01T00:00:00Z',
        lastLogin: '2024-07-04T17:30:00Z',
        isActive: true,
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face'
      },
      {
        id: '2',
        email: 'manager@iagrosat.com',
        name: 'Carlos Silva',
        role: UserRole.MANAGER,
        company: 'iAgroSat Corp',
        department: 'Agricultura',
        permissions: [],
        createdAt: '2024-01-15T00:00:00Z',
        lastLogin: '2024-07-04T16:45:00Z',
        isActive: true,
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face'
      },
      {
        id: '3',
        email: 'analyst@iagrosat.com',
        name: 'Ana Santos',
        role: UserRole.ANALYST,
        company: 'iAgroSat Corp',
        department: 'Pesquisa',
        permissions: [],
        createdAt: '2024-02-01T00:00:00Z',
        lastLogin: '2024-07-04T15:20:00Z',
        isActive: true,
        avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face'
      },
      {
        id: '4',
        email: 'viewer@iagrosat.com',
        name: 'João Oliveira',
        role: UserRole.VIEWER,
        company: 'iAgroSat Corp',
        department: 'Operações',
        permissions: [],
        createdAt: '2024-02-15T00:00:00Z',
        lastLogin: '2024-07-04T14:30:00Z',
        isActive: true,
        avatar: 'https://images.unsplash.com/photo-1519244703995-f4e0f30006d5?w=150&h=150&fit=crop&crop=face'
      },
      {
        id: '5',
        email: 'inactive@iagrosat.com',
        name: 'Pedro Costa',
        role: UserRole.ANALYST,
        company: 'iAgroSat Corp',
        department: 'Pesquisa',
        permissions: [],
        createdAt: '2024-03-01T00:00:00Z',
        lastLogin: '2024-06-20T10:00:00Z',
        isActive: false,
        avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&h=150&fit=crop&crop=face'
      }
    ];
    
    setUsers(mockUsers);
    setFilteredUsers(mockUsers);
  }, []);

  useEffect(() => {
    let filtered = users;

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(user =>
        user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.department?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Apply role filter
    if (selectedRole !== 'all') {
      filtered = filtered.filter(user => user.role === selectedRole);
    }

    setFilteredUsers(filtered);
  }, [users, searchTerm, selectedRole]);

  const getRoleColor = (role: UserRole) => {
    switch (role) {
      case UserRole.SUPER_ADMIN: return 'bg-red-500';
      case UserRole.ADMIN: return 'bg-purple-500';
      case UserRole.MANAGER: return 'bg-blue-500';
      case UserRole.ANALYST: return 'bg-green-500';
      case UserRole.VIEWER: return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  const getRoleIcon = (role: UserRole) => {
    switch (role) {
      case UserRole.SUPER_ADMIN: return Shield;
      case UserRole.ADMIN: return Shield;
      case UserRole.MANAGER: return Users;
      case UserRole.ANALYST: return Eye;
      case UserRole.VIEWER: return EyeOff;
      default: return Users;
    }
  };

  const toggleUserStatus = (userId: string) => {
    setUsers(prev => prev.map(user => 
      user.id === userId ? { ...user, isActive: !user.isActive } : user
    ));
  };

  const inviteUser = () => {
    console.log('📧 Inviting new user...');
    // In real app, open invite dialog
  };

  const editUser = (userId: string) => {
    console.log('✏️ Editing user:', userId);
    // In real app, open edit dialog
  };

  const deleteUser = (userId: string) => {
    console.log('🗑️ Deleting user:', userId);
    // In real app, show confirmation dialog
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Gerenciamento de Usuários</h1>
          <p className="text-slate-400">Controle de acesso e permissões de usuários</p>
        </div>
        <Button onClick={inviteUser} className="bg-green-600 hover:bg-green-700">
          <UserPlus className="w-4 h-4 mr-2" />
          Convidar Usuário
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Total Usuários</p>
                <p className="text-2xl font-bold text-white">{users.length}</p>
              </div>
              <Users className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Usuários Ativos</p>
                <p className="text-2xl font-bold text-white">{users.filter(u => u.isActive).length}</p>
              </div>
              <Eye className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Administradores</p>
                <p className="text-2xl font-bold text-white">
                  {users.filter(u => u.role === UserRole.SUPER_ADMIN || u.role === UserRole.ADMIN).length}
                </p>
              </div>
              <Shield className="w-8 h-8 text-red-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Analistas</p>
                <p className="text-2xl font-bold text-white">
                  {users.filter(u => u.role === UserRole.ANALYST).length}
                </p>
              </div>
              <Users className="w-8 h-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
          <Input
            placeholder="Buscar usuários..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-slate-800/50 border-slate-600 text-white"
          />
        </div>
        
        <div className="flex items-center gap-2">
          <Button
            variant={selectedRole === 'all' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedRole('all')}
          >
            Todos
          </Button>
          <Button
            variant={selectedRole === UserRole.SUPER_ADMIN ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedRole(UserRole.SUPER_ADMIN)}
          >
            Super Admin
          </Button>
          <Button
            variant={selectedRole === UserRole.ADMIN ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedRole(UserRole.ADMIN)}
          >
            Admin
          </Button>
          <Button
            variant={selectedRole === UserRole.MANAGER ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedRole(UserRole.MANAGER)}
          >
            Manager
          </Button>
          <Button
            variant={selectedRole === UserRole.ANALYST ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedRole(UserRole.ANALYST)}
          >
            Analyst
          </Button>
        </div>
      </div>

      {/* Users Table */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Users className="w-5 h-5" />
            Usuários
            <Badge variant="outline" className="text-slate-300 border-slate-600">
              {filteredUsers.length} usuários
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {filteredUsers.map((user) => {
              const RoleIcon = getRoleIcon(user.role);
              
              return (
                <div
                  key={user.id}
                  className={`flex items-center justify-between p-4 rounded-lg transition-colors ${
                    user.isActive 
                      ? 'bg-slate-900/30 hover:bg-slate-900/50' 
                      : 'bg-slate-900/20 opacity-75'
                  }`}
                >
                  <div className="flex items-center gap-4">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={user.avatar} />
                      <AvatarFallback>{user.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                    </Avatar>
                    
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-medium text-white">{user.name}</p>
                        <Badge 
                          variant="outline" 
                          className={`text-xs ${getRoleColor(user.role)} border-none text-white`}
                        >
                          <RoleIcon className="w-3 h-3 mr-1" />
                          {user.role}
                        </Badge>
                        {!user.isActive && (
                          <Badge variant="outline" className="text-xs border-red-500 text-red-400">
                            Inativo
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex items-center gap-4 text-sm text-slate-400">
                        <span className="flex items-center gap-1">
                          <Mail className="w-3 h-3" />
                          {user.email}
                        </span>
                        <span>{user.department}</span>
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          Último login: {user.lastLogin ? new Date(user.lastLogin).toLocaleDateString('pt-BR') : 'Nunca'}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => toggleUserStatus(user.id)}
                      className={`${user.isActive ? 'text-red-400 hover:text-red-300' : 'text-green-400 hover:text-green-300'}`}
                    >
                      {user.isActive ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </Button>
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => editUser(user.id)}
                      className="text-slate-400 hover:text-white"
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteUser(user.id)}
                      className="text-slate-400 hover:text-red-400"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-slate-400 hover:text-white"
                    >
                      <MoreHorizontal className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}