'use client'

import { useEffect, useRef } from 'react'

interface LeafletMapProps {
  tilesUrl: string
  center: [number, number]
  jobId: string
}

export default function LeafletMap({ tilesUrl, center, jobId }: LeafletMapProps) {
  const mapRef = useRef<HTMLDivElement>(null)
  const mapInstanceRef = useRef<any>(null)

  useEffect(() => {
    if (!mapRef.current || mapInstanceRef.current) return

    // Dynamic import to avoid SSR issues
    import('leaflet').then((L) => {
      console.log("🗺️ Initializing Leaflet map for job:", jobId)
      console.log("📍 Center coordinates:", center)
      console.log("🔗 Tiles URL:", tilesUrl)

      // Initialize map
      const map = L.map(mapRef.current!, {
        center: center,
        zoom: 15,
        minZoom: 10,
        maxZoom: 18
      })

      // Add base OpenStreetMap layer
      const osmLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        opacity: 0.7
      })
      osmLayer.addTo(map)

      // Add satellite analysis tiles
      const analysisLayer = L.tileLayer(tilesUrl, {
        attribution: '© Satellite Analysis',
        minZoom: 13,
        maxZoom: 17,
        tileSize: 256,
        opacity: 0.8
      })
      analysisLayer.addTo(map)

      // Add layer control
      const baseLayers = {
        "OpenStreetMap": osmLayer
      }
      
      const overlayLayers = {
        "🛰️ Satellite Analysis": analysisLayer
      }

      L.control.layers(baseLayers, overlayLayers).addTo(map)

      // Add marker at center
      const marker = L.marker(center).addTo(map)
      marker.bindPopup(`
        <div style="color: #000;">
          <strong>🎯 Análise Satelital</strong><br/>
          <small>Job: ${jobId}</small><br/>
          <small>Lat: ${center[0].toFixed(6)}</small><br/>
          <small>Lon: ${center[1].toFixed(6)}</small>
        </div>
      `)

      // Add zoom level indicator
      const zoomLevelControl = L.Control.extend({
        onAdd: function() {
          const div = L.DomUtil.create('div', 'leaflet-control-zoom-level')
          div.innerHTML = `Zoom: ${map.getZoom()}`
          
          map.on('zoomend', function() {
            div.innerHTML = `Zoom: ${map.getZoom()}`
          })
          
          return div
        }
      })
      
      map.addControl(new zoomLevelControl({ position: 'bottomright' }))

      mapInstanceRef.current = map

      console.log("✅ Leaflet map initialized successfully")

      // Test tile loading
      analysisLayer.on('tileload', function(e: any) {
        console.log("✅ Tile loaded:", e.url)
      })

      analysisLayer.on('tileerror', function(e: any) {
        console.error("❌ Tile error:", e.url)
      })
    })

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove()
        mapInstanceRef.current = null
      }
    }
  }, [tilesUrl, center, jobId])

  return (
    <div 
      ref={mapRef} 
      className="w-full h-full"
      style={{ minHeight: '400px' }}
    />
  )
}