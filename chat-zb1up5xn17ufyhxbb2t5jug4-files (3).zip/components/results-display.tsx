'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'

interface ResultsDisplayProps {
  jobId: string | null
  isAnalysisComplete: boolean
}

interface AnalysisResults {
  status: string
  resultado?: {
    images?: {
      rgb?: string
      ndvi?: string
      evi?: string
      savi?: string
      gci?: string
      [key: string]: string | undefined
    }
    tiles?: string
    stats?: any
  }
}

export default function ResultsDisplay({ jobId, isAnalysisComplete }: ResultsDisplayProps) {
  const [results, setResults] = useState<AnalysisResults | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const fetchResults = async () => {
    if (!jobId) return
    
    console.log("🔍 Fetching results for job:", jobId)
    setIsLoading(true)
    
    try {
      const response = await fetch(`/api/full-report/status?job_id=${jobId}`)
      const data = await response.json()
      console.log("📊 Results data:", data)
      
      setResults(data)
      
      if (data.status === 'done' && data.resultado) {
        console.log("✅ Analysis complete, results available")
      }
    } catch (error) {
      console.error("❌ Failed to fetch results:", error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    if (isAnalysisComplete && jobId) {
      fetchResults()
    }
  }, [isAnalysisComplete, jobId])

  if (!jobId || !isAnalysisComplete) {
    return null
  }

  const openResultsPage = () => {
    const resultsUrl = `/results?job_id=${jobId}`
    window.open(resultsUrl, '_blank')
    console.log("🔗 Opening results page:", resultsUrl)
  }

  return (
    <div className="space-y-4">
      <Card className="border-moss-600/20 bg-moss-950/80">
        <CardHeader>
          <CardTitle className="text-moss-100 flex items-center gap-2">
            🎯 Análise Concluída
            <Badge variant="outline" className="text-moss-300 border-moss-600">
              Job: {jobId}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {isLoading ? (
            <div className="text-moss-300">Carregando resultados...</div>
          ) : results?.resultado ? (
            <div className="space-y-3">
              <div className="text-moss-200 text-sm">
                ✅ {Object.keys(results.resultado.images || {}).length} imagens geradas
              </div>
              
              {results.resultado.images && (
                <div className="grid grid-cols-2 gap-2 text-xs">
                  {Object.entries(results.resultado.images).map(([key, url]) => (
                    url && (
                      <div key={key} className="text-moss-300 bg-moss-900/50 p-2 rounded">
                        {key.toUpperCase()}: ✅
                      </div>
                    )
                  ))}
                </div>
              )}
              
              <Button 
                onClick={openResultsPage}
                className="w-full bg-moss-600 hover:bg-moss-500 text-white"
              >
                🔍 Ver Resultados Completos
              </Button>
            </div>
          ) : (
            <Button 
              onClick={fetchResults}
              variant="outline" 
              className="w-full border-moss-600 text-moss-300 hover:bg-moss-900/50"
            >
              🔄 Verificar Resultados
            </Button>
          )}
        </CardContent>
      </Card>
    </div>
  )
}