"use client"

import { useState, useEffect, useRef } from 'react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'
import { Separator } from '@/components/ui/separator'
import { MapPin, Navigation, Square, Edit3, Trash2, Play, Search, MousePointer, Map, Target, Coordinates } from 'lucide-react'

// Declare ESRI global types
declare global {
  interface Window {
    require: any;
  }
}

interface MapContainerProps {
  onCoordinateSelect: (coordinates: { lat: number; lon: number; address: string }) => void
  onAreaSelect?: (area: any) => void
  onAnalysisStart?: () => void
  onToolActivated?: (tool: string) => void
}

export function MapContainer({ onCoordinateSelect, onAreaSelect, onAnalysisStart, onToolActivated }: MapContainerProps) {
  const mapRef = useRef<HTMLDivElement>(null)
  const [map, setMap] = useState<any>(null)
  const [view, setView] = useState<any>(null)
  const [sketchViewModel, setSketchViewModel] = useState<any>(null)
  const [searchInput, setSearchInput] = useState('')
  const [latitude, setLatitude] = useState('')
  const [longitude, setLongitude] = useState('')
  const [selectedCoordinates, setSelectedCoordinates] = useState<{lat: number, lon: number}>({ lat: -23.5505, lon: -46.6333 })
  const [selectedArea, setSelectedArea] = useState<any>(null)
  const [areaSize, setAreaSize] = useState(0)
  const [isDrawing, setIsDrawing] = useState(false)
  const [drawingMode, setDrawingMode] = useState<'polygon' | 'rectangle' | null>(null)
  const [esriLoaded, setEsriLoaded] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [isSearching, setIsSearching] = useState(false)
  const [manualLat, setManualLat] = useState('')
  const [manualLon, setManualLon] = useState('')

  // Load ESRI script
  useEffect(() => {
    const loadEsriScript = () => {
      if (window.require) {
        setEsriLoaded(true)
        return
      }

      const script = document.createElement('script')
      script.src = 'https://js.arcgis.com/4.28/'
      script.onload = () => {
        console.log("✅ ESRI ArcGIS API loaded")
        setEsriLoaded(true)
      }
      script.onerror = () => {
        console.error("❌ Failed to load ESRI ArcGIS API")
      }
      document.head.appendChild(script)
    }

    loadEsriScript()
  }, [])

  // Initialize ESRI Map
  useEffect(() => {
    if (!esriLoaded || !mapRef.current || map) return

    const initializeMap = () => {
      console.log("🗺️ Initializing ESRI ArcGIS Map...")
      
      window.require([
        'esri/Map',
        'esri/views/MapView',
        'esri/widgets/Sketch',
        'esri/layers/GraphicsLayer',
        'esri/Graphic',
        'esri/geometry/geometryEngine'
      ], (Map: any, MapView: any, Sketch: any, GraphicsLayer: any, Graphic: any, geometryEngine: any) => {
        
        // Create graphics layer for drawings
        const graphicsLayer = new GraphicsLayer()

        // Create map
        const mapInstance = new Map({
          basemap: "hybrid", // Hybrid shows satellite + city labels for professional use
          ground: "world-elevation"
        })

        // Add graphics layer to map
        mapInstance.add(graphicsLayer)

        // Create map view
        const viewInstance = new MapView({
          container: mapRef.current!,
          map: mapInstance,
          center: [-46.6333, -23.5505], // Default to São Paulo
          zoom: 10,
          ui: {
            components: ["attribution"] // Keep attribution but remove other UI to avoid login
          },
          constraints: {
            minZoom: 3,
            maxZoom: 18
          },
          // Professional navigation settings
          navigation: {
            browserTouchPanEnabled: true,
            mouseWheelZoomEnabled: true,
            gamepad: {
              enabled: false
            }
          }
        })

        // Create sketch widget
        const sketch = new Sketch({
          layer: graphicsLayer,
          view: viewInstance,
          creationMode: 'update',
          availableCreateTools: ['rectangle', 'polygon'], // Rectangle and Polygon tools
          defaultCreateOptions: {
            hasZ: false
          },
          defaultUpdateOptions: {
            enableRotation: false,
            enableScaling: false, // REMOVE DOTS - disable scaling handles
            multipleSelectionEnabled: false,
            toggleToolOnClick: false, // CLEAN RECTANGLES without handles
            // Prevent automatic conversion to rectangle
            preserveAspectRatio: false
          },
          // Override visual settings for clean appearance
          visibleElements: {
            selectionTools: {
              "lasso-selection": false,
              "rectangle-selection": false
            },
            settingsMenu: false,
            undoRedoMenu: false
          }
        })

        // Add sketch widget to view (but hidden by default)
        viewInstance.ui.add(sketch, 'top-right')
        sketch.visible = false

        // Handle sketch events
        sketch.on('create', (event: any) => {
          console.log("🎨 Sketch create event:", event.state, event.graphic?.geometry?.type)
          
          if (event.state === 'complete') {
            const geometry = event.graphic.geometry
            console.log("🎯 Area created:", geometry)
            
            // Calculate area in square meters
            const area = Math.abs(geometryEngine.geodesicArea(geometry, 'square-meters'))
            console.log("📏 Area size:", area, "m²")
            
            setAreaSize(area)
            
            // Count points based on geometry type - FIXED LOGIC
            let pointCount = 0
            if (geometry.type === 'polygon') {
              // For polygons, count all vertices in the first ring (minus the closing point)
              pointCount = geometry.rings[0].length - 1
              console.log("🔺 Polygon points detected:", pointCount, "Ring:", geometry.rings[0])
            } else if (geometry.type === 'extent') {
              pointCount = 4 // Rectangle always has 4 points
              console.log("⬛ Rectangle points detected:", pointCount)
            }
            
            console.log("📊 Final point count:", pointCount)
            
            // Update selected area info
            setSelectedArea({
              ...event.graphic,
              pointCount: pointCount
            })
            
            // Get centroid for coordinates
            const centroid = geometry.centroid || geometry.center
            if (centroid) {
              const lat = centroid.latitude
              const lon = centroid.longitude
              
              setSelectedCoordinates({ lat, lon })
              setLatitude(lat.toString())
              setLongitude(lon.toString())
              
              onCoordinateSelect({
                lat,
                lon,
                address: `${lat.toFixed(6)}, ${lon.toFixed(6)}`
              });
            }

            setIsDrawing(false)
            setDrawingMode(null)
            
            if (onAreaSelect) {
              onAreaSelect({
                geometry: geometry,
                area: area,
                centroid: centroid,
                points: pointCount // CORRECTED: pass points instead of pointCount
              })
            }
            
            console.log("✅ Drawing completed successfully")
          }
        })

        sketch.on('update', (event: any) => {
          if (event.state === 'complete') {
            const geometry = event.graphics[0].geometry
            const area = Math.abs(geometryEngine.geodesicArea(geometry, 'square-meters'))
            
            console.log("📏 Updated area size:", area, "m²")
            setAreaSize(area)
            setSelectedArea(event.graphics[0])
          }
        })

        sketch.on('delete', () => {
          console.log("🗑️ Area deleted")
          setSelectedArea(null)
          setAreaSize(0)
        })

        // Map click handler for point selection
        viewInstance.on('click', (event: any) => {
          console.log("🖱️ Map clicked, current drawing mode:", drawingMode)
          
          // Only handle clicks when in point mode or no active drawing
          if (drawingMode === 'point' || (!isDrawing && !drawingMode)) {
            const mapPoint = event.mapPoint
            const lat = mapPoint.latitude
            const lon = mapPoint.longitude
            
            console.log("🎯 Pin placed at:", lat, lon)
            
            setSelectedCoordinates({ lat, lon })
            setLatitude(lat.toFixed(6))
            setLongitude(lon.toFixed(6))
            
            onCoordinateSelect({
              lat,
              lon,
              address: `${lat.toFixed(6)}, ${lon.toFixed(6)}`
            })
            
            // Create bright, visible pin marker - ACTUAL PIN SHAPE
            const marker = new Graphic({
              geometry: mapPoint,
              symbol: {
                type: 'picture-marker',
                url: 'data:image/svg+xml;base64,' + btoa(`
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="40" viewBox="0 0 24 32">
                    <path d="M12 0C7.6 0 4 3.6 4 8c0 5.4 8 24 8 24s8-18.6 8-24c0-4.4-3.6-8-8-8z" fill="#FFD700" stroke="#FFF" stroke-width="2"/>
                    <circle cx="12" cy="8" r="3" fill="#FFF"/>
                  </svg>
                `),
                width: 32,
                height: 40,
                yoffset: 20 // Offset so pin points to correct location
              },
              popupTemplate: {
                title: "📍 Pin Adicionado",
                content: `<div style="color: #000; font-size: 14px; line-height: 1.5;">
                  <strong>🌍 Latitude:</strong> ${lat.toFixed(6)}<br/>
                  <strong>🌍 Longitude:</strong> ${lon.toFixed(6)}<br/>
                  <strong>🛰️ Sistema:</strong> <span style="color: #00ff00;">Sentinel-2 Ready</span><br/>
                  <strong>🎯 Status:</strong> Pin adicionado com sucesso
                </div>`,
                outFields: ["*"]
              }
            })
            
            // Clear previous graphics and add new marker
            graphicsLayer.removeAll()
            graphicsLayer.add(marker)
            
            // Show popup automatically
            viewInstance.popup.open({
              features: [marker],
              location: mapPoint
            })
            
            // Update selected area info for pin - FIXED
            setSelectedArea({
              pointCount: 1,
              geometry: mapPoint
            })
            
            if (onAreaSelect) {
              onAreaSelect({
                geometry: mapPoint,
                area: 25, // Default small area for point
                centroid: mapPoint,
                points: 1 // CORRECTED: use points instead of pointCount
              })
            }
            
            // Reset pin tool mode after use ONLY if it was specifically point mode
            if (drawingMode === 'point') {
              setDrawingMode(null)
              setIsDrawing(false)
              if (onToolActivated) onToolActivated('point') // Keep point tool active
            }
            
            console.log("✅ Pin added successfully at:", lat, lon)
          } else {
            console.log("⚠️ Click ignored - in drawing mode:", drawingMode, "isDrawing:", isDrawing)
          }
        })

        viewInstance.when(() => {
          console.log("✅ ESRI Map initialized successfully")
          setMap(mapInstance)
          setView(viewInstance)
          setSketchViewModel(sketch)
        })
      })
    }

    initializeMap()

    return () => {
      if (view) {
        view.destroy()
        setView(null)
        setMap(null)
      }
    }
  }, [esriLoaded, longitude, latitude])

  // Handle coordinate update
  const handleCoordinateUpdate = (lat: number, lon: number) => {
    setSelectedCoordinates({ lat, lon })
    setLatitude(lat.toString())
    setLongitude(lon.toString())
    
    if (view) {
      view.center = [lon, lat]
    }
    
    onCoordinateSelect({
      lat,
      lon,
      address: `${lat.toFixed(6)}, ${lon.toFixed(6)}`
    })
  }

  // Handle latitude input change
  const handleLatitudeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    setLatitude(value)
    
    const latNum = parseFloat(value)
    const lonNum = parseFloat(longitude)
    
    if (!isNaN(latNum) && !isNaN(lonNum) && latNum >= -90 && latNum <= 90 && lonNum >= -180 && lonNum <= 180) {
      handleCoordinateUpdate(latNum, lonNum)
    }
  }

  // Handle longitude input change  
  const handleLongitudeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    setLongitude(value)
    
    const latNum = parseFloat(latitude)
    const lonNum = parseFloat(value)
    
    if (!isNaN(latNum) && !isNaN(lonNum) && latNum >= -90 && latNum <= 90 && lonNum >= -180 && lonNum <= 180) {
      handleCoordinateUpdate(latNum, lonNum)
    }
  }

  // Start drawing mode - FIXED POLYGON/RECTANGLE TOOLS
  const startDrawing = (mode: 'polygon' | 'rectangle') => {
    if (sketchViewModel) {
      console.log(`🎨 Starting ${mode} drawing mode`)
      
      // Clear any existing graphics
      if (sketchViewModel.layer) {
        sketchViewModel.layer.removeAll()
      }
      
      // Cancel any ongoing operations
      sketchViewModel.cancel()
      
      // Set drawing state
      setIsDrawing(true)
      setDrawingMode(mode)
      
      // Start drawing with correct tool
      sketchViewModel.create(mode)
      
      console.log(`✅ ${mode} tool activated successfully`)
    } else {
      console.error("❌ Sketch view model not available")
    }
  }

  // Clear all drawings
  const clearDrawings = () => {
    if (sketchViewModel && sketchViewModel.layer) {
      sketchViewModel.layer.removeAll()
      setSelectedArea(null)
      setAreaSize(0)
      console.log("🗑️ All drawings cleared")
    }
  }

  // Handle analysis button click
  const handleAnalysisClick = () => {
    const latNum = parseFloat(latitude)
    const lonNum = parseFloat(longitude)
    
    if (!isNaN(latNum) && !isNaN(lonNum) && latNum >= -90 && latNum <= 90 && lonNum >= -180 && lonNum <= 180) {
      handleCoordinateUpdate(latNum, lonNum)
      
      if (onAnalysisStart) {
        console.log('🚀 Starting analysis from ESRI map')
        onAnalysisStart()
      }
    } else {
      alert('Por favor, selecione uma localização válida no mapa ou insira coordenadas válidas.')
    }
  }

  // Search for places worldwide using OpenStreetMap Nominatim (free, no API key)
  const searchPlace = async () => {
    if (!searchQuery.trim() || !esriLoaded) return
    
    setIsSearching(true)
    console.log("🔍 Searching for:", searchQuery)
    
    try {
      // Use OpenStreetMap Nominatim API (free, no API key required)
      const nominatimUrl = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchQuery)}&limit=1&addressdetails=1`
      
      console.log("📡 Nominatim URL:", nominatimUrl)
      
      const response = await fetch(nominatimUrl, {
        headers: {
          'User-Agent': 'iAgroSat-Satellite-System/1.0'
        }
      })
      const data = await response.json()
      
      console.log("🗺️ Nominatim response:", data)
      
      if (data && data.length > 0) {
        const location = data[0]
        const lat = parseFloat(location.lat)
        const lon = parseFloat(location.lon)
        
        console.log(`✅ Found ${searchQuery} at:`, lat, lon)
        
        setSelectedCoordinates({ lat, lon })
        setLatitude(lat.toString())
        setLongitude(lon.toString())
        
        // Update parent coordinates
        onCoordinateSelect({
          lat,
          lon,
          address: location.display_name || `${lat.toFixed(6)}, ${lon.toFixed(6)}`
        })
        
        if (view) {
          // Clear previous graphics
          if (sketchViewModel && sketchViewModel.layer) {
            sketchViewModel.layer.removeAll()
          }
          
          // Center map on location
          view.goTo({
            center: [lon, lat],
            zoom: 14
          }).then(() => {
            // Add marker after map moves
            window.require(['esri/Graphic'], (Graphic: any) => {
              const marker = new Graphic({
                geometry: {
                  type: 'point',
                  latitude: lat,
                  longitude: lon
                },
                symbol: {
                  type: 'picture-marker',
                  url: 'data:image/svg+xml;base64,' + btoa(`
                    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="36" viewBox="0 0 24 32">
                      <path d="M12 0C7.6 0 4 3.6 4 8c0 5.4 8 24 8 24s8-18.6 8-24c0-4.4-3.6-8-8-8z" fill="#00FF00" stroke="#FFF" stroke-width="2"/>
                      <circle cx="12" cy="8" r="3" fill="#FFF"/>
                    </svg>
                  `),
                  width: 28,
                  height: 36,
                  yoffset: 18 // Green pin for search results
                },
                popupTemplate: {
                  title: `📍 ${location.display_name || searchQuery}`,
                  content: `<div style="color: #000; font-size: 14px; line-height: 1.5;">
                    <strong>📍 Local:</strong> ${location.display_name || searchQuery}<br/>
                    <strong>🌍 Latitude:</strong> ${lat.toFixed(6)}<br/>
                    <strong>🌍 Longitude:</strong> ${lon.toFixed(6)}<br/>
                    <strong>🛰️ Sistema:</strong> <span style="color: #00ff00;">Sentinel-2 Ready</span><br/>
                    <strong>🔍 Fonte:</strong> OpenStreetMap
                  </div>`
                }
              })
              
              if (sketchViewModel && sketchViewModel.layer) {
                sketchViewModel.layer.add(marker)
                
                // Show popup
                view.popup.open({
                  features: [marker],
                  location: { latitude: lat, longitude: lon }
                })
              }
            })
          })
        }
        
        setSearchQuery('')
        console.log(`🎯 Search complete: Found ${location.display_name || searchQuery}`)
      } else {
        console.log("❌ No results found for:", searchQuery)
        alert('Local não encontrado. Tente outro nome.')
      }
    } catch (error) {
      console.error('❌ Search error:', error)
      alert('Erro na busca. Tente novamente.')
    } finally {
      setIsSearching(false)
    }
  }

  const setManualCoordinates = () => {
    if (esriLoaded && map && manualLat && manualLon) {
      const lat = parseFloat(manualLat);
      const lon = parseFloat(manualLon);
      
      if (!isNaN(lat) && !isNaN(lon)) {
        map.goTo({
          center: [lon, lat],
          zoom: 12
        });
        
        onCoordinateSelect({ 
          lat, 
          lon, 
          address: `${lat.toFixed(6)}, ${lon.toFixed(6)}`
        });
      }
    }
  };

  // Expose functions for external use
  const handleExternalSearch = async (query: string) => {
    console.log("🔍 External search triggered:", query)
    setSearchQuery(query)
    
    if (!query.trim() || !esriLoaded) return false
    
    setIsSearching(true)
    
    try {
      // Use OpenStreetMap Nominatim API (free, no API key required)
      const nominatimUrl = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=1&addressdetails=1`
      
      console.log("📡 External Nominatim URL:", nominatimUrl)
      
      const response = await fetch(nominatimUrl, {
        headers: {
          'User-Agent': 'iAgroSat-Satellite-System/1.0'
        }
      })
      const data = await response.json()
      
      console.log("🗺️ External Nominatim response:", data)
      
      if (data && data.length > 0) {
        const location = data[0]
        const lat = parseFloat(location.lat)
        const lon = parseFloat(location.lon)
        
        console.log(`✅ External search found ${query} at:`, lat, lon)
        
        setSelectedCoordinates({ lat, lon })
        setLatitude(lat.toString())
        setLongitude(lon.toString())
        
        // Update parent coordinates
        onCoordinateSelect({
          lat,
          lon,
          address: location.display_name || `${lat.toFixed(6)}, ${lon.toFixed(6)}`
        })
        
        if (view) {
          // Clear previous graphics
          if (sketchViewModel && sketchViewModel.layer) {
            sketchViewModel.layer.removeAll()
          }
          
          // Center map on location
          view.goTo({
            center: [lon, lat],
            zoom: 14
          }).then(() => {
            // Add marker after map moves
            window.require(['esri/Graphic'], (Graphic: any) => {
              const marker = new Graphic({
                geometry: {
                  type: 'point',
                  latitude: lat,
                  longitude: lon
                },
                symbol: {
                  type: 'picture-marker',
                  url: 'data:image/svg+xml;base64,' + btoa(`
                    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="36" viewBox="0 0 24 32">
                      <path d="M12 0C7.6 0 4 3.6 4 8c0 5.4 8 24 8 24s8-18.6 8-24c0-4.4-3.6-8-8-8z" fill="#00FF00" stroke="#FFF" stroke-width="2"/>
                      <circle cx="12" cy="8" r="3" fill="#FFF"/>
                    </svg>
                  `),
                  width: 28,
                  height: 36,
                  yoffset: 18 // Green pin for external search
                },
                popupTemplate: {
                  title: `📍 ${location.display_name || query}`,
                  content: `<div style="color: #000; font-size: 14px; line-height: 1.5;">
                    <strong>📍 Local:</strong> ${location.display_name || query}<br/>
                    <strong>🌍 Latitude:</strong> ${lat.toFixed(6)}<br/>
                    <strong>🌍 Longitude:</strong> ${lon.toFixed(6)}<br/>
                    <strong>🛰️ Sistema:</strong> <span style="color: #00ff00;">Sentinel-2 Ready</span><br/>
                    <strong>🔍 Fonte:</strong> OpenStreetMap
                  </div>`
                }
              })
              
              if (sketchViewModel && sketchViewModel.layer) {
                sketchViewModel.layer.add(marker)
                
                // Show popup
                view.popup.open({
                  features: [marker],
                  location: { latitude: lat, longitude: lon }
                })
              }
            })
          })
        }
        
        console.log(`🎯 External search complete: Found ${location.display_name || query}`)
        return true
      } else {
        console.log("❌ External search - No results found for:", query)
        alert('Local não encontrado. Tente outro nome.')
        return false
      }
    } catch (error) {
      console.error('❌ External search error:', error)
      alert('Erro na busca. Tente novamente.')
      return false
    } finally {
      setIsSearching(false)
    }
  }

  const handleExternalAreaTool = () => {
    console.log("📐 External rectangle tool activated")
    if (onToolActivated) onToolActivated('rectangle')
    
    // Clear any existing drawings and cancel operations
    if (sketchViewModel) {
      if (sketchViewModel.layer) {
        sketchViewModel.layer.removeAll()
      }
      sketchViewModel.cancel()
    }
    
    startDrawing('rectangle') // Clean rectangle for bounding box
  }

  const handleExternalPolygonTool = () => {
    console.log("🎨 External polygon tool activated")  
    if (onToolActivated) onToolActivated('polygon')
    
    // Clear any existing drawings and cancel operations  
    if (sketchViewModel) {
      if (sketchViewModel.layer) {
        sketchViewModel.layer.removeAll()
      }
      sketchViewModel.cancel()
    }
    
    startDrawing('polygon') // True polygon for custom shapes
  }

  const handleExternalPointTool = () => {
    console.log("📍 External point tool activated")
    if (onToolActivated) onToolActivated('point')
    
    // Clear any existing drawings first
    if (sketchViewModel && sketchViewModel.layer) {
      sketchViewModel.layer.removeAll()
    }
    
    // Cancel any active sketch operations
    if (sketchViewModel) {
      sketchViewModel.cancel()
    }
    
    // Enable click mode for pin tool - FIXED
    setIsDrawing(false)
    setDrawingMode('point')
    
    console.log("✅ Point mode activated - click anywhere on the map to place a pin")
    console.log("🎯 Current drawing mode set to:", 'point')
  }

  const handleExternalClear = () => {
    console.log("🗑️ External clear activated")
    if (onToolActivated) onToolActivated('clear')
    clearDrawings()
  }

  const handleExternalUpdateCoordinates = (lat: number, lon: number) => {
    console.log("📍 External coordinate update:", lat, lon)
    if (view) {
      // Clear previous graphics first
      if (sketchViewModel && sketchViewModel.layer) {
        sketchViewModel.layer.removeAll()
      }
      
      view.goTo({
        center: [lon, lat],
        zoom: 12
      }).then(() => {
        // Add marker at the new location AFTER map moves
        window.require(['esri/Graphic'], (Graphic: any) => {
          const marker = new Graphic({
            geometry: {
              type: 'point',
              latitude: lat,
              longitude: lon
            },
            symbol: {
              type: 'picture-marker',
              url: 'data:image/svg+xml;base64,' + btoa(`
                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="36" viewBox="0 0 24 32">
                  <path d="M12 0C7.6 0 4 3.6 4 8c0 5.4 8 24 8 24s8-18.6 8-24c0-4.4-3.6-8-8-8z" fill="#FFD700" stroke="#FFF" stroke-width="2"/>
                  <circle cx="12" cy="8" r="3" fill="#FFF"/>
                </svg>
              `),
              width: 28,
              height: 36,
              yoffset: 18 // Gold pin for manual coordinates
            },
            popupTemplate: {
              title: "📍 Coordenadas Inseridas",
              content: `<div style="color: #000; font-size: 14px; line-height: 1.5;">
                <strong>🌍 Latitude:</strong> ${lat.toFixed(6)}<br/>
                <strong>🌍 Longitude:</strong> ${lon.toFixed(6)}<br/>
                <strong>🛰️ Sistema:</strong> <span style="color: #00ff00;">Sentinel-2 Ready</span><br/>
                <strong>🎯 Fonte:</strong> Coordenadas Manuais
              </div>`
            }
          })
          
          // Add marker to graphics layer
          if (sketchViewModel && sketchViewModel.layer) {
            sketchViewModel.layer.add(marker)
            console.log("📍 Manual coordinate marker added at:", lat, lon)
            
            // Show popup
            view.popup.open({
              features: [marker],
              location: { latitude: lat, longitude: lon }
            })
          }
        })
      })
    }
    
    setSelectedCoordinates({ lat, lon })
    setLatitude(lat.toString())
    setLongitude(lon.toString())
    
    onCoordinateSelect({
      lat,
      lon,
      address: `${lat.toFixed(6)}, ${lon.toFixed(6)}`
    })
  }

  // Handle zoom in
  const handleZoomIn = () => {
    if (view) {
      view.zoom = Math.min(view.zoom + 1, 20)
      console.log("🔍 Zoom in:", view.zoom)
    }
  }

  // Handle zoom out
  const handleZoomOut = () => {
    if (view) {
      view.zoom = Math.max(view.zoom - 1, 1)
      console.log("🔍 Zoom out:", view.zoom)
    }
  }

  // Handle pan tool
  const handlePanTool = () => {
    if (view) {
      // Reset to default navigation mode (pan/zoom)
      view.navigation.mouseWheelZoomEnabled = true
      view.navigation.browserTouchPanEnabled = true
      setDrawingMode(null)
      setIsDrawing(false)
      console.log("🤚 Pan tool activated - drag to move map")
    }
  }

  // Store functions for external access
  const mapFunctions = {
    search: handleExternalSearch,
    activateAreaTool: handleExternalAreaTool,
    activatePolygonTool: handleExternalPolygonTool,
    activatePointTool: handleExternalPointTool,
    activatePanTool: handlePanTool,
    clearSelection: handleExternalClear,
    updateCoordinates: handleExternalUpdateCoordinates,
    zoomIn: handleZoomIn,
    zoomOut: handleZoomOut
  }

  // Expose functions to parent
  if (typeof window !== 'undefined') {
    (window as any).mapFunctions = mapFunctions
  }

  return (
    <div className="relative h-full bg-slate-900">
      {/* ESRI Map Container */}
      <div 
        ref={mapRef} 
        className="h-full w-full"
        style={{ minHeight: '600px' }}
      >
        {!esriLoaded && (
          <div className="h-full w-full flex items-center justify-center bg-gray-100">
            <div className="text-center p-8">
              <div className="text-6xl mb-4 animate-bounce">🌍</div>
              <h3 className="text-2xl font-bold text-gray-800 mb-2">Carregando Sistema</h3>
              <p className="text-gray-600">Inicializando mapa interativo</p>
              <div className="mt-4 flex justify-center">
                <div className="w-8 h-8 border-4 border-green-600 border-t-transparent rounded-full animate-spin"></div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}