'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Satellite, Download, CheckCircle, Loader2, RefreshCw, Database, MapPin, BarChart3, Image, Layers, Cloud } from 'lucide-react'

interface ProcessingStep {
  step: number
  nome: string
  descricao: string
  status: 'pending' | 'in_progress' | 'done' | 'error'
  tempo_estimado: number
  dados: {
    [key: string]: any
  }
}

interface ProgressTrackerProps {
  jobId: string | null
  onComplete?: (shortJobId: string) => void
}

const PROCESSING_STEPS: ProcessingStep[] = [
  {
    step: 1,
    nome: "Busca de Imagens Sentinel-2",
    descricao: "Consultando catálogo oficial ESA para localizar a cena mais recente com menor cobertura de nuvens na área de interesse.",
    status: "pending",
    tempo_estimado: 8,
    dados: {}
  },
  {
    step: 2,
    nome: "Download das Bandas Espectrais",
    descricao: "Baixando bandas B02 (Blue), B03 (Green), B04 (Red), B08 (NIR) e SCL (Scene Classification) em resolução 10m.",
    status: "pending",
    tempo_estimado: 25,
    dados: {
      bandas_baixadas: []
    }
  },
  {
    step: 3,
    nome: "Validação de Cobertura e Qualidade",
    descricao: "Verificando integridade dos dados, proporção de pixels válidos e cobertura de nuvens na região.",
    status: "pending",
    tempo_estimado: 4,
    dados: {
      pixels_validos: null,
      proporcao_pixels_validos: null,
      proporcao_nuvem: null
    }
  },
  {
    step: 4,
    nome: "Recorte para Área de Interesse (AOI)",
    descricao: "Reprojetando coordenadas e recortando precisamente a área de interesse usando geometria fornecida.",
    status: "pending",
    tempo_estimado: 4,
    dados: {
      crs: null,
      tamanho_aoi_km2: null
    }
  },
  {
    step: 5,
    nome: "Remoção de Nuvens e Máscaras",
    descricao: "Aplicando máscara SCL para remover pixels de nuvens, sombras e dados inválidos.",
    status: "pending",
    tempo_estimado: 3,
    dados: {
      pixels_mascarados: null,
      qualidade_final: null
    }
  },
  {
    step: 6,
    nome: "Geração de Imagem RGB",
    descricao: "Processando bandas B04, B03, B02 para criar composição RGB natural com ajuste de contraste.",
    status: "pending",
    tempo_estimado: 5,
    dados: {
      preview_rgb: null,
      resolucao: null
    }
  },
  {
    step: 7,
    nome: "Cálculo de Índices Espectrais",
    descricao: "Calculando NDVI, EVI, SAVI e GCI para análise de vegetação e saúde das culturas.",
    status: "pending",
    tempo_estimado: 8,
    dados: {
      stats_ndvi: null,
      stats_evi: null,
      stats_savi: null,
      stats_gci: null
    }
  },
  {
    step: 8,
    nome: "Renderização de Mapas Coloridos",
    descricao: "Gerando visualizações coloridas dos índices espectrais com paletas científicas apropriadas.",
    status: "pending",
    tempo_estimado: 5,
    dados: {
      mapas_coloridos: [],
      paletas_aplicadas: []
    }
  },
  {
    step: 9,
    nome: "Geração de Tiles Superzoom",
    descricao: "Criando tiles em múltiplas escalas (até zoom 18) para visualização interativa de alta resolução.",
    status: "pending",
    tempo_estimado: 30,
    dados: {
      tiles_gerados: false,
      zoom_levels: null,
      tiles_url: null
    }
  },
  {
    step: 10,
    nome: "Finalização e Entrega",
    descricao: "Compilando resultados finais, gerando metadados e liberando acesso aos produtos processados.",
    status: "pending",
    tempo_estimado: 2,
    dados: {
      arquivos_finais: [],
      metadata_completo: null
    }
  }
]

const steps = [
  { 
    name: 'Iniciando análise', 
    duration: 3000, 
    icon: '🚀'
  },
  { 
    name: 'Baixando bandas espectrais', 
    duration: 25000, 
    icon: '📡'
  },
  { 
    name: 'Validando qualidade dos pixels', 
    duration: 8000, 
    icon: '🔍'
  },
  { 
    name: 'Calculando índices de vegetação', 
    duration: 15000, 
    icon: '📊'
  },
  { 
    name: 'Gerando tiles e visualizações', 
    duration: 10000, 
    icon: '🗺️'
  },
  { 
    name: 'Finalizando processamento', 
    duration: 2000, 
    icon: '✅'
  }
]

export default function ProgressTracker({ jobId, onComplete }: ProgressTrackerProps) {
  const [status, setStatus] = useState<'waiting' | 'processing' | 'completed' | 'error'>('waiting')
  const [progress, setProgress] = useState(0)
  const [statusMessage, setStatusMessage] = useState('Iniciando análise...')
  const [pollCount, setPollCount] = useState(0)
  const [processingSteps, setProcessingSteps] = useState<ProcessingStep[]>(PROCESSING_STEPS)
  const [currentStep, setCurrentStep] = useState(0)
  const [jobData, setJobData] = useState<any>(null)

  const getStepIcon = (step: number) => {
    switch (step) {
      case 1: return Database
      case 2: return Satellite
      case 3: return Download
      case 4: return CheckCircle
      case 5: return MapPin
      case 6: return BarChart3
      case 7: return Image
      case 8: return Layers
      case 9: return CheckCircle
      default: return Satellite
    }
  }

  const updateStepFromBackend = (stepNumber: number, backendData: any) => {
    console.log(`🔄 Updating step ${stepNumber} with backend data:`, backendData)
    
    setProcessingSteps(prev => prev.map(step => {
      if (step.step === stepNumber) {
        return {
          ...step,
          status: 'in_progress',
          dados: { ...step.dados, ...backendData }
        }
      }
      return step
    }))
  }

  const completeStep = (stepNumber: number) => {
    console.log(`✅ Completing step ${stepNumber}`)
    
    setProcessingSteps(prev => prev.map(step => {
      if (step.step === stepNumber) {
        return { ...step, status: 'done' }
      }
      return step
    }))
    
    setCurrentStep(stepNumber)
  }

  useEffect(() => {
    // Enhanced validation for jobId
    if (!jobId || jobId === 'undefined' || jobId === 'null' || jobId.trim() === '') {
      console.error('❌ Invalid or missing job ID:', jobId)
      setStatus('error')
      setStatusMessage('⚠️ Job ID inválido ou não encontrado')
      return
    }

    console.log('🔄 Starting job monitoring for job ID:', jobId)
    
    // Clear any browser cache/localStorage that might contain old job IDs
    localStorage.removeItem('currentJobId')
    localStorage.removeItem('lastJobId')
    sessionStorage.clear()
    
    // CRITICAL: Cancel any existing polls by setting a flag
    const pollId = Date.now().toString()
    ;(window as any).currentPollId = pollId
    console.log('🏃 Starting new poll with ID:', pollId)
    
    const pollJob = async () => {
      // Check if this poll has been cancelled
      if ((window as any).currentPollId !== pollId) {
        console.log('🛑 Poll cancelled, another job started')
        return
      }
      
      try {
        console.log(`📡 Polling job ${jobId} (attempt ${pollCount + 1})`)
        
        // Validate jobId before making request
        if (!jobId || jobId === 'undefined' || jobId === 'null') {
          console.error('❌ Invalid job ID:', jobId)
          setStatus('error')
          setStatusMessage('⚠️ Job ID inválido')
          return
        }
        
        const response = await fetch(`/api/full-report/status?job_id=${jobId}`, {
          method: 'GET',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
          }
        })
        
        console.log(`📡 Response status: ${response.status} for job ${jobId}`)
        
        // STOP INFINITE POLLING FOR 404s
        if (!response.ok && response.status === 404) {
          console.log(`🛑 Job ${jobId} not found (404), stopping polling`)
          setStatus('error')
          setStatusMessage('⚠️ Job não encontrado no backend')
          return // Stop polling
        }
        
        if (!response.ok) {
          console.error(`❌ HTTP error: ${response.status} ${response.statusText}`)
          throw new Error(`HTTP ${response.status}: ${response.statusText}`)
        }
        
        const data = await response.json()
        
        console.log('📊 Job status response:', data)
        setJobData(data)

        // Update processing steps based on backend status
        if (data.status === 'processing' || data.status === 'tiling') {
          setStatus('processing')
          
          // More realistic step progression based on actual backend timing
          const elapsedTime = pollCount * 8 // 8 seconds per poll
          
          if (elapsedTime >= 16 && currentStep < 1) {
            updateStepFromBackend(1, { timestamp: new Date().toISOString() })
            setTimeout(() => completeStep(1), 2000)
          } else if (elapsedTime >= 40 && currentStep < 2) {
            updateStepFromBackend(2, { 
              data_imagem: data.metadata?.date || new Date().toISOString().split('T')[0],
              cloud_cover: data.metadata?.cloud_cover || 'N/A'
            })
            setTimeout(() => completeStep(2), 15000) // Longer for download
          } else if (elapsedTime >= 80 && currentStep < 3) {
            updateStepFromBackend(3, { 
              bandas_baixadas: ['B02', 'B03', 'B04', 'B08', 'SCL']
            })
            setTimeout(() => completeStep(3), 5000)
          } else if (elapsedTime >= 120 && currentStep < 4) {
            updateStepFromBackend(4, { 
              pixels_validos: data.debug?.pixels_validos || 'Calculando...',
              proporcao_pixels_validos: data.debug?.proporcao_pixels_validos || 'N/A',
              proporcao_nuvem: data.metadata?.cloud_cover || 'N/A'
            })
            setTimeout(() => completeStep(4), 3000)
          } else if (elapsedTime >= 140 && currentStep < 5) {
            updateStepFromBackend(5, { 
              crs: 'EPSG:4326',
              tamanho_aoi_km2: data.metadata?.area_km2 || 'N/A'
            })
            setTimeout(() => completeStep(5), 2000)
          } else if (elapsedTime >= 160 && currentStep < 6) {
            updateStepFromBackend(6, { 
              stats_ndvi: 'Processando...',
              stats_evi: 'Processando...',
              stats_savi: 'Processando...',
              stats_gci: 'Processando...'
            })
            setTimeout(() => completeStep(6), 8000)
          } else if (elapsedTime >= 200 && currentStep < 7) {
            updateStepFromBackend(7, { 
              preview_rgb: 'Renderizando...',
              previews_indices: ['NDVI', 'EVI', 'SAVI', 'GCI']
            })
            setTimeout(() => completeStep(7), 4000)
          } else if (data.status === 'tiling' && currentStep < 8) {
            updateStepFromBackend(8, { 
              tiles_gerados: true,
              tiles_url: data.tiles_url || 'Gerando tiles...'
            })
            setTimeout(() => completeStep(8), 25000) // Tiles take longer
            setProgress(95)
            setStatusMessage('🗖️ Finalizando geração de tiles...')
          } else {
            setProgress(Math.min(5 + (currentStep * 8) + (pollCount * 0.5), 90))
            setStatusMessage(`🛰️ Processando Etapa ${currentStep + 1}/10 - Sentinel-2`)
          }
        }

        if (data.status === 'done') {
          console.log('🎉 Job completed! Redirecting to results...', data)
          
          // Complete all steps
          for (let i = 1; i <= 10; i++) {
            completeStep(i)
          }
          
          // Final step with complete data
          updateStepFromBackend(10, {
            arquivos_finais: ['RGB.png', 'NDVI.png', 'EVI.png', 'SAVI.png', 'GCI.png', 'Tiles'],
            metadata_completo: 'Processamento concluído com sucesso'
          })
          
          setStatus('completed')
          setProgress(100)
          setStatusMessage('✅ Análise Sentinel-2 concluída! Redirecionando...')
          
          setTimeout(() => {
            window.location.href = `/results/${jobId}`
          }, 2000)
          return
        } else if (data.status === 'processing' || data.status === 'tiling') {
          // Check again before scheduling next poll
          if ((window as any).currentPollId === pollId) {
            setTimeout(pollJob, 8000) // Changed from 3000 to 8000 (8 seconds)
            setPollCount(prev => prev + 1)
          }
        } else if (data.status === 'failed') {
          setStatus('error')
          setStatusMessage('❌ Erro no processamento')
        } else {
          console.log('⏳ Job still in queue, continuing to poll...')
          if ((window as any).currentPollId === pollId) {
            setTimeout(pollJob, 8000) // Changed from 3000 to 8000 (8 seconds)
            setPollCount(prev => prev + 1)
          }
        }
        
      } catch (error) {
        console.error('❌ Polling error:', error)
        
        // Check if it's a network error vs HTTP error
        if (error instanceof TypeError && error.message.includes('Failed to fetch')) {
          console.error('🌐 Network error - backend may be offline')
          setStatusMessage('🌐 Erro de conexão com o backend')
          
          // Only retry network errors a few times
          if (pollCount < 5 && (window as any).currentPollId === pollId) {
            console.log(`🔄 Retrying network request in 15 seconds (attempt ${pollCount + 1}/5)`)
            setTimeout(pollJob, 15000) // Wait longer for network issues
            setPollCount(prev => prev + 1)
          } else {
            console.log('🛑 Max network retries reached, stopping polling')
            setStatus('error')
            setStatusMessage('❌ Erro de conexão. Verifique se o backend está online.')
          }
        } else {
          // Other types of errors
          console.error('❌ Unexpected error:', error)
          if (pollCount < 10 && (window as any).currentPollId === pollId) {
            setTimeout(pollJob, 10000)
            setPollCount(prev => prev + 1)
          } else {
            console.log('🔍 Max polls reached, redirecting to results anyway...')
            setStatus('completed')
            setStatusMessage('⚠️ Redirecionando para resultados...')
            setTimeout(() => {
              window.location.href = `/results/${jobId}`
            }, 2000)
          }
        }
      }
    }

    // Start polling immediately
    pollJob()
    
    // Cleanup function to cancel polling when component unmounts or jobId changes
    return () => {
      if ((window as any).currentPollId === pollId) {
        console.log('🧹 Cleaning up poll for job:', jobId)
        delete (window as any).currentPollId
      }
    }
  }, [jobId, pollCount])

  const checkRecentCompletedJobs = async () => {
    try {
      console.log('🕵️ Checking recent completed jobs...')
      
      // Just redirect to current jobId if we have one
      if (jobId) {
        console.log(`🎯 Redirecting to job: ${jobId}`)
        window.location.href = `/results/${jobId}`
        return
      }
      
      console.log('⚠️ No job ID available')
      setStatusMessage('⚠️ Job ID não encontrado. Tente iniciar nova análise.')
      
    } catch (error) {
      console.error('❌ Error checking recent jobs:', error)
    }
  }

  return (
    <Card className="border-slate-700 bg-gradient-to-br from-slate-900 to-slate-800">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center justify-between text-slate-200">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-cyan-500 rounded-lg flex items-center justify-center">
              <Satellite className="h-4 w-4 text-white" />
            </div>
            <div>
              <span className="font-semibold">Processamento Sentinel-2</span>
              <div className="text-xs text-slate-400 font-normal">Análise espectral automatizada</div>
            </div>
          </div>
          <Badge 
            variant="outline" 
            className={`font-mono text-xs ${
              status === 'completed' 
                ? 'border-emerald-500 text-emerald-400 bg-emerald-950' 
                : status === 'error'
                ? 'border-red-500 text-red-400 bg-red-950'
                : 'border-blue-500 text-blue-400 bg-blue-950 animate-pulse'
            }`}
          >
            {status === 'completed' && '✅ CONCLUÍDO'}
            {status === 'error' && '❌ ERRO'}
            {status === 'processing' && '🔄 PROCESSANDO'}
            {!status && '⏳ INICIANDO'}
          </Badge>
        </CardTitle>
        
        <div className="mt-3">
          <div className="flex justify-between text-xs text-slate-400 mb-1">
            <span>Progresso Geral</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <div className="w-full bg-slate-800 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-blue-500 to-cyan-400 h-2 rounded-full transition-all duration-500 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        <div className="mt-2 text-xs text-slate-400 font-mono">
          Job ID: <span className="text-cyan-400">{jobId}</span>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="space-y-3">
          {processingSteps.map((step, index) => (
            <div key={step.step} className="flex items-start space-x-3">
              <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold ${
                step.status === 'done' 
                  ? 'bg-emerald-600 text-white' 
                  : step.status === 'in_progress'
                  ? 'bg-blue-600 text-white animate-pulse'
                  : step.status === 'error'
                  ? 'bg-red-600 text-white'
                  : 'bg-slate-700 text-slate-400'
              }`}>
                {step.status === 'done' ? '✓' : 
                 step.status === 'error' ? '✗' :
                 step.status === 'in_progress' ? '⟳' : step.step}
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h4 className={`text-sm font-medium ${
                    step.status === 'done' ? 'text-emerald-400' :
                    step.status === 'in_progress' ? 'text-blue-400' :
                    step.status === 'error' ? 'text-red-400' :
                    'text-slate-400'
                  }`}>
                    {step.nome}
                  </h4>
                </div>
                
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  {step.descricao}
                </p>
                
                {step.status === 'done' && step.dados && Object.keys(step.dados).length > 0 && (
                  <div className="mt-2 space-y-1">
                    {Object.entries(step.dados).map(([key, value]) => {
                      if (value && value !== 'N/A' && value !== null) {
                        return (
                          <div key={key} className="text-xs">
                            <span className="text-slate-500">{key.replace(/_/g, ' ')}:</span>{' '}
                            <span className="text-cyan-400 font-mono">{String(value)}</span>
                          </div>
                        )
                      }
                      return null
                    })}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
        
        {/* Status Summary at bottom */}
        <div className="mt-6 pt-4 border-t border-slate-700">
          <div className="grid grid-cols-2 gap-4 text-center">
            <div className="bg-slate-950/50 rounded-lg p-3 border border-slate-700">
              <div className="text-lg font-bold text-blue-400 font-mono">
                {processingSteps.filter(s => s.status === 'done').length}/10
              </div>
              <div className="text-xs text-slate-500">Etapas Concluídas</div>
            </div>
            <div className="bg-slate-950/50 rounded-lg p-3 border border-slate-700">
              <div className="text-lg font-bold text-cyan-400 font-mono">
                {status === 'completed' ? 'OK' : 
                 status === 'error' ? 'ERR' :
                 status === 'processing' ? 'RUN' : 'WAIT'}
              </div>
              <div className="text-xs text-slate-500">Status Atual</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}