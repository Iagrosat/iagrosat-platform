'use client'

import { useEffect, useRef } from 'react'
import dynamic from 'next/dynamic'

// Dynamically import leaflet to avoid SSR issues
const LeafletMap = dynamic(() => import('./leaflet-map'), { 
  ssr: false,
  loading: () => <div className="w-full h-96 bg-moss-900/50 rounded border border-moss-600/30 flex items-center justify-center text-moss-300">🗺️ Carregando mapa...</div>
})

interface SuperZoomMapProps {
  tilesUrl: string
  center: [number, number]
  jobId: string
}

export default function SuperZoomMap({ tilesUrl, center, jobId }: SuperZoomMapProps) {
  console.log("🗺️ SuperZoomMap initialized:", { tilesUrl, center, jobId })
  
  return (
    <div className="w-full h-96 border border-moss-600/30 rounded overflow-hidden">
      <LeafletMap tilesUrl={tilesUrl} center={center} jobId={jobId} />
    </div>
  )
}

// Also export as named export for compatibility
export { SuperZoomMap as SuperzoomMap }