"use client"

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Bell, CheckCircle, Clock } from 'lucide-react'

interface GlobalJobMonitorProps {
  onJobCompleted: (jobId: string) => void
}

interface JobStatus {
  id: string
  status: string
  timestamp: number
  notified: boolean
}

export function GlobalJobMonitor({ onJobCompleted }: GlobalJobMonitorProps) {
  const [activeJobs, setActiveJobs] = useState<JobStatus[]>([])
  const [completedJobs, setCompletedJobs] = useState<string[]>([])
  const [notifications, setNotifications] = useState<string[]>([])

  console.log("🔄 GlobalJobMonitor active - NO PLACEHOLDERS, only real-time jobs", { notifications: notifications.length })

  // Function to manually trigger job completion notification
  const triggerJobCompletion = (jobId: string) => {
    console.log("🎉 GlobalJobMonitor: Triggering completion for:", jobId)
    
    if (!completedJobs.includes(jobId)) {
      setCompletedJobs(prev => [...prev, jobId])
      setNotifications([jobId]) // Show notification
      onJobCompleted(jobId)
    }
  }

  // Expose function globally for ProgressTracker to call
  useEffect(() => {
    (window as any).globalJobMonitor = {
      triggerJobCompletion
    }
    
    return () => {
      delete (window as any).globalJobMonitor
    }
  }, [completedJobs])

  // Clear notifications after 5 seconds (faster)
  useEffect(() => {
    if (notifications.length > 0) {
      const timer = setTimeout(() => {
        setNotifications([])
      }, 5000)
      return () => clearTimeout(timer)
    }
  }, [notifications])

  if (notifications.length === 0) {
    return null
  }

  return (
    <div className="fixed top-4 right-4 z-50">
      {/* Show only the FIRST notification (most recent) */}
      {notifications.length > 0 && (
        <Card className="border-green-500/50 bg-green-50/95 backdrop-blur-sm shadow-xl animate-in slide-in-from-top-2 duration-300">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2 text-green-800">
              <CheckCircle className="h-4 w-4" />
              Análise Concluída!
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="flex items-center justify-between">
              <div>
                <Badge variant="outline" className="text-xs border-green-600 text-green-700">
                  {notifications[0]}
                </Badge>
              </div>
              <Button
                size="sm"
                variant="outline"
                className="text-xs border-green-600 text-green-700 hover:bg-green-100"
                onClick={() => {
                  window.location.href = `/results/${notifications[0]}`
                }}
              >
                Ver Resultados
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}