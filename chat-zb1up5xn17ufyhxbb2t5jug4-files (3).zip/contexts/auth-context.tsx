"use client";

import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { User, AuthSession, UserRole, Permission } from '@/types/auth';

interface AuthContextType {
  user: User | null;
  session: AuthSession | null;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  loading: boolean;
  hasPermission: (permission: Permission) => boolean;
  hasRole: (role: UserRole) => boolean;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock users for enterprise demo
const MOCK_USERS: User[] = [
  {
    id: '1',
    email: 'admin@iagrosat.com',
    name: 'Admin Principal',
    role: UserRole.SUPER_ADMIN,
    company: 'iAgroSat Corp',
    department: 'TI',
    permissions: Object.values(Permission),
    createdAt: '2024-01-01T00:00:00Z',
    lastLogin: new Date().toISOString(),
    isActive: true,
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face'
  },
  {
    id: '2',
    email: 'manager@iagrosat.com',
    name: 'Carlos Silva',
    role: UserRole.MANAGER,
    company: 'iAgroSat Corp',
    department: 'Agricultura',
    permissions: [
      Permission.CREATE_ANALYSIS,
      Permission.VIEW_ANALYSIS,
      Permission.DELETE_ANALYSIS,
      Permission.EXPORT_ANALYSIS,
      Permission.VIEW_USERS,
      Permission.INVITE_USERS,
      Permission.ACCESS_HISTORICAL_DATA,
    ],
    createdAt: '2024-01-15T00:00:00Z',
    lastLogin: new Date().toISOString(),
    isActive: true,
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face'
  },
  {
    id: '3',
    email: 'analyst@iagrosat.com',
    name: 'Ana Santos',
    role: UserRole.ANALYST,
    company: 'iAgroSat Corp',
    department: 'Pesquisa',
    permissions: [
      Permission.CREATE_ANALYSIS,
      Permission.VIEW_ANALYSIS,
      Permission.EXPORT_ANALYSIS,
      Permission.ACCESS_HISTORICAL_DATA,
    ],
    createdAt: '2024-02-01T00:00:00Z',
    lastLogin: new Date().toISOString(),
    isActive: true,
    avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face'
  },
  {
    id: '4',
    email: 'viewer@iagrosat.com',
    name: 'João Oliveira',
    role: UserRole.VIEWER,
    company: 'iAgroSat Corp',
    department: 'Operações',
    permissions: [
      Permission.VIEW_ANALYSIS,
    ],
    createdAt: '2024-02-15T00:00:00Z',
    lastLogin: new Date().toISOString(),
    isActive: true,
    avatar: 'https://images.unsplash.com/photo-1519244703995-f4e0f30006d5?w=150&h=150&fit=crop&crop=face'
  }
];

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<AuthSession | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for existing session
    const savedSession = localStorage.getItem('auth_session');
    if (savedSession) {
      try {
        const parsedSession = JSON.parse(savedSession);
        const sessionExpiry = new Date(parsedSession.expires);
        
        if (sessionExpiry > new Date()) {
          setSession(parsedSession);
          setUser(parsedSession.user);
        } else {
          localStorage.removeItem('auth_session');
        }
      } catch (error) {
        console.error('Error parsing session:', error);
        localStorage.removeItem('auth_session');
      }
    }
    
    // Auto-login for demo purposes
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('demo') === 'true' && !user) {
      const adminUser = MOCK_USERS[0]; // Admin user
      const expiryDate = new Date();
      expiryDate.setHours(expiryDate.getHours() + 24);
      
      const newSession: AuthSession = {
        user: adminUser,
        token: `demo_token_${Date.now()}`,
        expires: expiryDate.toISOString(),
      };
      
      setSession(newSession);
      setUser(adminUser);
      localStorage.setItem('auth_session', JSON.stringify(newSession));
      
      console.log('🔐 Demo auto-login:', adminUser.email);
    }
    
    setLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    setLoading(true);
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Find user (in real app, this would be an API call)
      const foundUser = MOCK_USERS.find(u => u.email === email);
      
      if (foundUser && password === 'admin123') {
        const expiryDate = new Date();
        expiryDate.setHours(expiryDate.getHours() + 24);
        
        const newSession: AuthSession = {
          user: foundUser,
          token: `mock_token_${Date.now()}`,
          expires: expiryDate.toISOString(),
        };
        
        setSession(newSession);
        setUser(foundUser);
        localStorage.setItem('auth_session', JSON.stringify(newSession));
        
        // Log audit event
        console.log('🔐 User login:', {
          userId: foundUser.id,
          email: foundUser.email,
          timestamp: new Date().toISOString()
        });
        
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Login error:', error);
      return false;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    setSession(null);
    localStorage.removeItem('auth_session');
    
    // Log audit event
    console.log('🔐 User logout:', {
      userId: user?.id,
      timestamp: new Date().toISOString()
    });
  };

  const hasPermission = (permission: Permission): boolean => {
    return user?.permissions.includes(permission) || false;
  };

  const hasRole = (role: UserRole): boolean => {
    if (!user) return false;
    
    // Super admin has all roles
    if (user.role === UserRole.SUPER_ADMIN) return true;
    
    // Role hierarchy
    const roleHierarchy = {
      [UserRole.SUPER_ADMIN]: 5,
      [UserRole.ADMIN]: 4,
      [UserRole.MANAGER]: 3,
      [UserRole.ANALYST]: 2,
      [UserRole.VIEWER]: 1,
    };
    
    return roleHierarchy[user.role] >= roleHierarchy[role];
  };

  const value: AuthContextType = {
    user,
    session,
    login,
    logout,
    loading,
    hasPermission,
    hasRole,
    isAuthenticated: !!user,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}