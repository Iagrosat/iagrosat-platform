import { NextRequest } from 'next/server'
import { UserRole, Permission } from '@/types/auth'
import { AuditLogger } from './audit-logger'

interface AuthResult {
  isValid: boolean
  userId?: string
  userRole?: UserRole
  permissions?: Permission[]
  ip?: string
  reason?: string
}

interface RateLimitInfo {
  requests: number
  resetTime: number
}

// Simple in-memory rate limiting (in production, use Redis)
const rateLimitStore = new Map<string, RateLimitInfo>()

export class AuthChecker {
  private static readonly RATE_LIMIT_WINDOW = 60 * 1000 // 1 minute
  private static readonly RATE_LIMIT_MAX_REQUESTS = 100 // per minute per user

  static async validateRequest(request: NextRequest): Promise<AuthResult> {
    try {
      // Get client IP
      const ip = request.headers.get('x-forwarded-for')?.split(',')[0] ||
                request.headers.get('x-real-ip') ||
                'unknown'

      // Get user agent
      const userAgent = request.headers.get('user-agent') || 'unknown'

      // Check rate limiting
      const rateLimitResult = this.checkRateLimit(ip)
      if (!rateLimitResult.allowed) {
        // Log security incident
        AuditLogger.logSecurityIncident('RATE_LIMIT_EXCEEDED', {
          ip,
          requests: rateLimitResult.remaining,
          endpoint: request.nextUrl.pathname
        }, ip, userAgent)
        
        return {
          isValid: false,
          reason: 'Rate limit exceeded',
          ip
        }
      }

      // Check for session token in header or cookie
      const authHeader = request.headers.get('authorization')
      const sessionCookie = request.cookies.get('auth_session')?.value

      let sessionToken: string | null = null
      if (authHeader?.startsWith('Bearer ')) {
        sessionToken = authHeader.substring(7)
      } else if (sessionCookie) {
        try {
          const session = JSON.parse(sessionCookie)
          sessionToken = session.token
        } catch (e) {
          console.warn('Invalid session cookie format')
        }
      }

      if (!sessionToken) {
        // Log unauthorized access attempt
        AuditLogger.logSecurityIncident('UNAUTHORIZED_ACCESS', {
          endpoint: request.nextUrl.pathname,
          reason: 'No authentication token'
        }, ip, userAgent)
        
        return {
          isValid: false,
          reason: 'No authentication token provided',
          ip
        }
      }

      // Validate session token (in production, validate with JWT or database)
      const sessionData = this.validateSessionToken(sessionToken)
      if (!sessionData) {
        // Log invalid token attempt
        AuditLogger.logSecurityIncident('INVALID_TOKEN', {
          endpoint: request.nextUrl.pathname,
          token_prefix: sessionToken.substring(0, 10)
        }, ip, userAgent)
        
        return {
          isValid: false,
          reason: 'Invalid or expired session',
          ip
        }
      }

      // Check if user session is still valid
      const sessionExpiry = new Date(sessionData.expires)
      if (sessionExpiry <= new Date()) {
        return {
          isValid: false,
          reason: 'Session expired',
          ip
        }
      }

      return {
        isValid: true,
        userId: sessionData.userId,
        userRole: sessionData.userRole,
        permissions: sessionData.permissions,
        ip
      }

    } catch (error) {
      console.error('Auth validation error:', error)
      return {
        isValid: false,
        reason: 'Authentication error',
        ip: 'unknown'
      }
    }
  }

  static checkRateLimit(identifier: string): { allowed: boolean; remaining: number } {
    const now = Date.now()
    const key = `rate_limit:${identifier}`
    
    const existing = rateLimitStore.get(key)
    
    if (!existing || now > existing.resetTime) {
      // Reset or first request
      rateLimitStore.set(key, {
        requests: 1,
        resetTime: now + this.RATE_LIMIT_WINDOW
      })
      return { allowed: true, remaining: this.RATE_LIMIT_MAX_REQUESTS - 1 }
    }
    
    if (existing.requests >= this.RATE_LIMIT_MAX_REQUESTS) {
      return { allowed: false, remaining: 0 }
    }
    
    existing.requests++
    rateLimitStore.set(key, existing)
    
    return { 
      allowed: true, 
      remaining: this.RATE_LIMIT_MAX_REQUESTS - existing.requests 
    }
  }

  static validateSessionToken(token: string): any | null {
    try {
      // In production, validate JWT token or check database
      // For demo, we'll use a simple token format validation
      if (token.startsWith('demo_token_') || token.startsWith('mock_token_')) {
        // Extract mock session data (in real app, decode JWT)
        const mockSessionData = {
          userId: 'demo_user',
          userRole: UserRole.SUPER_ADMIN,
          permissions: Object.values(Permission),
          expires: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // 24 hours
        }
        return mockSessionData
      }
      
      return null
    } catch (error) {
      console.error('Token validation error:', error)
      return null
    }
  }

  static hasPermission(userPermissions: Permission[], requiredPermission: Permission): boolean {
    return userPermissions.includes(requiredPermission)
  }

  static hasRole(userRole: UserRole, requiredRole: UserRole): boolean {
    const roleHierarchy = {
      [UserRole.SUPER_ADMIN]: 5,
      [UserRole.ADMIN]: 4,
      [UserRole.MANAGER]: 3,
      [UserRole.ANALYST]: 2,
      [UserRole.VIEWER]: 1,
    }
    
    return roleHierarchy[userRole] >= roleHierarchy[requiredRole]
  }

  static sanitizeInput(input: string): string {
    // Remove potentially dangerous characters
    return input.replace(/[<>;"'%&+]/g, '')
  }

  static validateCoordinates(lat: string, lon: string): { valid: boolean; lat?: number; lon?: number } {
    try {
      const latitude = parseFloat(lat)
      const longitude = parseFloat(lon)
      
      if (isNaN(latitude) || isNaN(longitude)) {
        return { valid: false }
      }
      
      if (latitude < -90 || latitude > 90) {
        return { valid: false }
      }
      
      if (longitude < -180 || longitude > 180) {
        return { valid: false }
      }
      
      return { valid: true, lat: latitude, lon: longitude }
    } catch (error) {
      return { valid: false }
    }
  }
}

// Export functions for backward compatibility
export const validateAuth = AuthChecker.validateRequest
export const checkRateLimit = AuthChecker.checkRateLimit
export const validateSessionToken = AuthChecker.validateSessionToken
export const hasPermission = AuthChecker.hasPermission
export const hasRole = AuthChecker.hasRole
export const sanitizeInput = AuthChecker.sanitizeInput
export const validateCoordinates = AuthChecker.validateCoordinates